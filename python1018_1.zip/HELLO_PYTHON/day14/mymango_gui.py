import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow
from selenium import webdriver
from selenium.webdriver.common.by import By
from day14.mymango_dao import DaoMango

form_class = uic.loadUiType("mymango_gui.ui")[0]

class MainClass(QMainWindow, form_class):
    def __init__(self) :
        QMainWindow.__init__(self)
        self.browser = webdriver.Chrome()
        self.browser.get("https://www.mangoplate.com/search/%EB%8C%80%EC%A0%84%20%EC%98%A4%EB%A5%98%EB%8F%99")
        self.dm = DaoMango()
        self.setupUi(self)
        self.show()
        self.pb.clicked.connect(self.myclick)
        self.pb_scrap.clicked.connect(self.myscrap)
    
    def myclick(self):
        url = self.le.text()
        self.browser.get(url)
        
    def myscrap(self):
        figs = self.browser.find_elements(by=By.CSS_SELECTOR, value='figcaption')
        for fig in figs:
            try:
                m_name = fig.find_elements(by=By.CSS_SELECTOR, value='a')[0].text
                if m_name != "":
                
                    menu = fig.find_elements(by=By.CSS_SELECTOR, value='.etc')[0].find_elements(by=By.CSS_SELECTOR, value='span')[0].text
                    print(":",m_name,":",menu)
                
                    cnt = self.dm.myinsert(m_name, menu)
                    print(cnt)
            except:
                print("error:")
            
    
        
if __name__ == "__main__" :
    app = QApplication(sys.argv) 
    window = MainClass() 
    app.exec_()