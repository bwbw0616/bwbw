package Chapter08Homework;

public class Rectangle extends Shape {

	private double width;
	private double height;

	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}

	public double area() {
		return (width * height);
	}

	public double perimeter() {
		return 2.00 * (width + height);
	}

	public String toString() {
		return String.format("도형의 종류 : 사각형, 둘레 : " + Math.floor(perimeter() * 100) / 100 + "cm, 넓이 : "
				+ Math.floor(area() * 100) / 100 + "cm²");
	}

}
