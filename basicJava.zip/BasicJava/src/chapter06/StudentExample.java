package chapter06;

public class StudentExample {
	public static void main(String[] args) {
		Student1 s1 = new Student1();
		
		System.out.println(s1.name);
//		s1.name = "홍길동";
	//	s1.no = 1;
		//Student s2 = new Student();
		
	}

}
