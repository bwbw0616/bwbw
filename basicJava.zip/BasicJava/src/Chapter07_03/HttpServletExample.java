package Chapter07_03;

import java.lang.reflect.Method;

public class HttpServletExample {
	public static void main(String[] args) {
		method(new LoginServlet());
		method(new FileDownloadServlet());		
	}
	
	
	public static void method(HttpServlet servlet) {
		servlet.service();
		
	}

}
