package day03;

import java.awt.Frame;

public class AweTest {
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setSize(300,400);
		f.setVisible(true);
	}
}
