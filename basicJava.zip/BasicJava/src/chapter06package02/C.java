package chapter06package02;

import chapter06package01.A;

public class C {
	
	A a1 = new A(true);
	A a2 = new A(1);
	a a3 = new A("문자열");

}
