package com.ddit.java.temp.view;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.ddit.java.temp.JdbcTemplate;
import com.ddit.java.temp.ScanUtil;
import com.ddit.java.temp.dao.MemberDAO;
import com.ddit.java.temp.service.CategoryService;
import com.ddit.java.temp.service.MemberService;

public class View {
	private static View instance;

	private View() {
	}

	public static View getInstance() {
		if(instance == null) {
			instance = new View();
		}
		return instance;
	}

	public void showReEnterMsg() {
		System.err.println("------------------");
		System.err.println(" ※ 다시 입력해 주십시오.");
		System.err.println("------------------");
	}

	// 홈
	public void showHomeMenu() {
		System.out.println("------------------");
		System.out.println("    << HOME >>");
		System.out.println("1. 로그인");
		System.out.println("2. 회원가입");
		System.out.println("Q. 종료");
		System.out.println("------------------");
		System.out.print("입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------");
		switch (enter) {
		case "1":
			login();
			break;
		case "2":
			join();
			break;
		case "Q":
			System.out.println("프로그램을 종료합니다.");
			System.out.println("------------------");
			return;
		default:
			showReEnterMsg();
			showHomeMenu();
			break;
		}
	}

	// 로그인
	public void login() {
		System.out.println("   << LOGIN >>");
		System.out.print("ID: ");
		String id = ScanUtil.nextLine();
		System.out.print("PASSWORD: ");
		String password = ScanUtil.nextLine();
		System.out.println("------------------");

		if(MemberService.getInstance().login(id, password)) {
			System.out.println("로그인에 성공했습니다.");
			System.out.println("------------------");
			showMainMenu();
			// user = dao.selectUser한 것을 보관하기
		}
		else {
			System.out.println("로그인에 실패했습니다.");
			System.out.println("------------------");
			showHomeMenu();
		}
	}

	// 회원가입
	public void join() {
		List<Object> list = new ArrayList<>();
		System.out.println("    << JOIN >>");
		System.out.println("------------------");
		System.out.print("ID: ");
		list.add(ScanUtil.nextLine());
		System.out.print("PASSWORD: ");
		list.add(ScanUtil.nextLine());
		System.out.print("이름: ");
		list.add(ScanUtil.nextLine());
		System.out.print("주민번호 앞자리(6): ");
		list.add(ScanUtil.nextLine());
		System.out.print("주민번호 뒷자리(7): ");
		list.add(ScanUtil.nextLine());
		System.out.print("주소: ");
		list.add(ScanUtil.nextLine());
		System.out.print("전화번호: ");
		list.add(ScanUtil.nextLine());
		System.out.println("------------------");

		MemberDAO dao = MemberDAO.getInstance();
		int result = dao.insertUser(list);
		if(result > 0) {
			System.out.println("\"" + list.get(2) + "\" 회원님의 회원가입을 축하드립니다.");
			System.out.println(" 홈 메뉴에서 로그인을 진행해 주세요.");
			System.out.println("------------------");
			showHomeMenu();
		}
		else {
			System.err.println("회원가입에 실패하였습니다.");
		}
	}

	// 메인
	public void showMainMenu() {
		System.out.println("   << MAIN >>");
		System.out.println("------------------");
		System.out.println("1. 예매하기");
		System.out.println("2. 마이페이지");
		System.out.println("Q. 종료");
		System.out.println("------------------");
		System.out.print("입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------");
		switch (enter) {
		case "1":
			showTicketingMenu();
			break;
		case "2":
			showMyPageMenu();
			break;
		case "Q":
			System.out.println("프로그램을 종료합니다.");
			System.out.println("------------------");
			return;
		default:
			showReEnterMsg();
			showMainMenu();
			break;
		}

	}

	public void showTicketingMenu() {
		System.out.println(" << TICKETING >>");
		System.out.println("------------------");

		// 카테고리 다오, 서비스로 나누기
		JdbcTemplate template = JdbcTemplate.getTemplate();
		String sql = "select CATEGORY_NAME from CONCERT_CATEGORY";
		List<Map<String, Object>> list = template.selectList(sql);

		System.out.println("선택번호\t 카테고리명");
		System.out.println("------------------");
		for (int i = 0; i < list.size(); i++) {
			for (Entry<String, Object> entry : list.get(i).entrySet()) {
				System.out.println("   " + (i + 1) + "\t " + entry.getValue());
			}

		}
		System.out.println("   " + (list.size() + 1) + "\t 돌아가기");
		
		System.out.println("------------------");
		System.out.print("입력 >> ");
		String enter = ScanUtil.nextLine();

		switch (enter) {
		case "1":
			showConcertInfo("뮤지컬");
			break;
		case "2":
			showConcertInfo("연극");
			break;
		case "3":
			showConcertInfo("콘서트");
			break;
		case "4":
			showConcertInfo("클래식/무용");
			break;
		case "5":
			showConcertInfo("아동/가족");
			break;
		case "6":
			showMainMenu();
			break;
		default:
			showReEnterMsg();
			showTicketingMenu();
			break;
		}
	}

	// 단어 정렬 필요
	public void showConcertInfo(String category) {
		String sql = "";
		sql += " select A.CON_NAME,";
		sql += "        A.CON_RATING,";
		sql += "        B.PLACE_NAME,";
		sql += "        A.CON_DATE";
		sql += "   from CONCERT A, PLACE B, CONCERT_CATEGORY C";
		sql += "  where A.PLACE_ID = B.PLACE_ID";
		sql += "    and A.CATEGORY_ID = C.CATEGORY_ID";
		sql += "    and C.CATEGORY_NAME = ?";

		JdbcTemplate template = JdbcTemplate.getTemplate();

		List<Map<String, Object>> list = template.selectList(sql, category);

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		System.out.println("------------------");
		System.out.println("선택번호\t 공연명\t\t 관람등급\t\t 장소\t\t 기간");
		for (int i = 0; i < list.size(); i++) {
			System.out.print((i + 1) + "\t ");
			if(list.get(i).get("CON_NAME").toString().length() < 8) {
				System.out.print(list.get(i).get("CON_NAME") + "\t\t ");
			}
			else {
				System.out.print(list.get(i).get("CON_NAME") + "\t ");
			}
			System.out.print(list.get(i).get("CON_RATING") + "\t ");
			System.out.print(list.get(i).get("PLACE_NAME") + "\t ");
			System.out.print(format.format(list.get(i).get("CON_DATE")) + "\t");
			System.out.println();
		}
		System.out.println("------------------");
		System.out.println("입력(Q만 됨) >> ");
		String enter = ScanUtil.nextLine();
		if(enter.equals("Q") || enter.equals("q")) {
			showTicketingMenu();
		}
		else {
			showReEnterMsg();
			showConcertInfo(category);
		}
	}

	public void showMyPageMenu() {

	}

}
