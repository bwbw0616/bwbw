a = 1
b = 3.4
print(a+b)
