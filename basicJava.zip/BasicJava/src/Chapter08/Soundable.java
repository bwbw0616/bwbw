package Chapter08;

public interface Soundable {
	String sound();
}
