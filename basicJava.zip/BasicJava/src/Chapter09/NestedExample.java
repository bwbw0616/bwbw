package Chapter09;

import Chapter09.NestedClass.InnerClass;

public class NestedExample {
	public static void main(String[] args) {
		NestedClass nestedClass = new NestedClass();
		nestedClass.a = "A";
		
		InnerClass innerClass = new NestedClass(). new InnerClass();
		innerClass.b = "B";
		
		new NestedClass.InnerClass2();
		
	}
}
