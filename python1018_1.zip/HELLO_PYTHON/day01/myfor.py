arr = [1, 2, 3, 4, 5]

for i in arr:
    print(i)
    #i는 아이템