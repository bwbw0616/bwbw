package com.ddit.java.ticketingapp.category;

import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class CategoryDAO {
	private static CategoryDAO instance;
	
	private CategoryDAO() {
	}
	
	public static CategoryDAO getInstance() {
		if(instance == null) {
			instance = new CategoryDAO();
		}
		return instance;
	}
	
	JdbcTemplate template = JdbcTemplate.getTemplate();
	
	public List<Map<String, Object>> selectCategory() {
		String sql = "select CATEGORY_NAME from CONCERT_CATEGORY";
		List<Map<String, Object>> list = template.selectList(sql);
		
		return list;
	}
	
}
