package chapter06;

public class Student {
	// 생성자(constructor)
	public Student() {
		//  TODO Auto-generated constructor stub
	}
}