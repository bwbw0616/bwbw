package com.ddit.java.temp;

import java.util.HashMap;
import java.util.Map;

public class MemberVO {
	public Map<String, Object> member = new HashMap<>();;

	   private Object memId;
	   private Object memPassword;
	   private Object memName;
	   private Object memRegno1;
	   private Object memRegno2;
	   private Object memHp;
	   private Object memAddr;
	   private Object registrationDate;

	   private static MemberVO instance;

	   private MemberVO() {
	   }

	   public static MemberVO getInstance() {
	      if(instance == null) {
	         instance = new MemberVO();
	      }
	      return instance;
	   }

	   public void setMember(Map<String, Object> member) {
	      this.member = member;
	      setMemberInfo();
	   }
	   
	   public void setMemberInfo() {
	      setMemId(member.get("MEM_ID"));
	      setMemPassword(member.get("MEM_PASSWORD"));
	      setMemName(member.get("MEM_NAME"));
	      setMemRegno1(member.get("MEM_REGNO1"));
	      setMemRegno2(member.get("MEM_REGNO2"));
	      setMemHp(member.get("MEM_HP"));
	      setMemAddr(member.get("MEM_ADDR"));
	      setRegistrationDate(member.get("REGISTRATION_DATE"));
	   }
	   
	   public void setMemId(Object memId) {
	      this.memId = memId;
	   }

	   public void setMemPassword(Object memPassword) {
	      this.memPassword = memPassword;
	   }

	   public void setMemName(Object memName) {
	      this.memName = memName;
	   }

	   public void setMemRegno1(Object memRegno1) {
	      this.memRegno1 = memRegno1;
	   }

	   public void setMemRegno2(Object memRegno2) {
	      this.memRegno2 = memRegno2;
	   }

	   public void setMemHp(Object memHp) {
	      this.memHp = memHp;
	   }

	   public void setMemAddr(Object memAddr) {
	      this.memAddr = memAddr;
	   }

	   public void setRegistrationDate(Object registrationDate) {
	      this.registrationDate = registrationDate;
	   }

	   public Object getId() {
	      return memId;
	   }

	   public Object getPassword() {
	      return memPassword;
	   }

	   public Object getName() {
	      return memName;
	   }

	   public Object getRegno1() {
	      return memRegno1;
	   }

	   public Object getRegno2() {
	      return memRegno2;
	   }

	   public Object getHp() {
	      return memHp;
	   }

	   public Object getAddr() {
	      return memAddr;
	   }

	   public Object getRegistrationDate() {
	      return registrationDate;
	   }
	
}
