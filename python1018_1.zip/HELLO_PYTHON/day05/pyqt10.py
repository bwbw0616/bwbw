from PyQt5 import uic
from PyQt5.Qt import QMainWindow
from anaconda_navigator.utils.qthelpers import qapplication
import sys


form_class = uic.loadUiType("pyqt10.ui")[0]

class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        
        self.pb.clicked.connect(self.button1Function)
    def drawStar(self,cnt):
        ret = ""
        for i in range(cnt):
            ret += "*"
        ret += "\n"
        return ret 
    
        
    def button1Function(self) :
        
        a = self.le_first.text()
        b = self.le_last.text()
        
        aa = int(a)
        bb = int(b)
        
        txt = ""
        for i in range(aa, bb+1):
            txt += self.drawStar(i)
        
        self.te.setText(txt)

if __name__ == "__main__" :
    app = qapplication(sys.argv) 

    myWindow = WindowClass() 

    myWindow.show()

    app.exec_()