package com.ddit.java.ticketingapp.payment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class PaymentDAO {
	private static PaymentDAO instance;
	private PaymentDAO() {
	}
	public static PaymentDAO getInstance() {
		if(instance == null) {
			instance = new PaymentDAO();
		}
		return instance;
	}
	
	JdbcTemplate template = JdbcTemplate.getTemplate();
	
	public List<Map<String, Object>> selectPayMethod() {
		String sql = "select PAYMETHOD_NAME as 결제수단명 from PAYMENT_METHOD";
		List<Map<String, Object>> list = template.selectList(sql);
		
		return list;
	}
	
	public Map<String, Object> selectPayMethod(Object methodName) {
		String sql = "select PAYMETHOD_ID from PAYMENT_METHOD where PAYMETHOD_NAME = ?";
		Map<String, Object> map = template.selectOne(sql, methodName);
		return map;
	}
	
	public int updatePayment(Object methodId, Object price, Object ticketingId) {
		String sql = "insert into PAYMENT values('P'||?||substr(to_char(SYSDATE, 'YYYYMMDD'), 5, 4)||TRIM(TO_CHAR(SEQ_PAYMENT.NEXTVAL, '000')), SYSDATE, ?, ?, ?)";
		List<Object> list = new ArrayList<>();
		list.add(methodId);
		list.add(price);
		list.add(methodId);
		list.add(ticketingId);
		
		int result = template.update(sql, list);
				
		return result;
	}

}
