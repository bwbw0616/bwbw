package day02;

public class Xi {
	int cnt_nuclear = 100;
	
	public void command() {
		cnt_nuclear++;
	}
}
