a = True

if a :
    print("good")
    print("good1")