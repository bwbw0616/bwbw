package com.ddit.java.ticketingapp.util;

import java.text.SimpleDateFormat;

public class FormatUtil {
	private static FormatUtil instance;
	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	
	private FormatUtil() {
	}
	
	public static FormatUtil getInstance() {
		if(instance == null) {
			instance = new FormatUtil();
		}
		return instance;
	}
	
	public static Object format(Object object) {
		return format.format(object);
	}
}
