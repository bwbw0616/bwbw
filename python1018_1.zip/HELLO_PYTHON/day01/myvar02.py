a = True
b = False

print(a and b)
print(a or b)

print(not a)