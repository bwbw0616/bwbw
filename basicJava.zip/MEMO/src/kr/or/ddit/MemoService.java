package kr.or.ddit;

import java.util.List;

public class MemoService {
	MemoDAO dao = MemoDAO.getInstance();

	public List<MemoVO> getMemoList(String searchWord) throws Exception {
		return dao.getMemoList(searchWord);
	}

	public MemoVO getMemo(long no) {
		return dao.getMemo(no);
	}

	public int insertMemo(MemoVO vo) throws Exception {
		return dao.insertMemo(vo);
	}

	public int updateMemo(MemoVO vo) {

		return dao.updateMemo(vo);

	}

	public int deleteMemo(long no) {

		return dao.deleteMemo(no);

	}

}