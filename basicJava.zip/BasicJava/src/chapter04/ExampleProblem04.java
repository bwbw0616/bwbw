package chapter04;

import java.util.Scanner;

public class ExampleProblem04 {
	public static void main(String[] args) {
		//시험문제 나옴**
		Scanner scanner = new Scanner(System.in);
		String a = "철수";
		String b = "영희";
		String result1;
		String result2;
		System.out.println("가위 바위 보 게임");		
		System.out.println(a + ":");
	   result1 = scanner.next();		
		System.out.println(b + ":");
		result2 = scanner.next();
		String result = "";
		if(!result1.equals(result2)) {
			if(result1.equals("바위")) {
				if(result2.equals("가위"))
					result = a;
				else
					result = b;
			}
			
				if(result1.equals("보")) {
					if(result2.equals("바위"))
						result = a;
					else
						result = b;
		}
				
					if(result1.equals("가위")) {
						if(result2.equals("보"))
							result = a;
						else
							result = b;
					}				
		System.out.println("결과:"+result+"승리");
				}
				else
		
		System.out.println("무승부");
		scanner.close();
	}
	
}
