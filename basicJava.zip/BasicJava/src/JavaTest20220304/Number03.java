package JavaTest20220304;

public class Number03 {
	public static void main(String[] args) {
		int n = 7;
		n = n + add(1, 2);
		Number03Foo f = new Number03Foo(10);
		n = n + f.getA();
		out(n);
	}

	private static void out(int x) {
		System.out.println(x);
	}

	private static int add(int x, int y) {
		int z = x + y;
		return z;
	}

}
