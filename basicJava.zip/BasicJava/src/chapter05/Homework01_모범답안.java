package chapter05;

public class Homework01_모범답안 {
	public static void main(String[] args) {
		
	//	int max = numbers[0];       //배열의 처음 값으로 시작
	//	int min = numbers[0];       //배열의 처음 값으로 시작
		
		int max = Integer.MIN_VALUE;
		int min = Integer.MAX_VALUE; 
		int[] numbers = {38,94,16,3,76,94,82,47,59,8};
		
		for (int i = 0; i<numbers.length; i++) {
			if(numbers[i] > max) {
				max = numbers[i];
				
			}
			if (numbers[i] < min) {
				min = numbers[i];
			}
		}
		System.out.println("최댓값 : "+max);
		System.out.println("최솟값 : " + min);
	}

}
