from day03.ooptest01 import Animal

ani = Animal()

print(ani.age)
ani.getOld()
print(ani.age)