package review_hyorim;

import java.util.Scanner;

public class chapter04homework_03 {
	public static void main(String [] args) {
		
		// 5과목의 점수를 입력받아 평균을 구하는 프로그램
		//프로그래밍기초, 데이터베이스, 화면 구현,
		//애플리케이션 구현, 머신러닝. 이렇게 총 5과목
		//총점, 평균, 학점 구하기
		//평균은 소수 둘째자리까지
		//학점은 90점 이상이면 A, 80점 이상 90점 미만이면 B
		//70점 이상 80점 미만이면 C, 60점 이상 70점 미만이면 D
		//60점 미만이면 F
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("점수를 입력하세요.");
		System.out.println("프로그래밍 기초 : ");
		
		int programming;
		programming = scanner.nextInt();
		
		System.out.println("데이터베이스 : ");
		
		int database;
		database = scanner.nextInt();
		
		System.out.println("화면 구현 : ");
		
		int picture;
		picture = scanner.nextInt();
		
		System.out.println("애플리케이션 구현 : ");
		
		int application;
		application = scanner.nextInt();
		
		System.out.println("머신 러닝 : ");
		
		int machine;
		machine = scanner.nextInt();
		
		double all =(programming + database + picture + application + machine) ;{
			System.out.println("총점 : " + all);
		
		double average = (all/(5.0)); {
			System.out.println("평균 : " + average);
		
		
		if (average >=90){
			System.out.println("학점은 A입니다.");
		}else if (average>=80){
			System.out.println("학점은 B입니다.");
		}else if (average>=70) {
			System.out.println("학점은 C입니다.");
		}else if(average>=60) {
			System.out.println("학점은 D입니다.");
		}else{
			System.out.println("학점은 F입니다.");
		
			scanner.close();
		}
		
		
		}	
		}
	}

}
