import Animal from './main4.js';

var a = new Animal();
console.log("a.age",a.age);
a.getOld();
console.log("a.age",a.age);