import pymysql

conn = pymysql.connect(host='localhost', user='root', password='python',
                       db='python', port=3305, charset='utf8')

e_id = '5'

cursor = conn.cursor()

sql = f"""
    delete from emp
    where
        e_id= '{e_id}'
"""

print("sql",sql)
cnt = cursor.execute(sql)
print("cnt",cnt)

conn.commit()
cursor.close()
conn.close()