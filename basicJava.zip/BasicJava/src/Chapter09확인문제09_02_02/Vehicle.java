package Chapter09확인문제09_02_02;

public interface Vehicle {
	public void run();

}
