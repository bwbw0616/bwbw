package JavaTest20220304;

public class Number03Foo {
	int a;

	public Number03Foo(int a) {
		this.a = a;
	}

	public int getA() {
		return a;
	}
}
