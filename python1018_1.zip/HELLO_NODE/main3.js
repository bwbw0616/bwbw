function add(a,b){
	return a+b;
}
function minus(a,b){
	return a-b;
}
function multiply(a,b){
	return a*b;
}
function divide(a,b){
	return a/b;
}

var sum = add(1,5);
var min = minus(1,5);
var mul = multiply(1,5);
var div = divide(1,5);

console.log("sum",sum);
console.log("min",min);
console.log("mul",mul);
console.log("div",div);

