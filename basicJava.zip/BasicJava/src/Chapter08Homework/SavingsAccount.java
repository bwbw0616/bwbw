package Chapter08Homework;

public class SavingsAccount extends BankAccount {
	private double interestRate;

	public SavingsAccount(int balance, double interestRate) {
		super(balance);
		this.interestRate = interestRate;
	}

	public void updateBalance(int period) { 
		this.balance = (int) (balance * interestRate * period) + balance;
	}

	@Override
	public String getAccountType() {
		return "저축예금";

	}

}