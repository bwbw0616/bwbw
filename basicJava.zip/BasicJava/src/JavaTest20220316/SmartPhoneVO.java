package JavaTest20220316;

public class SmartPhoneVO {
	private String menufacturer;
	private String model;
	private int capacity;

	public SmartPhoneVO() {
	}

	public SmartPhoneVO(String menufacturer, String model, int capacity) {
		this.menufacturer = menufacturer;
		this.model = model;
		this.capacity = capacity;
	}

	public String getMenufacturer() {
		return menufacturer;
	}

	public void setMenufacturer(String menufacturer) {
		this.menufacturer = menufacturer;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
}
