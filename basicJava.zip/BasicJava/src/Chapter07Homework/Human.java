package Chapter07Homework;

public class Human {
	// 'is a' vs 'has a'
	// 상속 vs 포함
	private String name;	
	private int age;
	
	public Human(String name, int age) {
		this.name = name;
		this.age = age;		
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	
	
	public int getAge() {
		return age;
	}
	
	
	public String toString() {
		return String.format("이름" + name + ", 나이 : " + age);
	}

}
