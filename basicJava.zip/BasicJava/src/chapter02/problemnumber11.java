package chapter02;

import java.util.Scanner;

public class problemnumber11 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("아이디:");
		String name = scanner.nextLine();
		
		System.out.println("패스워드:");
		String strPassword = scanner.nextLine();
		int password = Integer.parseInt(strPassword);
		
		if   ("java".equals(name))    {    //name.equals("java"):좋지 않은 표현 방법
			if  (password==123456)        {
				System.out.println("로그인 성공");
				}else {
					System.out.println("로그인 실패 : 패스워드가 틀림");
				}
		} else {
			System.out.println("로그인 실패:아이디가 존재하지 않음");
		}
	}
}
	