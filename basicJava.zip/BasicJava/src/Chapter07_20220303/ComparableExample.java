package Chapter07_20220303;

import java.util.Arrays;

public class ComparableExample {
	public static void main(String[] args) {
		
		Student[] students = {
                new Student("유지형", 24, "컴퓨터"),
                new Student("고혜인", 23, "음악"),
                new Student("박채록", 22, "미술"),
                new Student("고정현", 21, "국어"),
                new Student("심민경", 21, "컴퓨터"),
                new Student("정아영", 22, "수학"),
                new Student("김규진", 20, "영어"),
                new Student("서효림", 20, "수학"),
        };
        Arrays.sort(students);
        for (Student student : students) {
                System.out.println(student);
        }
	}
}	