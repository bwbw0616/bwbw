package application;

public class GugudanTest {
	public static void main(String[] args) {
//		for(int i = 2; i < 10; i++) {
//			for(int j = 1; j < 10; j++) {
//				System.out.println(i + " * " + j + " = " + i * j);
//			}
//			System.out.println();
//		}	
	
	showDan(8);
	showDan(9);
	showDan(3);
	showDan(2);
	showDan(6);
	showDan(7);
	showDan(5);
	showDan(4);
	}
	public static void showDan(int dan) {
		System.out.println(dan + "*" + 1 + "=" + (dan * 1));
		System.out.println(dan + "*" + 2 + "=" + (dan * 2));
		System.out.println(dan + "*" + 3 + "=" + (dan * 3));
		System.out.println(dan + "*" + 4 + "=" + (dan * 4));
		System.out.println(dan + "*" + 5 + "=" + (dan * 5));
		System.out.println(dan + "*" + 6 + "=" + (dan * 6));
		System.out.println(dan + "*" + 7 + "=" + (dan * 7));
		System.out.println(dan + "*" + 8 + "=" + (dan * 8));
		System.out.println(dan + "*" + 9 + "=" + (dan * 9));
		System.out.println();
	}
}