package day02;

public class Lee extends Xi{
	int money = 100;
	
	public void galguda(int power) {
		money += power;
	}
}
