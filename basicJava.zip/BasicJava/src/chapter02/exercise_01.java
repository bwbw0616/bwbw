package chapter02;

import java.util.Scanner;

public class exercise_01 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("가로의 길이는?(단위:m)");
		float var1 = scanner.nextFloat();

		System.out.print("세로의 길이는(단위:m)?");
		float var2 = scanner.nextFloat();

		float result = (var1 * var2);
		System.out.println("넓이: " + result);
		float result2 = 2 * (var1 + var2);
		System.out.println("둘레:" + result2);
		scanner.close();
	}

}
