package chapter04;

import java.util.Random;
import java.util.Scanner;

public class ExampleProblem05 {
	public static void main(String[] args) {
	
		
		Random random = new Random();
		Scanner scanner = new Scanner(System.in);
		
		int a;
		int b = (int)(Math.random() * 100) + 1;
		while (true) {	
	
		System.out.println("1 부터 100 사이의 정수 중 하나를 선택하세요");
		a = scanner.nextInt();
		if (b>a){
			System.out.println("정답은 더 큰 수입니다.");
		}else if(a>b){
			System.out.println("정답은 더 작은 수입니다.");
		}else {
			System.out.println("정답입니다.게임을 종료합니다.");
			break;
		}
	}
		scanner.close();
	}

}
