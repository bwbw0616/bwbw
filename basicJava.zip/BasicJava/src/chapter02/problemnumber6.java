package chapter02;

public class problemnumber6 {
	public static void main(String[] args) {
		int value = 356;
		System.out.println(value/100*100);
	}

}
