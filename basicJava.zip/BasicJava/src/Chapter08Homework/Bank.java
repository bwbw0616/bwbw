package Chapter08Homework;

public class Bank {
	private Customer[] customers;
	private int numberOfCustomers;

	public Bank() {

		customers = new Customer[10];
		numberOfCustomers = 0;

	}

	public void addCustomer(Customer customer) {
		if (numberOfCustomers < 10) {
			customers[numberOfCustomers] = customer;
			numberOfCustomers++;

		}

	}

	public int getNumberOfCustomers() {
		return numberOfCustomers;

	}

	public Customer[] getCustomers() {
		return customers;

	}

	public Customer getCustomer(int num) {
		return customers[num];

	}

}
