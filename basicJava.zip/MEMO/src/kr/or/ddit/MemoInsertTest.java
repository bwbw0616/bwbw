package kr.or.ddit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

class MemoInsertTest {
	MemoDAO dao = MemoDAO.getInstance();

//	@Test
	void test() throws Exception {
		// TDD (Test Driven Development)
		int insertMemo = dao.insertMemo(new MemoVO("두번째 글","벌써 11시"));
		
		assertEquals(1, insertMemo);
		
//		fail("Not yet implemented");
	}
	@Test
	void selectMemoTest() throws Exception{
		List<MemoVO> list = dao.getMemoList("");
		assertEquals(12, list.size());	
	}

}
