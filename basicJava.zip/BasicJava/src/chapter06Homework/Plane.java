package chapter06Homework;

public class Plane {
	
	private String manufacture;
	private String model;
	private int maxNumberOfPassengers;
	private static int numberOfplanes;    //static private도 상관없음 하지만 일반적으로 private static으로 더 많이 사용
	
	//이 생성자는 Plane입니다.
	
	public Plane() {
		manufacture = "";
		model = "";
		maxNumberOfPassengers = 0;
		numberOfplanes++;
		
	}
	Plane(String manufacture, String model, int maxNumberOfPassengers) {
		this();
		this.manufacture = manufacture;
		this.model = model;
		this.maxNumberOfPassengers = maxNumberOfPassengers;
		
	}
	
	
	public String getManufacture() {
		return manufacture;
	}
	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
		
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
		
	}
	public int getMaxNumberOfPassengers() {
		return maxNumberOfPassengers;
		
		
	}
	public void setMaxNumberOfPassengers(int maxNumberOfPassengers) {
		if(maxNumberOfPassengers<0) {
			this.maxNumberOfPassengers=0;
		}else {
			this.maxNumberOfPassengers=maxNumberOfPassengers;         // 잘못된 값을 0으로 변환
		}
	}
	public static int getNumberOfPlanes() {
		return numberOfplanes;
	}
	

}
