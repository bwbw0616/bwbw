package homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RaceHorse {

	public static void main(String[] args) {

		List<Horse> myhorse = new ArrayList<>();// 정렬을 해줘야 해서 list로 넣어줌
		myhorse.add(new Horse("말 1"));
		myhorse.add(new Horse("말 2"));
		myhorse.add(new Horse("말 3"));
		myhorse.add(new Horse("말 4"));
		myhorse.add(new Horse("말 5"));
		myhorse.add(new Horse("말 6"));
		myhorse.add(new Horse("말 7"));
		myhorse.add(new Horse("말 8"));
		myhorse.add(new Horse("말 9"));
		myhorse.add(new Horse("말 10"));

		for (Horse horse : myhorse) { // myhorse를 horse에 넣고 시작
			horse.start();
		}

		while (true) {// 현재 달리고 있는 위치
			for (int i = 0; i < myhorse.size(); i++) {// 말의 개수만큼
				System.out.print(myhorse.get(i).name + " : ");
				for (int j = 1; j <= 50; j++) {
					if (myhorse.get(i).place == j) {// i번째 위치가 j와 같으면
						System.out.print(">");// >로 변환
						continue;// 하고 첫번째 for 문으로 올라가서
					}
					System.out.print("-");// -를 출력
				}
				System.out.println();
			}
			try {
				Thread.sleep(500);// 0.5초의 시간 딜레이
			} catch (InterruptedException e) {
			}

			int exitCnt = 0;// 스레드 갯수
			for (int i = 0; i < myhorse.size(); i++) {
				if (myhorse.get(i).getState() == Thread.State.TERMINATED) {// 스레드의 상태가 종료되었을때
					exitCnt++;// 스레드의 갯수를 증가시킴
				}
			}
			if (exitCnt == 10) {// 10번말이 모두 끝났을때는 끝남
				break;
			}
			System.out.println("\n=========================================================\n");
			// 끝나지 않았으면 출력
		}

		System.out.println();
		Collections.sort(myhorse);// 정렬한것
		System.out.println("===경기결과===");
		for (Horse h : myhorse) {// 리스트를 h에 넣고
			System.out.println(h);// h출력
		}
	}

}

class Horse extends Thread implements Comparable<Horse> {
	public static int setRank = 1;
	public String name;
	public int rank;
	public int place = 1;

	public Horse(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			try {
				Thread.sleep((int) (Math.random() * 500));
			} catch (InterruptedException e) {

			}
			if (place < 50) {   // 장소가 50까지 가야 됨
				place++;
			}
		}
		System.out.println(name + "경기 완료");
		rank = setRank++;
		System.out.println("등수는 " + rank);
	}

	@Override
	public int compareTo(Horse h) {
		return Integer.compare(rank, h.rank);   // 비교해서 정렬
	}

	@Override
	public String toString() {
		return name + " : " + rank + "등 ";

	}

}