package chapter06;

public class BoardExample {
	public static void main(String[] args) {
		Board board1 = new Board("제목", "내용");
		Board board2 = new Board("제목", "내용", "홍길동");
		Board board3 = new Board("제목", "내용", "홍길동", "2022-02-21");		
		Board board4 = new Board("제목", "내용", "홍길동","2022-02-21",0);		
		
		
	}

}
