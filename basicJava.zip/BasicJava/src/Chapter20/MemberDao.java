package Chapter20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import oracle.jdbc.driver.OracleDriver;

public class MemberDao {
	// CRUD(Create Read Update Delete): insert select update delete
	// 조회 (목록 상세)
	public List<MemberVO> getMembers() throws Exception{
		/*
		 * JDBC(Java DataBase Connectivity) 자바와 DBMS를 연결 PDO(Php Data Objects)와 비슷
		 * 
		 * Driver가 필요 Oracle JDBC Driver (ojdbc-숫자.jar) jar: Java ARchive tar: Tape
		 * ARchive war: Web Application ARchive
		 */
		new OracleDriver();
		/*
		 * JDBC 순서 
		 * 0. 드라이버 로딩 
		 * 1. 드라이버를 통해 DB 접속(Connection)(DB서버 주소, 사용다 계정, 비밀번호 필요) 
		 * 2. * 쿼리문 작성할 객체 생성(Statement)
		 * 3. 쿼리(질의)문 작성한 뒤 실행 
		 * 4. 실행 결과를 돌려받음(ResultSet: select에만 필요) 
		 * 5. 자원 반납
		 */

		// 드라이버 로딩
		Class.forName("oracle.jdbc.driver.OracleDriver");
		// 드라이버를 통해 DB 접속
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "SHR98", "java");
		// 쿼리문 작성 객체 생성
		Statement statement = connection.createStatement();
		// 쿼리문 작성
		String sql = "select mem_id, mem_name, mem_hp, mem_mail from member";
		// 쿼리문 실행 후 결과 받기
		ResultSet resultSet = statement.executeQuery(sql);
		
		List<MemberVO> list = new ArrayList<MemberVO>();
		
		while (resultSet.next()) {
			String memID = resultSet.getString("mem_id");
			String memName = resultSet.getString("mem_name");
			String memHp = resultSet.getString("mem_hp");
			String memMail = resultSet.getString("mem_mail");
			list.add(new MemberVO(memID, memName, memHp, memMail));
			
		}
		// 자원반납
		resultSet.close();
		statement.close();
		connection.close();	
		return list;
	}	
	//reactive => reactive.java(RX Java), reactive android(RX Android), reactive swift
	//spring webflux
	//조회 (상세)
	public MemberVO getMember(String id) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "SHR98", "java");
		Statement statement = connection.createStatement();
		String sql = "select mem_id, mem_name, mem_hp, mem_mail, mem_add1, mem_add2, mem_bir, mem_job from member where mem_id = '" + id + "'";
		ResultSet resultSet = statement.executeQuery(sql);
		MemberVO vo = null;
		if(resultSet.next()) {
			String memID = resultSet.getString("mem_id");
			String memName = resultSet.getString("mem_name");
			String memHp = resultSet.getString("mem_hp");
			String memMail = resultSet.getString("mem_mail");
			String memAdd1= resultSet.getString("mem_add1");
			String memAdd2 = resultSet.getString("mem_add2");
			Date memBir = resultSet.getDate("mem_bir");
			String memJob = resultSet.getString("mem_job");
			vo = new MemberVO(memID, memName, memHp, memMail, memAdd1, memAdd2, memBir, memJob);		
		}
		resultSet.close();
		statement.close();
		connection.close();
		return vo;
	}
	//등록
	public void insertMember(MemberVO vo) {
		
	}
	public int updateMember(MemberVO vo) throws Exception{
//		Class.forName("oracle.jdbc.driver.OracleDriver");         //오타 확률이 상대적으로 높음
		
		DriverManager.registerDriver(new OracleDriver());
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "SHR98", "java");
		
		connection.setAutoCommit(false);
		
		String sql = "update member set mem_job = ? where mem_id = ?";		
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, vo.getMemJob());
		statement.setString(2, vo.getMemId());
		statement.setString(1, vo.getMemJob());
		statement.setString(2, vo.getMemId());
		
		//업데이트를 실행하고 난 결과: 업데이트 한 row 갯수
		int executeUpdate = statement.executeUpdate();
		
	    statement.close();
	    connection.close();
	    
	    return executeUpdate;
	}
	public void deleteMember(String id) {
		
	}
}
