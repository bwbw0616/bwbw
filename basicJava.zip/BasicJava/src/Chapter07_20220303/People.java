package Chapter07_20220303;

public class People {
	String name;
	String ssn;
	public People(String name, String ssn) {
		this.name = name;
		this.ssn = ssn;
	}

}
