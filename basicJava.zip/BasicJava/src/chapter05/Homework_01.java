package chapter05;

public class Homework_01 {
	public static void main(String[] args) {
		
		//최댓값 & 최솟값 구하기
		// {38, 94, 16, 3, 76, 94, 82, 47, 59, 8}
		int sum = 0;
		
		int[] scores =   {38, 94, 16, 3, 76, 94, 82, 47, 59, 8};
		
		int max = scores[0];
		int min = scores[0];
		for(int i = 0; i < scores.length; i++) {
			   if(max < scores[i]) {
				   max = scores[i];
			   
			}
			   if(min > scores[i]) {
				   min = scores[i];
			   }
		}
		System.out.println("최댓값 : " + max);
		
		System.out.println("최솟값 : " + min);
		
		
			
		}
		

		
	}


