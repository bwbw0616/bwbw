package kr.or.ddit;

public class MemoController {

}
