package com.ddit.java.ticketingapp.home;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.member.MemberDAO;
import com.ddit.java.ticketingapp.member.MemberVO;
import com.ddit.java.ticketingapp.util.ScanUtil;
import com.ddit.java.ticketingapp.view.View;

public class HomeService {
	private static HomeService instance = new HomeService();

	public static HomeService getInstance() {
		return instance;
	}

	private HomeService() {
	}

	public void login() {
		System.out.println("\t\t\t       << 로그인 >>");
		System.out.print("\t\t\t      ID: ");
		String id = ScanUtil.nextLine();
		System.out.print("\t\t\t      PASSWORD: ");
		String password = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");

		MemberDAO dao = MemberDAO.getInstance();

		Map<String, Object> member = dao.selectUser(id, password);

		if(member != null) {
			MemberVO.getInstance().setMember(member);
			System.out.println("\n\t\t\t          로그인에 성공했습니다.");
			System.out.println("\t\t\t          ※" + member.get("MEM_NAME") + " 님 어서오세요. ※\n");
			System.out.println("------------------------------------------------------------------------");
			View.getInstance().showMainMenu();
		}
		else {
			System.out.println("\n\t\t           ※ 아이디 혹은 비밀번호가 올바르지 않습니다.\n");
			System.out.println("------------------------------------------------------------------------");
			View.getInstance().showHomeMenu();
		}
	}

	// 회원가입
	public void join() {
		List<Object> list = new ArrayList<>();
		System.out.println("\t\t\t      << 회원가입 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t      ID: ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      PASSWORD: ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      이름: ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      주민번호 앞자리(6): ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      주민번호 뒷자리(7): ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      전화번호: ");
		list.add(ScanUtil.nextLine());
		System.out.print("\t\t      주소: ");
		list.add(ScanUtil.nextLine());
		System.out.println("------------------------------------------------------------------------");

		MemberDAO dao = MemberDAO.getInstance();
		int result = dao.insertUser(list);
		if(result > 0) {
			System.out.println("\n\t\t            ※ " + list.get(2) + " 회원님의 회원가입을 축하드립니다.");
			System.out.println("\t\t               ※ 홈 메뉴에서 로그인을 진행해 주세요.\n");
			View.getInstance().showHomeMenu();
		}
		else {
			System.out.println("\n\t\t\t        회원가입에 실패하였습니다.\n");
			System.out.println("------------------------------------------------------------------------");
			View.getInstance().showHomeMenu();
		}
	}
}
