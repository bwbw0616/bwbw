# 1 ~ 9 까지의 수 중에서 랜덤으로 중복 없이 3개를 출력하시오.
import random
arr9 = [1,2,3,4,5,6,7,8,9]

for i in range(10):
    rnd = int(random.random()*9)
    a = arr9[rnd]
    b = arr9[0]
    arr9[0]=a
    arr9[rnd]=b

print(arr9[0],arr9[1],arr9[2])