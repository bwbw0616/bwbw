class Xi:
    def __init__(self):
        self.cnt_nuclear = 100
    def command(self):
        self.cnt_nuclear += 1
    
class Lee:
    def __init__(self):
        self.money = 100
    def galguda(self,power):
        self.money += power
        
class Putin:
    def __init__(self):
        self.army_power = 100
    def goToUkraine(self):
        self.army_power -= 1

class Shin(Xi, Lee, Putin):
    def __init__(self):
        # super().__init__()
        Xi.__init__(self)
        Lee.__init__(self)
        Putin.__init__(self)

if __name__ == '__main__':
    shin = Shin()
    print(shin.cnt_nuclear)
    print(shin.money)
    print(shin.army_power)
    shin.command()
    shin.galguda(5)
    shin.goToUkraine()
    print(shin.cnt_nuclear)
    print(shin.money)
    print(shin.army_power)