package chapter05;

import java.util.Random;
import java.util.Scanner;

public class Homework03_모범답안 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("가위바위보 게임");
	    System.out.println("게이머:");
	    String player = scanner.next();
	    Random random = new Random();
	    
	    int ranNum = random.nextInt(3);
	    String[] rps = {"가위", "바위", "보"};
	    String ai = rps[ranNum];
	    String result = "";
	   if (player.equals(ai)) {
	    	result = "비김";
	    }else if (ai.equals("가위")&&player.equals("바위")
	    		   ||ai.equals("바위")&&player.equals("보")
	    		   ||ai.equals("보")&&player.equals("가위")) {
	    	result = "게이머 승리!";
	    }else{
	    	result = "인공지능 컴퓨터 승리!";
	    }
	   System.out.println("컴퓨터:"+ai);
	   System.out.println("결과:"+result);
		
	}

}
