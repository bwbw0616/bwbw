package com.ddit.java.ticketingapp.view;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.ddit.java.ticketingapp.category.CategoryDAO;
import com.ddit.java.ticketingapp.concert.ConcertDAO;
import com.ddit.java.ticketingapp.util.FormatUtil;
import com.ddit.java.ticketingapp.util.ScanUtil;

public class ViewTemp {
	public static void main(String[] args) {
		System.out.print("\t\t\t\t입력 >> ");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t\t<< 메인 >>");
		
//		<< TICKET SERVICE >> 
//		--------------------------------------------------------------
//		공연명: 씨어터 이문세	 날짜: 2022-04-08
//		주연: 이문세		 장소명: 충무아트센터
//		좌석번호: V1
//		가격: 115600
//		--------------------------------------------------------------
//		예매하시겠습니까?(Y/N) >> 
//		
		
		
		List<Map<String, Object>> list = ConcertDAO.getInstance().selectConcertWithCategory("뮤지컬");

	}

}
