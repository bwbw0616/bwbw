package kr.or.ddit.board.service;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.dao.BoardDAO;
import kr.or.ddit.board.dao.BoardDAOImpl;
import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.SqlMapClientFactory;

public class BoardServiceImpl implements BoardService {
	
	private static BoardService boardService; 
	
	private SqlMapClient smc;
	
	private BoardDAO boardDAO;
	
	private BoardServiceImpl() {
		boardDAO = BoardDAOImpl.getInstance();
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static BoardService getInstance() {
		
		if(boardService == null) {
			boardService = new BoardServiceImpl();
		}
		
		return boardService;
	}
	
	@Override
	public int insertBoard(BoardVO mv) {

		int cnt = 0;
		
		try {
			smc.startTransaction();		//트랜잭션 시작
			
			cnt = boardDAO.insertBoard(smc, mv);
			
			smc.commitTransaction();		//커밋
		} catch (SQLException e) {
			try {
				smc.endTransaction(); 		//롤백
			}catch(SQLException e1) {
				e1.printStackTrace();
			}
		}
		
		return cnt;
	}

	@Override
	public int updateBoard(BoardVO mv) {
		return boardDAO.updateBoard(smc,mv);
	}

	@Override
	public int deleteBoard(String boardId) {
		return boardDAO.deleteBoard(smc,boardId);
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		return boardDAO.getAllBoardList(smc);
	}

	@Override
	public boolean checkBoard(String boardId) {
		return boardDAO.checkBoard(smc,boardId);
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO mv) {
		
		return boardDAO.searchBoardList(smc,mv);
	}

}
