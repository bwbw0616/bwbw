package com.ddit.java.ticketingapp.mypage;

import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.member.MemberVO;
import com.ddit.java.ticketingapp.view.View;

public class MyPageService {
	private static MyPageService instance;

	private MyPageService() {
	}

	public static MyPageService getInstance() {
		if (instance == null) {
			instance = new MyPageService();
		}
		return instance;
	}

	MyPageDAO myPageDAO = MyPageDAO.getInstance();

	public Map<String, Object> showMember(String id) {
		return myPageDAO.showMember(id);
	}

	// 티켓정보출력
	public List<Map<String, Object>> showTicket(String id) {
		return myPageDAO.showTicket(id);
	}

	// 회원정보변경

	public int modifyMember(int enter, String newMem, MemberVO memberVO) {
		switch (enter) {
		case 1:
			memberVO.setMemName(newMem);
			return myPageDAO.modifyName(memberVO);
		case 2:
			memberVO.setMemPassword(newMem);
			return myPageDAO.modifyPassword(memberVO);
		case 3:
			memberVO.setMemAddr(newMem);
			return myPageDAO.modifyAddr(memberVO);
		case 4:
			memberVO.setMemHp(newMem);
			return myPageDAO.modifyHp(memberVO);
		default:
			return 0;
		}
	}

	public List<Map<String, Object>> showTicketId(String id) {
		return myPageDAO.showTicketId(id);
	}
	
	public Map<String, Object> showTicketingId(Object ticketId){	
		return myPageDAO.showTicketingId(ticketId);
	}
	
	public Map<String, Object> showPayMethod(Object ticketingId){
		return myPageDAO.showPayMethod(ticketingId);
	}
	
	public int insertRefund(Object ticketingId) {
		Map<String, Object> payMethod = showPayMethod(ticketingId);
		return myPageDAO.insertRefund(ticketingId, payMethod.get("PAYMETHOD_NAME"));
	}
}
