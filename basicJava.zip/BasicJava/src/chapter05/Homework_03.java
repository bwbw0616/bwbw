package chapter05;

import java.util.Random;
import java.util.Scanner;

public class Homework_03 {
	public static void main(String[] args) {
		//인공지능 컴퓨터와 게이머(사람)가
		//가위바위보 게임을 할 수 있도록
		//프로그램을 작성하시오.
		Scanner scanner = new Scanner(System.in);		
		System.out.print("가위, 바위, 보를 입력하세요 : ");
		String player = scanner.nextLine();
		int player1 = 0;
		String com = " ";
		int com1 = (int)(Math.random()*3)+1;
		if(com1==1) {
		com = "가위";
		}else if(com1==2) {
		com = "바위";
		}else if(com1==3) {
		com = "보";
		}
		if(player.equals("가위")) {

		if(player1-com1==0) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("무승부입니다.");
		
		}else if(player1-com1==-1 || player1-com1==2) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("컴퓨터 승리");
		
		}else if(player1-com1==-2||player1-com1==1) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("게이머 승리");
		}
		
		}else if(player.equals("바위")) {

		if(player1==com1) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("무승부입니다.");
		
		}else if(player1-com1==-1 || player1-com1==2) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("컴퓨터 승리");

		

		}else if(player1-com1==-2||player1-com1==1) {
		  System.out.println("게이머 : "+player);
	      System.out.println("컴퓨터 : "+com);
		  System.out.println("게이머 승리");
		}

		
		}else if(player.equals("보")) {

		if(player1==com1) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("무승부입니다.");
		

		}else if(player1-com1==-1 || player1-com1==2) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("컴퓨터 승리");

		}else if(player1-com1==-2||player1-com1==1) {
		  System.out.println("게이머 : "+player);
		  System.out.println("컴퓨터 : "+com);
		  System.out.println("게이머 승리");
		
		

		}
		}
	}
}