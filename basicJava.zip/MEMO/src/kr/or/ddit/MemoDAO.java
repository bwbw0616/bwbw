package kr.or.ddit;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.driver.OracleDriver;

// 직접 데이터베이스 접속

public class MemoDAO {
	
	private static MemoDAO instance = new MemoDAO();
	private MemoDAO() {
	}	
	public static MemoDAO getInstance() {
		return instance;		
	}
	
	public List<MemoVO> getMemoList(String searchWord) throws Exception {
		DriverManager.registerDriver(new OracleDriver());
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SHR98", "java");
		String sql = "";
		sql += " SELECT ";
		sql += "     no, ";
		sql += "     title, ";
		sql += "     contents, ";
		sql += "     create_date, ";
		sql += "     modify_date ";
		sql += " FROM ";
		sql += "     memo ";
		sql += " WHERE ";
		sql += "     title LIKE '%' || ? || '%' ";
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, searchWord);
		List<MemoVO> list = new ArrayList<MemoVO>();
		ResultSet resultSet =  statement.executeQuery();
		while(resultSet.next()) {
			long no = resultSet.getLong("no");
			String title = resultSet.getString("title");
			String contents = resultSet.getString("contents");
			Date createDate = resultSet.getDate("create_date");
			Date modifyDate = resultSet.getDate("modify_date");
			list.add(new MemoVO(no, title, contents, createDate, modifyDate));
		}
		resultSet.close();
		statement.close();
		connection.close();
		return list;

	}

	public MemoVO getMemo(long no) {
		return null;
	}

	public int insertMemo(MemoVO vo) throws Exception {
		DriverManager.registerDriver(new OracleDriver());
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SHR98", "java");
//		String sql = "insert into memo (no, title, contents) values (SEQ_MEMO.nextval, ?, ?)";
		String sql = "";
		sql += " INSERT INTO memo (";
		sql += "     no,";
		sql += "     title,";
		sql += "     contents";
		sql += " ) VALUES (";
		sql += "     seq_memo.NEXTVAL,";
		sql += "     ?,";
		sql += "     ?";
		sql += " )";

		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, vo.getTitle());
		statement.setString(2, vo.getContents());
		int executeInsert = statement.executeUpdate();
		statement.close();
		connection.close();

		return executeInsert;

	}

	public int updateMemo(MemoVO vo) {
		return 0;
	}

	public int deleteMemo(long no) {
		return 0;
	}

}