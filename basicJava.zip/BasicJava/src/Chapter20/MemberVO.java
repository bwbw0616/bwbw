package Chapter20;

import java.sql.Date;

// VO(Value Object): 값 저장 객체
// DTO(Data Transfer Object): 값 전달 객체

public class MemberVO {
	private String memId;
	private String memName;
	private String memHp;
	private String memMail;
	private String memAdd1;
	private String memAdd2;
	private Date memBir;
	private String memJob;
	public MemberVO() {
	}
	
	public MemberVO(String memId, String memName, String memHp, String memMail) {
		this.memId = memId;
		this.memName = memName;
		this.memHp = memHp;
		this.memMail = memMail;
	}

	public MemberVO(String memId, String memName, String memHp, String memMail, String memAdd1, String memAdd2,
			Date memBir, String memJob) {
		this.memId = memId;
		this.memName = memName;
		this.memHp = memHp;
		this.memMail = memMail;
		this.memAdd1 = memAdd1;
		this.memAdd2 = memAdd2;
		this.memBir = memBir;
		this.memJob = memJob;
	}
	
	public String getMemId() {
		return memId;
	}

	public void setMemId(String memId) {
		this.memId = memId;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}

	public String getMemHp() {
		return memHp;
	}

	public void setMemHp(String memHp) {
		this.memHp = memHp;
	}

	public String getMemMail() {
		return memMail;
	}

	public void setMemMail(String memMail) {
		this.memMail = memMail;
	}

	public String getMemAdd1() {
		return memAdd1;
	}

	public void setMemAdd1(String memAdd1) {
		this.memAdd1 = memAdd1;
	}

	public String getMemAdd2() {
		return memAdd2;
	}

	public void setMemAdd2(String memAdd2) {
		this.memAdd2 = memAdd2;
	}

	public Date getMemBir() {
		return memBir;
	}

	public void setMemBir(Date memBir) {
		this.memBir = memBir;
	}

	public String getMemJob() {
		return memJob;
	}

	public void setMemJob(String memJob) {
		this.memJob = memJob;
	}
}
