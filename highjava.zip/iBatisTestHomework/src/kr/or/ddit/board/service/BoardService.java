package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;


public interface BoardService {
	
	
	public int insertBoard(BoardVO mv);
	
	
	public int updateBoard(BoardVO mv);
	
	
	public int deleteBoard(String memId);
	
	
	public List<BoardVO> getAllBoardList();
	
	
	public boolean checkBoard(String memId);
	
	
	public List<BoardVO> searchBoardList(BoardVO mv);
}
