package Chapter08;

public interface RemoteControl {
	int MAX_VOLUME = 10;   //public (static final) int MAX_VOLUME = 10;
	int MIN_VOLUME = 10;
	void turnOn();
	void turnOff();
	void setVolume(int volume);
	
	
	
	//public int MAX_VOLUME = 10;  
	//public int MIN_VOLUME = 10;
	//public void turnOn();
	//public void turnOff();
	//public void setVolume(int volume); 
	      //->public 생략 가능

}
