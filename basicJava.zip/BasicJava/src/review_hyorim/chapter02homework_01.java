package review_hyorim;

import java.util.Scanner;

public class chapter02homework_01 {
	public static void main(String[] args) {
		//직사각형의 가로, 세로의 길이를 입력받아 
		//넓이와 둘레를 출력하는 프로그램
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("가로의 길이는? (단위 : m)");
		double width = scanner.nextDouble();
		
		System.out.println("세로의 길이는? (단위 : m)");
		double height = scanner.nextDouble();
		
		
		double area = (width * height);
		System.out.println("직사각형의 넓이 : (단위 : m^2)" + area);
		
		double perimeter = (width + height) * 2;
		System.out.println("직사각형의 둘레 : (단위 : m)" + perimeter);
		
		scanner.close();
	}

}
