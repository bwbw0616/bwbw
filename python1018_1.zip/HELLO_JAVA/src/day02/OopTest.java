package day02;

public class OopTest {
	public static void main(String[] args) {
		Cat cat = new Cat();
		System.out.println(cat.age);
		System.out.println(cat.ssagaji);
		cat.getOld();
		cat.onepunch();
		System.out.println(cat.age);
		System.out.println(cat.ssagaji);
	}
}
