package homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentExample {
	public static void main(String[] args) {
		// 20220324 과제
		List<Student> list = new ArrayList<Student>();
		list.add(new Student(20100124, "강호동", 85, 45, 70));
		list.add(new Student(20081116, "김C", 95, 80, 80));
		list.add(new Student(20090118, "이수근", 100, 60, 50));
		list.add(new Student(20100314, "언지원", 70, 90, 45));
		list.add(new Student(20100117, "MC몽", 80, 40, 50));
		list.add(new Student(20100103, "김종민", 95, 95, 90));
		list.add(new Student(20091101, "이승기", 95, 90, 95));
		for(Student jongmin : list) {
			jongmin.setRank(1);
            for(Student seungki : list) {
                if(jongmin.getTotal() < seungki.getTotal()) {
                	jongmin.setRank(jongmin.getRank() + 1);
                }
            }
        }
		System.out.println(list); // 정렬 전

		Collections.sort(list);
		System.out.println(list); // 학번 오름차순

		Collections.sort(list, new twoDaysOneNight());
		System.out.println(list); // 총점 역순

	}
}

class twoDaysOneNight implements Comparator<Student> {
	@Override
	public int compare(Student sugeun, Student jiwon) {
		if (sugeun.getTotal() > jiwon.getTotal()) {
			return sugeun.getTotal() * -1;
		} else if (sugeun.getTotal() == jiwon.getTotal()) {
			return sugeun.getOneNightTwodays() * -1;        // 등수순 & 학번 내림차순
		}
		return 0;
	}

}