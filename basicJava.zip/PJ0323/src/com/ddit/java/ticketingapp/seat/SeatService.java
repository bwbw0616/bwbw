package com.ddit.java.ticketingapp.seat;

public class SeatService {
	private static SeatService instance;
	private SeatService() {
	}
	public static SeatService getInstance() {
		if(instance == null) {
			instance = new SeatService();
		}
		return instance;
	}
	
	public void showSeatLeftAll() {
		System.out.println("\t\t               << 좌석 선택 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t           1 2 3 4 5 6 7 8 9 10");
		SeatDAO dao = SeatDAO.getInstance();
		dao.showSeatLeft("V", 2);
		dao.showSeatLeft("R", 2);
		dao.showSeatLeft("S", 2);
		dao.showSeatLeft("A", 3);
	}
}
