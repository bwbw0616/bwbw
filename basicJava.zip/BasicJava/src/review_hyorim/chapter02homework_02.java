package review_hyorim;

import java.util.Scanner;

public class chapter02homework_02 {
	public static void main(String [] args) {
		//프록시마 센타우리(Proxima Centauri)는 
		//지구로 부터 40 * 10^12km 떨어져 있는
		//태양 다음으로 지구와 가까운 별
		//빛의 속도는 300,000km/s
		//40*10^12km = 40e12km
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("빛의 속도는? 단위 : km/s");
		float light = scanner.nextFloat();
		System.out.println("프록시마 센타우리에서 지구까지의 거리는? 단위:km");       
		float time = scanner.nextFloat();       
		  System.out.println("걸리는 시간은? 단위 : 광년");      
		double distance = (double) (time)/(light)/60/60/24/365;
		System.out.println(distance);

		scanner.close();
	}

}
