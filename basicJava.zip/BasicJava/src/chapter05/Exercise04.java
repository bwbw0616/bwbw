package chapter05;

public class Exercise04 {
	public static void main (String[] args) {
		//배열의 최대값 구하기
		int max=0;
		int[] array = {1,5,3,8,2};
		
		if (array[0] > max) {
			max = array[0];
		}
		if (array[1] > max) {
			max = array[1];
		}
		
		if (array[2] > max) {
			max = array[2];
		}
		if (array[3] > max) {
			max = array[3];
		}
		if (array[4] > max) {
			max = array[4];
		}
		
		System.out.println("최대값:"+max);
		
	}

}
