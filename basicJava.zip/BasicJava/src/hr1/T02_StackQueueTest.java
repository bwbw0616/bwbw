package hr1;

import java.util.LinkedList;

import javax.xml.namespace.QName;

public class T02_StackQueueTest {
	public static void main(String[] args) {
		//
		//stack => 후입선출(LIFO) 자료구조
		//queue => 선입선출(LIFO) 자료구조
		//
		LinkedList<String> stack = new LinkedList<String>();
		
		/*
		 * stack의 명령
		 * 1) 자료 입력 : push(저장할 값)
		 * 2) 자료 출력 : pop() => 자료를 꺼내온 후 꺼내온 자료를 stack 에서 삭제한다.
		 */
		stack.push("홍길동");
		stack.push("홍길동");
		stack.push("홍길동");
		stack.push("홍길동");
		System.out.println("현재 stack 값들: " + stack);
		
		String data = stack.pop();
		System.out.println();
		System.out.println();
		System.out.println();
		
		stack.push("성춘향");
		System.out.println();
		System.out.println();
		
		System.out.println();
		System.out.println();
		
		LinkedList<String> queue = new LinkedList<String>();
		
		/*
		 * Queue의 명령
		 * 1) 자료 입력 : offer(저장할 값)
		 * 2) 자료 출력 : poll() => 자료를 Queue에서 꺼내온 후 꺼내온 자료는
		 *                         Queue에서 삭제된다. 
		 */
		queue.offer("홍길동");
		queue.offer("홍길동");
		queue.offer("홍길동");
		queue.offer("홍길동");
		System.out.println("현재 queue의 값: " + queue);
		
		
	}
}
