package com.ddit.java.ticketingapp.concert;


import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class ConcertDAO {
	private static ConcertDAO instance;
	private ConcertDAO() {
	}
	public static ConcertDAO getInstance() {
		if(instance == null) {
			instance = new ConcertDAO();
		}
		return instance;
	}
	
	JdbcTemplate template = JdbcTemplate.getTemplate();
	
	public List<Map<String, Object>> selectConcertWithCategory(Object category) {
		String sql = "";
		sql += " select A.CON_NAME,";
		sql += "        A.CON_RATING,";
		sql += "        B.PLACE_NAME,";
		sql += "        A.CON_DATE,";
		sql += "        A.CON_ID";
		sql += "   from CONCERT A, PLACE B, CONCERT_CATEGORY C";
		sql += "  where A.PLACE_ID = B.PLACE_ID";
		sql += "    and A.CATEGORY_ID = C.CATEGORY_ID";
		sql += "    and C.CATEGORY_NAME = ?";
		
		List<Map<String, Object>> list = template.selectList(sql, category);
		
		return list;
	}
	
	public Map<String, Object> selectConcertMoreInfo(Object conId) {
		String sql = "";
		sql += "select A.CON_NAME as 공연명,";
		sql += "       A.CON_PLANNER as \"주최/기획\",";
		sql += "       B.PLACE_HP as 고객문의,";
		sql += "       A.CON_SHOWTIME as 공연시간,";
		sql += "       A.CON_RATING as 관람등급,";
		sql += "       C.CAST_NAME as 주연,";
		sql += "       B.PLACE_NAME as 공연장소,";
		sql += "       '장당 1000원' as 예매수수료,";
		sql += "       A.CON_DATE as 공연기간";
		sql += "  from CONCERT A, PLACE B, CAST C, CASTING D";
		sql += " where A.PLACE_ID = B.PLACE_ID";
		sql += "   and A.CON_ID = D.CON_ID";
		sql += "   and C.CAST_ID = D.CAST_ID";
		sql += "   and A.CON_ID = ?";

		Map<String, Object> map = template.selectOne(sql, conId);
		
		return map;
	}
	
	public Map<String, Object> selectConcert(Object conId) {
		String sql = "select * from CONCERT where CON_ID = ?";
		
		Map<String, Object> map = template.selectOne(sql, conId);
		
		return map;
	}
}
