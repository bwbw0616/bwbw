package Chapter20;

import java.util.List;
import java.util.Scanner;

public class JDBCProgramming {
	public static void main(String[] args) throws Exception {
		MemberDao dao = new MemberDao();
		List<MemberVO> list = dao.getMembers();
		for (MemberVO vo : list) {
			System.out.printf("%s \t %s \t %s \t %s\n", vo.getMemId(), vo.getMemName(), vo.getMemHp(), vo.getMemMail());
		}
		Scanner scanner = new Scanner(System.in);
		System.out.print("조회할 아이디를 입력하세요: ");
	    String searchId = scanner.next();
	    MemberVO vo = dao.getMember(searchId);
	    if(vo != null) {
	    	System.out.println("---------------------------------");	
	    	System.out.println("이름: " + vo.getMemName());
	    	System.out.println("직업: " + vo.getMemJob());	
	    	System.out.println("---------------------------------");
	    }
	    System.out.print("수정할 아이디를 입력하세요: ");
	    String memId = scanner.next();
	    
	    System.out.print("변경할 직업을 입력하세요: ");
	    String memJob = scanner.next();
	    
	    MemberVO updateVO = new MemberVO();
	    updateVO.setMemJob(memJob);
	    updateVO.setMemId(memId);
	    //직업변경
	    int updateMember = dao.updateMember(updateVO);
	    //변경 성공 시 화면에 내용 출력
	    if(updateMember > 0) {
	    	MemberVO member = dao.getMember(memId);
	    	System.out.println(member.getMemId() + ":" + member.getMemJob());
	    }
	    
	    scanner.close();
	}
    
}