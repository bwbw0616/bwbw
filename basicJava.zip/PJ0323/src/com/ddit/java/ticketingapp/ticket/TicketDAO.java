package com.ddit.java.ticketingapp.ticket;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import javax.xml.transform.sax.TemplatesHandler;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class TicketDAO {
	private static TicketDAO instance;

	private TicketDAO() {
	}

	public static TicketDAO getInstance() {
		if(instance == null) {
			instance = new TicketDAO();
		}
		return instance;
	}

	JdbcTemplate template = JdbcTemplate.getTemplate();
	
	public Map<String, Object> selectTicket(Object conId, Object seatNo) {
		String sql = "";
		sql += "select A.CON_NAME as 공연명,";
		sql += "       A.CON_DATE as 날짜,";
		sql += "       B.PLACE_NAME as 장소명,";
		sql += "       C.CAST_NAME as 주연,";
		sql += "       E.SEAT_NO as 좌석번호,";
		sql += "       A.TICKET_PRICE + A.TICKET_PRICE / 100 * NVL2(E.PREMIUM, SUBSTR(E.PREMIUM, 2, 2), 0) as 가격";
		sql += "  from CONCERT A, PLACE B, CAST C, CASTING D, SEAT E";
		sql += " where A.CON_ID = D.CON_ID";
		sql += "   and A.PLACE_ID = B.PLACE_ID";
		sql += "   and C.CAST_ID = D.CAST_ID";
		sql += "   and A.CON_ID = ?";
		sql += "   and E.SEAT_NO = ?";

		List<Object> list = new ArrayList<>();
		list.add(conId);
		list.add(seatNo);
		Map<String, Object> map = template.selectOne(sql, list);
		return map;
	}

	public Map<String, Object> selectTicketCommission(Object conId, Object seatNo) {
		String sql = "";
		sql += "select A.CON_NAME as 공연명,";
		sql += "       A.CON_DATE as 날짜,";
		sql += "       B.PLACE_NAME as 장소명,";
		sql += "       C.CAST_NAME as 주연,";
		sql += "       E.SEAT_NO as 좌석번호,";
		sql += "       A.TICKET_PRICE + A.TICKET_PRICE / 100 * NVL2(E.PREMIUM, SUBSTR(E.PREMIUM, 2, 2), 0) + 1000 as 가격";
		sql += "  from CONCERT A, PLACE B, CAST C, CASTING D, SEAT E";
		sql += " where A.CON_ID = D.CON_ID";
		sql += "   and A.PLACE_ID = B.PLACE_ID";
		sql += "   and C.CAST_ID = D.CAST_ID";
		sql += "   and A.CON_ID = ?";
		sql += "   and E.SEAT_NO = ?";

		List<Object> list = new ArrayList<>();
		list.add(conId);
		list.add(seatNo);
		Map<String, Object> map = template.selectOne(sql, list);
		return map;
	}
	
	public Map<String, Object> selectTicket(Object conId, Object seatNo, Object method) {
		String sql = "";
		sql += "select A.CON_NAME as 공연명,";
		sql += "       A.CON_DATE as 날짜,";
		sql += "       B.PLACE_NAME as 장소명,";
		sql += "       C.CAST_NAME as 주연,";
		sql += "       E.SEAT_NO as 좌석명,";
		sql += "       " + method + " 결제수단,";
		sql += "       A.TICKET_PRICE + A.TICKET_PRICE / 100 * NVL2(E.PREMIUM, SUBSTR(E.PREMIUM, 2, 2), 0) + 1000 as 가격";
		sql += "  from CONCERT A, PLACE B, CAST C, CASTING D, SEAT E";
		sql += " where A.CON_ID = D.CON_ID";
		sql += "   and A.PLACE_ID = B.PLACE_ID";
		sql += "   and C.CAST_ID = D.CAST_ID";
		sql += "   and A.CON_ID = ?";
		sql += "   and E.SEAT_NO = ?";

		List<Object> list = new ArrayList<>();
		list.add(conId);
		list.add(seatNo);
		Map<String, Object> map = template.selectOne(sql, list);
		return map;
	}
	
	public Map<String, Object> updateTicket(Object conId, Object seatNo) {
		String sql = "insert into TICKET values('T'||?||substr(?, 5, 4), ?, ?, '1000')";
		List<Object> list = new ArrayList<>();
		list.add(seatNo);
		list.add(conId);
		list.add(conId);
		list.add(seatNo);
		int result = template.update(sql, list);
		
		String sql2 = "select * from TICKET where TICKET_ID = 'T'||?||substr(?, 5, 4)";
		List<Object> list2 = new ArrayList<>();
		list2.add(seatNo);
		list2.add(conId);
		Map<String, Object> map = template.selectOne(sql2, list2);
		
		return map;
	}
	
	public Map<String, Object> updateTicketing(Object conId, Object seatNo, Object price, Object ticketId, Object memId) {
		String sql = "insert into TICKETING values(?||substr(?, 1, 5),  SYSDATE, 1, ?, ?, ?)";
		List<Object> list = new ArrayList<>();
		list.add(ticketId);
		list.add(memId);
		list.add(price);
		list.add(ticketId);
		list.add(memId);
		
		int result = template.update(sql, list);
		
		String sql2 = "select * from TICKETING where TICKETING_ID = ?||substr(?, 1, 5)";
		List<Object> list2 = new ArrayList<>();
		list2.add(ticketId);
		list2.add(memId);
		Map<String, Object> map = template.selectOne(sql2, list2);
		
		return map;
	}
}
