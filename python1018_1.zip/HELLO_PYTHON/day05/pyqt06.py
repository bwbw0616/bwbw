from PyQt5 import uic
from PyQt5.Qt import QMainWindow
from anaconda_navigator.utils.qthelpers import qapplication
import sys
import random

from _random import Random

#UI파일 연결
#단, UI파일은 Python 코드 파일과 같은 디렉토리에 위치해야한다.
form_class = uic.loadUiType("pyqt06.ui")[0]

#화면을 띄우는데 사용되는 Class 선언
class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        #버튼에 기능을 연결하는 코드
        self.pb.clicked.connect(self.button1Function)
        
    #pb가 눌리면 작동할 함수
    def button1Function(self) :
        arr45 = list(range(1,45+1))
        arr6 = []

        for i in range(6):
            rnd = int(len(arr45)*random.random())
            p = arr45.pop(rnd)
            arr6.append(p)
        
        self.lbl1.setText(str(arr6[0]))
        self.lbl2.setText(str(arr6[1]))
        self.lbl3.setText(str(arr6[2]))
        self.lbl4.setText(str(arr6[3]))
        self.lbl5.setText(str(arr6[4]))
        self.lbl6.setText(str(arr6[5]))

if __name__ == "__main__" :
    #QApplication : 프로그램을 실행시켜주는 클래스
    app = qapplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()

    #프로그램을 이벤트루프로 진입시키는(프로그램을 작동시키는) 코드
    app.exec_()