package chapter05;

public class page201num05 {
	public static void main(String[] args) {
		int[][] array = {
				{95,86},
				{83,92,96},
				{78,83,93,87,88}
		};
		
		int sum = 0;
		double avg = 0.0;
		
		//작성 위치
		
		//전체의 합 & 평균값 구하기
		

	        for (int a=0; a< array.length; a++)	{
	    	for(int b = 0; b<array[a].length; b++) {
	        
	    		sum += array[a][b];
	        
	    		avg = sum/10.0;
	       
	    	}
	    }
	    	
	    	
	    	
		System.out.println("sum: " + sum);
		
		System.out.println("avg: " + avg);
		
	}

}
