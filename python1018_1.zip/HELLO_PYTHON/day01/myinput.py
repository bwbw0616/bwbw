a = input("원하는 수를 넣으시오")
print("a", a, "adsafg")