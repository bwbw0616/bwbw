package Chapter07;

public class Maltese extends Dog {
	@Override
	public String sound() {
		return "멍멍";
	}

}
