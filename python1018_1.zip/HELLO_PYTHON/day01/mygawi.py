# 사용자 vs 컴퓨터 가위바위보 만들기
import random

com = ""
mine = ""
result = ""

mine = input("가위/바위/보를 입력하세요.")

rnd = random.random()

if rnd > 0.66:
    com = "가위"
elif rnd > 0.33:
    com = "바위"
else:
    com = "보"

if com == mine:
    result = "비김"
elif com == "가위" and mine == "바위" or com == "보" and mine == "가위" or com == "바위" and mine == "보":
    result = "이김"

else:
    result = "짐"

print("com", com)
print("mine", mine)
print("result", result)