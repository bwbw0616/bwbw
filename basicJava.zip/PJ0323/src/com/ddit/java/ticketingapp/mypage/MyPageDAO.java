package com.ddit.java.ticketingapp.mypage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.member.MemberVO;
import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class MyPageDAO {
	public static MyPageDAO instance;
	
	public static MyPageDAO getInstance() {
		if(instance == null) {
			instance = new MyPageDAO();
		}
		return instance;
	}

	private MyPageDAO() {
	}
	
	private JdbcTemplate template = JdbcTemplate.getTemplate();
	
	public Map<String, Object> showMember(String id){
		String sql = "";
		sql += "SELECT MEM_ID, MEM_NAME, MEM_REGNO1, MEM_REGNO2, MEM_ADDR, MEM_HP, REGISTRATION_DATE";
		sql += "  FROM MEMBER";
		sql += " WHERE MEM_ID=?";
		
		return template.selectOne(sql, id);
	}
	
	//예매내역출력
	public List<Map<String, Object>> showTicket(String id){
		String sql = "";
		sql += "SELECT K.TICKET_ID, K.CON_NAME, K.CON_DATE, K.CAST_NAME, K.PLACE_NAME, K.SEAT_NO, M.PAYMETHOD_NAME";
		sql += "   FROM (SELECT I.TICKETING_ID, J.MEM_ID, H.TICKET_ID, H.CON_NAME, H.CON_DATE, H.CAST_NAME, H.PLACE_NAME, H.SEAT_NO";
		sql += "           FROM (SELECT F.TICKET_ID, E.CON_NAME, E.PLACE_NAME, E.CON_DATE, E.CAST_NAME, G.SEAT_NO";
		sql += "                   FROM (SELECT B.CON_ID, B.CON_NAME, A.PLACE_NAME, B.CON_DATE, D.CAST_NAME";
		sql += "                           FROM PLACE A, CONCERT B, CASTING C, CAST D";
		sql += "                          WHERE A.PLACE_ID=B.PLACE_ID";
		sql += "                            AND B.CON_ID=C.CON_ID";
		sql += "                            AND C.CAST_ID=D.CAST_ID) E,";
		sql += "                          TICKET F, SEAT G";
		sql += "                 WHERE E.CON_ID=F.CON_ID";
		sql += "                   AND F.SEAT_NO=G.SEAT_NO) H,";
		sql += "                 TICKETING I, MEMBER J";
		sql += "        WHERE H.TICKET_ID=I.TICKET_ID";
		sql += "          AND I.MEM_ID=J.MEM_ID) K,";
		sql += "         PAYMENT L, PAYMENT_METHOD M";
		sql += "   WHERE K.TICKETING_ID=L.TICKETING_ID";
		sql += "     AND L.PAYMETHOD_ID=M.PAYMETHOD_ID";
		sql += "     AND K.MEM_ID=?";
		
		try {
			return template.selectList(sql, id);
		} catch(Exception e){
			return null;
		}
	}
	
	  public int modifyName(MemberVO vo) {
		  String sql = "UPDATE MEMBER SET MEM_NAME=? WHERE MEM_ID=?"; 
		  List<Object> param = new ArrayList<>();
		  param.add(vo.getName());
		  param.add(vo.getId());
		  return template.update(sql, param);
		  }
	  
	  public int modifyPassword(MemberVO vo) { 
		  String sql = "UPDATE MEMBER SET MEM_PASSWORD=? WHERE MEM_ID=?"; 
		  List<Object> param = new ArrayList<>();
		  param.add(vo.getPassword());
		  param.add(vo.getId());
		  return template.update(sql, param); 
		  }
	  
	  public int modifyAddr(MemberVO vo) { 
		  String sql = "UPDATE MEMBER SET MEM_ADDR=? WHERE MEM_ID=?"; 
		  List<Object> param = new ArrayList<>();
		  param.add(vo.getAddr());
		  param.add(vo.getId());
		  return template.update(sql, param); 
		  }
	  
	  public int modifyHp(MemberVO vo) {
		  String sql = "UPDATE MEMBER SET MEM_HP=? WHERE MEM_ID=?"; 
		  List<Object> param = new ArrayList<>();
		  param.add(vo.getHp());
		  param.add(vo.getId());
		  return template.update(sql, param); 
		  }
	 
	
	public List<Map<String, Object>> showTicketId(String id){
		String sql = "";
		sql += "SELECT A.TICKET_ID";
		sql += "  FROM TICKET A, TICKETING B, MEMBER C";
		sql += " WHERE A.TICKET_ID=B.TICKET_ID";
		sql += "   AND B.MEM_ID=C.MEM_ID";
		sql += "   AND C.MEM_ID=?";
		
		return template.selectList(sql, id);
	}
	
	public Map<String, Object> showTicketingId(Object ticketId){
		String sql = "";
		sql += "SELECT TICKETING_ID";
		sql += "  FROM TICKETING";
		sql += " WHERE TICKET_ID=?";
		
		return template.selectOne(sql, ticketId);
	}
	
	public Map<String, Object> showPayMethod(Object ticketingId){
		String sql = "";
		sql += "SELECT A.PAYMETHOD_NAME";
		sql += "  FROM PAYMENT_METHOD A, PAYMENT B";
		sql += " WHERE A.PAYMETHOD_ID=B.PAYMETHOD_ID";
		sql += "   AND B.TICKETING_ID=?";
		return template.selectOne(sql, ticketingId);
	}
	
	public int insertRefund(Object ticketingId, Object method) {
		String sql = "INSERT INTO REFUND VALUES(TO_CHAR(SYSDATE, 'YYYYMMDD')||SUBSTR(?,4,5), SYSDATE, ?,?)";
		List<Object> param = new ArrayList<>();
		param.add(ticketingId);
		param.add(method);
		param.add(ticketingId);
		return template.update(sql, param);
	}
}
