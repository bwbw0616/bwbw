import requests
from bs4 import BeautifulSoup
import datetime
import pymysql

conn = pymysql.connect(host='localhost', user='root', password='python',
                       db='python',port=3305, charset='utf8')
curs = conn.cursor()

now = datetime.datetime.now()
ymd = now.strftime("%Y%m%d.%H%M")
print(ymd)


htmls = requests.get('https://vip.mk.co.kr/newSt/rate/item_all.php?koskok=KOSDAQ&orderBy=dd')
#https://vip.mk.co.kr/newSt/rate/item_all.php?koskok=KOSDAQ&orderBy=dd
#https://vip.mk.co.kr/newSt/rate/item_all.php

htmls.encoding = "euc-kr"

soup = BeautifulSoup(htmls.text, "html.parser")

st2s = soup.select(".st2")

for st in st2s:
    s_name = st.text
    s_code = st.select("a")[0]['title']
    price = st.parent.select("td")[1].text.replace(",","")
    
    print(s_name,s_code,price,ymd)
    sql = f"""insert into stock (s_code,s_name,price,ymd) 
        values ('{s_code}','{s_name}','{price}','{ymd}')"""

    print("sql",sql)
    cnt = curs.execute(sql)
    print("cnt",cnt)

conn.commit()
curs.close() 
conn.close()