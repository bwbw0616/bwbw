package review_hyorim;

import java.util.Scanner;

public class chapter03homework_02 {
	public static void main(String[] args) {
		//메트로폴리스(거대도시)는
		//
		
		Scanner scanner = new Scanner(System.in);
		
		int capital;
		System.out.println("수도입니까? (수도 : 1, 수도아님 : 0)");
		capital = scanner.nextInt();
		
		int allpeople;
		System.out.println("총 인구 수는?(단위 : 만)");
		allpeople = scanner.nextInt();
		
		int rich;
		System.out.println("연 소득이 1억 이상인 인구는?");
		rich = scanner.nextInt();
		
		if (((capital==1)&&(allpeople>=100))||(rich>=50))   {
			System.out.println("이 도시는 메트로폴리스입니다.");
		}else  {
			System.out.println("이 도시는 메트로폴리스가 아닙니다.");
			
			scanner.close();
		}
		
	}

}
