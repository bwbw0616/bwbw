package JavaTest20220316;

public class SmartPhoneTest {
	public static void main(String[] args) {
		new SmartPhoneVO("SAMSUNG", "Galaxy zflip", 256);
		new SmartPhoneVO("iphone", "iphone13" , 256);
	}
}
