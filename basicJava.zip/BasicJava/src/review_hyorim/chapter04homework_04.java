package review_hyorim;

import java.util.Scanner;

public class chapter04homework_04 {
	public static void main(String [] args) {
		//두 사람이 하는 가위 바위 보 게임
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("가위 바위 보 게임입니다. 가위, 바위, 보 중에서 입력하세요");
		System.out.println("철수 : ");
		String cheolsu = scanner.next();
		System.out.println("영희 : ");
		String younghee = scanner.next();
		String result = "";
		
		if(cheolsu.equals(younghee)) {
			result = "무승부";
		}else if(cheolsu.equals("가위")&&younghee.equals("바위")||
		         cheolsu.equals("바위")&&younghee.equals("보")||
		         cheolsu.equals("보")&&younghee.equals("가위")){
		        	 result = "영희 승리";
		}else {
			result = "철수 승리";
		}
		 System.out.println("결과 : ");
		 System.out.println(result);
		  scanner.close();
	
	}

}
