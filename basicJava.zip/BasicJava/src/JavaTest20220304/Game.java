package JavaTest20220304;

import java.util.Scanner;

public class Game {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("강호동 : ");
		String hd = scanner.next();
		System.out.print("이승기 : ");
		String sg = scanner.next();
		String result = "";
		if (hd.equals(sg)) {
			result = "무승부!";
		} else if (hd.equals("가위") && sg.equals("바위") || hd.equals("바위") && sg.equals("보")
				|| hd.equals("보") && sg.equals("가위")) {
			result = "이승기 승리!";
		} else {
			result = "강호동 승리!";
		}
		System.out.println("결과 : ");
		System.out.println(result);
		scanner.close();
	}
}
