package Chapter10Homework;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercise01_모범답안 {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		while (true) {

			try {
				System.out.print("어떤 수를 나누시겠습니까?>>");
				int first = scanner.nextInt();
				System.out.print("어떤 수로 나누시겠습니까?>>");
				int second = scanner.nextInt();
				int result = first / second;
				System.out.println(first + " / " + second + " = " + result);
				break;

			} catch (InputMismatchException e) {
				System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
				scanner.next();
			} catch (ArithmeticException e) {
				System.out.println("0으로 나눌수 없습니다. 다시 입력해주세요.");
				continue;
			}
		}
		scanner.close();
	}
}