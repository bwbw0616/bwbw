package com.ddit.java.temp.service;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.ddit.java.temp.JdbcTemplate;
import com.ddit.java.temp.dao.CategoryDAO;

public class CategoryService {
	private static CategoryService instance;
	
	private CategoryService() {
	}
	
	public static CategoryService getInstance() {
		if(instance == null) {
			instance = new CategoryService();
		}
		return instance;
	}
	
	public void showCategory() {
		CategoryDAO dao = CategoryDAO.getInstance();
	}
}
