package review_hyorim;

public class page42_RunStatementExample {
	public static void main (String[] args) {
		int x = 1;
		int y = 2;
		int result = x + y ;
		System.out.println(result);
		
	}

}
