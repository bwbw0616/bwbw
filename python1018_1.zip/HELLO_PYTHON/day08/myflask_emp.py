from flask import Flask
from flask.globals import request
from flask.templating import render_template
from day08.dao_emp import DaoEmp
app = Flask(__name__)

@app.route('/')
@app.route('/emp')
def list():
    de = DaoEmp()
    emps = de.myselects()
    return render_template('emp.html', emps=emps)


if __name__ == '__main__':
    app.run()