package kr.or.ddit.board.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.vo.BoardVO;

public class BoardDAOImpl implements BoardDAO {
	
	private static BoardDAO boardDAO;
	
	private BoardDAOImpl() {
	}
	
	public static BoardDAO getInstance() {
		if(boardDAO == null) {
			boardDAO = new BoardDAOImpl();
		}
		
		return boardDAO;
	}
	
	public int insertBoard(SqlMapClient smc,BoardVO mv) {
		
		int cnt = 0;
		try {			
			cnt = smc.update("board.insertBoard", mv);			
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원정보 입력 중 예외발생!", ex);
		}

		return cnt;
	}

	public int updateBoard(SqlMapClient smc,BoardVO mv) {
		
		int cnt = 0;
		
		try {
			cnt = smc.update("board.updateBoard",mv);			
			
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원정보 수정 중 예외 발생!");
		}
		
		return cnt;
	}

	public int deleteBoard(SqlMapClient smc,String boardId) {
		
		int cnt = 0;
		
		try {
			cnt = smc.delete("board.deleteBoard", boardId);
			
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원정보 삭제 중 예외 발생", ex);
		}
		return cnt;
	}

	public List<BoardVO> getAllBoardList(SqlMapClient smc) {
		
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.getBoardAll");
			
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("전체 회원정보 조회 중 예외 발생", ex);
		}
		
		return boardList;
	}

	public boolean checkBoard(SqlMapClient smc,String boardId) {
		
		boolean chk = false; // 회원 존재여부 체크
		
		try {
			
			int cnt = (int)smc.queryForObject("board.checkBoard",boardId);
			
			if(cnt > 0) {
				chk = true;
			}
			
		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("",ex);
		}
		return chk;
	}

	public List<BoardVO> searchBoardList(SqlMapClient smc,BoardVO mv) {
		
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.searchBoard",mv);

		}catch(SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원정보 검색 중 예외 발생",ex);
		}
		
		return boardList;
	}

}
