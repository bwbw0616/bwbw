package com.ddit.java.ticketingapp.seat;

import java.util.Map;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class SeatDAO {
	private static SeatDAO instance;

	private SeatDAO() {
	}

	public static SeatDAO getInstance() {
		if(instance == null) {
			instance = new SeatDAO();
		}
		return instance;
	}

	JdbcTemplate template = JdbcTemplate.getTemplate();

	public void showSeatLeft(String rank, int rowNum) {
		int length;

		length = getNumLength(rank);
		System.out.print("\t\t         " + rank.substring(0, 1) + " ");
		for (int i = 1; i < length + 1; i++) {
			System.out.print(selectSeatLeft(rank.substring(0, 1), i));
			if(i % (length / rowNum) == 0 && i != length) {
				System.out.println();
				System.out.print("\t\t         " + rank.substring(0, 1) + " ");
			}
		}
		System.out.println();
	}

	public String selectSeatLeft(String param, int num) {
		Map<String, Object> map;
		String seatLeft = null;

		JdbcTemplate template = JdbcTemplate.getTemplate();
		String sql = "select SEAT_LEFT from SEAT where SEAT_NO = ?";

		map = template.selectOne(sql, param + num);

		if(String.valueOf(map.get("SEAT_LEFT")).equals("Y")) {
			seatLeft = "□ ";
		}
		else if(String.valueOf(map.get("SEAT_LEFT")).equals("N")) {
			seatLeft = "■ ";
		}
		return seatLeft;
	}

	public int getNumLength(String str) {
		String sql = "";
		sql += " select RANK,";
		sql += "        COUNT(*) as 수";
		sql += "   from SEAT";
		sql += "  where SEAT_NO like ?";
		sql += "  group by RANK";

		Map<String, Object> map = template.selectOne(sql, str + "%");
		int length = Integer.parseInt(String.valueOf(map.get("수")));

		return length;
	}

	public Map<String, Object> selectSeat(Object seatNo) {
		String sql = "select * from SEAT where SEAT_NO = ?";

		Map<String, Object> map = template.selectOne(sql, seatNo);

		return map;
	}
}
