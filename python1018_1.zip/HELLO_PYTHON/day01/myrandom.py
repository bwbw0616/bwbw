import random

rnd = random.random()

print("rnd", rnd)