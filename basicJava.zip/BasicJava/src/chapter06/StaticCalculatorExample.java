package chapter06;

public class StaticCalculatorExample {
	public static void main(String[] args) {
		StaticCalculator calculator = new StaticCalculator();
		
		
	}

}
