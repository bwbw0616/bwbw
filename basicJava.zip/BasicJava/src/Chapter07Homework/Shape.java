package Chapter07Homework;

public class Shape {

	
	public Shape() {
	
	}
	
	public double area() {
		return 0.0;
	}
	public double perimeter() {
		return 0.0;
	}
}