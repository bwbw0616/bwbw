package kr.or.ddit.member.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.Util.SqlMapClientFactory;
import kr.or.ddit.member.vo.MemberVO;

public class MemberDAOImpl implements IMemberDAO{
	
	private static IMemberDAO memDAO; //IMemberDAO안에 MemberDAOImpl도 포함
	
	private MemberDAOImpl() {
	}
	
	public static IMemberDAO getInstance() {
		if(memDAO == null) {
			memDAO = new MemberDAOImpl();
		}
		return memDAO;
	}
	
	

	@Override
	public int inserMember(SqlMapClient smc, MemberVO mv) {
		
		int cnt = 0;
		
		try {
			
			cnt = smc.update("member.insertMember",mv);
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 입력 중 예외 발생!",e);
			// RuntimeException : 강제적으로 예외처리 의무가 없다. 예외처리를 하지 않아도 되는 예외 (try-catch로 감싸지 않아도 된다.) (NullPointerException도 포함됨)
			// 서비스에서 에러를 확인할 수 있는데, 필요한 경우 예외를 가져다 의미있는 작업이 가능함.
		}
		return cnt;
	}

	@Override
	public int updateMember(SqlMapClient smc, MemberVO mv) {
		
		int cnt = 0;
		
		try {
			cnt = smc.update("member.updateMember", mv);
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 수정중 예외 발생!",e);
		}
		return cnt;
	}

	@Override
	public int deleteMember(SqlMapClient smc, String memId) {
		int cnt = 0;
		
		try {
			cnt = smc.delete("member.deleteMember", memId);
			
		}catch(SQLException e) {
			System.out.println("출력 작업 실패");
			e.printStackTrace();
			throw new RuntimeException("회원정보 삭제중 예외 발생!",e);
		}
		return cnt;
	}

	@Override
	public List<MemberVO> getAllMemberList(SqlMapClient smc) {
		
		List<MemberVO> memList = new ArrayList<MemberVO>();
		
		try {
			memList = smc.queryForList("member.getMemberAll");
		
		}catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("전체 회원정보 조회중 예외 발생!",e);
		}
		return memList;
	}

	@Override
	public boolean checkMember(SqlMapClient smc, String memId) {
		
		boolean chk = false; //회원 존재 여부 체크
		
		try {
			
			int cnt = (Integer) smc.queryForObject("member.checkMember", memId);
			
			if(cnt > 0) { //중복 존재
				chk = true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 중복 체크중 예외 발생!",e);
		}
		return chk;
	}

	@Override
	public List<MemberVO> searchMemberList(SqlMapClient smc, MemberVO mv) {
		
		List<MemberVO> memList = new ArrayList<MemberVO>();
		
		try {
			memList = smc.queryForList("member.searchMember", mv);
		}catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 검색중 예외 발생!",e);
		}
		return memList;
	}

	@Override
	public MemberVO getMember(SqlMapClient smc, String memId) {
		
		MemberVO mv = null;
		
		try {
			
			mv = (MemberVO) smc.queryForObject("member.getMember", memId);
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 조회 중 예외 발생!",e);
		}
		 
		return mv;
	}
	
	
}
