package Chapter08;

public interface Searchable {
	void search(String url);
}
