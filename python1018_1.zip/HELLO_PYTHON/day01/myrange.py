arr = list(range(5))

print(arr)

for i in arr:
    print(i)