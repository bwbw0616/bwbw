package chapter05;

import java.util.Random;
import java.util.Scanner;

public class Homework_04 {
	public static void main(String[] args) {
		
		boolean run = true;
		int Num = 0;
		int[] scores = new int[6]; 
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		for(int i=1; i<=10000; i++) {
			int rnd = random.nextInt(6) + 1;
			System.out.println(rnd);
			scores[rnd-1] ++;
		}
		System.out.println("---------------------------------------------------------------");
		System.out.println("면 | 빈도");
		System.out.println("----------------------------------------------------------------");
		System.out.println("");
		for(int i=0; i<scores.length; i++) {
			
			System.out.println((i+1) + "\t " + scores[i] );
		}

		
	}

}
