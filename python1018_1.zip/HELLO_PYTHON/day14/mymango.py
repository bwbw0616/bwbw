from selenium import webdriver
from selenium.webdriver.common.by import By

# 102.0.5005.63
 
browser = webdriver.Chrome()
browser.get("https://www.mangoplate.com/search/%EB%8C%80%EC%A0%84%20%EC%98%A4%EB%A5%98%EB%8F%99")

 
trs = browser.find_elements(by=By.CSS_SELECTOR, value='#tb > tr')

for tr in trs:
    tds = tr.find_elements(by=By.CSS_SELECTOR, value='td')
    print(tds[1].text,"\t",tds[3].text)
