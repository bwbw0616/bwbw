package chapter04;

public class ForExample {
	public static void main(String[] args) {
		//1부터 n까지의 합을 구하는 프로그램
		//n은 10000이내의 숫자를 입력
		int sum = 0;
		int i;
		for ( i = 1; i <=50;   i++ ) {
		    sum=sum+i;
		  }
	      System.out.println("1부터 "+ ( i - 1 ) + "까지의 합: " + sum);
	}
}
