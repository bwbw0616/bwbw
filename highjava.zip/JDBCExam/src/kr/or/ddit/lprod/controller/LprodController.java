package kr.or.ddit.lprod.controller;

import java.util.List;
import java.util.Scanner;

import kr.or.ddit.lprod.service.ILprodService;
import kr.or.ddit.lprod.service.LprodServiceImpl;
import kr.or.ddit.lprod.vo.LprodVO;

public class LprodController {

	private Scanner scan = new Scanner(System.in);

	private ILprodService service;
	
	public LprodController() {
		service = LprodServiceImpl.getInstance();	// 서비스 객체 생성
	}
	
	// 시작 메서드
	public void lprodStart() {
		while (true) {
			int choice = displayMenu();
			switch (choice) {
			case 1:
				displayAll();
				break;
			case 2:
				insert();
				break;
			case 0:
				System.out.println("프로그램을 종료합니다..");
				return;
			default:
				System.out.println("작업 번호를 잘못 입력했습니다.");
				System.out.println("다시 선택하세요.");
			}
		}
	}

	private void insert() {
		int maxnum = service.getMaxLprodId();
		maxnum++;
		//-----------------------------------------------------------------
		
		// 입력받은 Lpred_gu가 이미 등록되어 있는 값이면 다시 입력 받아서 처리한다.
		
		String gu;	// 상품 분류 코드(LPROD_GU)
		int count = 0;	// 입력한 상품 분류 코드의 개수가 저장될 변수
		do {
			System.out.println("상품 분류 코드(LPROD_GU) 입력 >> ");
			gu = scan.next();
			
			count = service.getLprodBuCount(gu);
			
			
			if(count == 1) {
				System.out.println("입력한 상품 분류 코드" + gu + "는 이미 등록된 코드입니다.");
				System.out.println("새로운 상품 분류 코드를 입력하세요.");
			}
		}while(count==1);
		//---------------------------------------------
		
		System.out.println("상품 분류명(LPROD_NM) 입력 >> ");
		String nm = scan.next();
		
		// insert할 데이터를 VO객체에 저장한다.
		LprodVO lvo = new LprodVO();
		lvo.setLprodId(maxnum);
		lvo.setLprodGu(gu);
		lvo.setLprodNm(nm);
		
		int cnt = service.insertLprod(lvo);
		
		if(cnt > 0) {
			System.out.println("데이터 추가 성공!!");
		}else {
			System.out.println("데이터 추가 실패!!");
		}
		
		
	}
	
	private void displayAll() {
		// Service객체에 있는 메서드를 호출하여 결과를 받아온다.
		List<LprodVO> lprodList = service.getAllLprod();
		
		for(LprodVO lvo : lprodList) {
			System.out.println("Lprod_ID : " + lvo.getLprodId());
			System.out.println("Lprod_GU : " + lvo.getLprodGu());
			System.out.println("Lprod_NM : " + lvo.getLprodNm());
			System.out.println("-----------------------------------");
		}
		System.out.println("출력의 끝...");
		System.out.println();
	}
	
	
	
	// 메뉴를 출력하고 작업 번호를 입력받아서 반환하는 메서드
		private int displayMenu() {
			System.out.println();
			System.out.println("=======================");
			System.out.println("1. 전체 목록 보기");
			System.out.println("2. 데이터 추가하기");
			System.out.println("0. 프로그램 종료");
			System.out.println("=======================");
			System.out.print("작업 번호>>");
			return scan.nextInt();
		}

	public static void main(String[] args) {
		new LprodController().lprodStart();

	}
}
