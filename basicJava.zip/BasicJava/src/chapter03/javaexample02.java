package chapter03;

import java.util.Scanner;

public class javaexample02 {
	public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    	   	//메트로폴리스(거대도시)는 다음과 같은 2가지 조건 중 하나를 만족하여야 한다
          //1. 한 나라의 수도이고, 인구가 100만 이상이어야 한다. 
           //2. 연 소득이 1억 이상인 인구가 50만 이상이어야 한다.
 
		System.out.println("수도입니까?(수도:1,수도아님:0) " );
	    String capital = scanner.nextLine();
		
		System.out.println("총 인구는?(단위: 만) " );
		String people = scanner.nextLine();
		
		System.out.println("연소득이 1억 이상인 인구는?(단위: 만)");
		String richpeople = scanner.nextLine();
		
		int strCapital = Integer.parseInt(capital);
		int allpeople = Integer.parseInt(people);
		int rich = Integer.parseInt(richpeople);
		 
		
		if((strCapital==1 && allpeople>=100 )||(strCapital<=1 &&rich>=50))  {
			System.out.println("이 도시는 메트로폴리스입니다");
			
					}else {
						System.out.println("이 도시는 메트로폴리스가 아닙니다.");
						
				}
		}	
}

	
		



