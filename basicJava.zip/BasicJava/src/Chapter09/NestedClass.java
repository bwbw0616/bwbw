package Chapter09;

public class NestedClass {
	String a;
	class InnerClass{
		String b;
		void method1() {
			class LocalClass{
				
			}
			LocalClass localClass = new LocalClass();{
				
			}
		}
	}
	static class InnerClass2{
		
	}
	interface InnerInterface{
		
	}
}
