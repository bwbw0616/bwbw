package chapter05;

import java.util.Random;

public class Homework04_모범답안 {
	public static void main(String[] args) {
		
		int[] dice = new int[6];
		
		Random random = new Random();
		for (int i = 0; i < 10000; i++) {
			int ranNum = random.nextInt(6);
			dice[ranNum]++;
			
		}
		System.out.println("---------------------------");
		System.out.println("면\t빈도");
		System.out.println("---------------------------");
		for(int i = 0; i<dice.length; i++) {
			System.out.println((i + 1) + "\t" + dice[i]);
		}
	}

}
