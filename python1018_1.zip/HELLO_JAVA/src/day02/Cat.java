package day02;

public class Cat extends Animal{
	boolean ssagaji = false;
	public void onepunch() {
		ssagaji = true;
	}
}
