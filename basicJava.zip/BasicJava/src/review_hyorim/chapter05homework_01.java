package review_hyorim;

public class chapter05homework_01 {
	public static void main(String[] args) {
		//다음 배열에서 최댓값과 최솟값을 구하시오.
		//{38, 94, 16, 3, 76, 94, 82, 47, 59, 8}
		
	}

}
