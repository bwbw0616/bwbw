arr = ["전우치","홍길동","이순신"]
# arr.append("신사임당")    =>맨 뒤에 배치됨
# arr.insert(3,"김구")      # 0번째부터 시작, 3을 넣으면 4번째 배치
arr.insert(len(arr),"김구")
print(arr)
