package chapter02;

public class problemnumber8 {
	public static void main(String[] args) {
		int lengthTop = 5;
		int lengthBottom = 10;
		int heigh = 7;
		double area = ((lengthTop+lengthBottom)*heigh/2.0);
		//2만 쓸 경우 답이 소수점까지 안나옴 
		System.out.println(area);
	}

}
