a = True
b = False

print(a + b)
print(a)
print(b)