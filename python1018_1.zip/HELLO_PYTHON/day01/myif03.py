a = 78
if a >= 90:
    print("수")
elif a >= 80:
    print("우")
elif a >= 70:
    print("미")
elif a >= 60:
    print("양")
else:
    print("가")