package chapter03;

import java.util.Scanner;

public class javaexample03 {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		//윤년은 4의 배수이어야 하고, 100의 배수는 아니어야 한다. 
        //또한 400의 배수는 무조건 윤년이 된다.

		System.out.print("윤년인지를 확인할 연도를 입력하세요:");
		//String name = scanner.nextLine();
		
		//if ("2100".equals(name))       {
		//	System.out.println("2100년은 윤년이 아닙니다");					
			
		int value = scanner.nextInt() ;
		
		if((value%4==0 && value%100!=0 ) ||(value%400==0))  {
			System.out.println("윤년입니다");
		
				
		} else {
			System.out.println("윤년이 아닙니다");
		}
	}
}
