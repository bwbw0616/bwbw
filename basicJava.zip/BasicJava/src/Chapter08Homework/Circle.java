package Chapter08Homework;

public class Circle extends Shape {
	private double radius;

	public Circle(double radius) {
		this.radius = radius;
	}

	@Override
	public double area() {
		return (radius * radius * Math.PI);
	}

	@Override
	public double perimeter() {
		return (2 * radius * Math.PI);
	}

	public String toString() {
		return String.format("도형의 종류 : 원, 둘레 : " + Math.floor(perimeter() * 100) / 100 + "cm, 넓이 : "
				+ Math.floor(area() * 100) / 100 + "cm²");
	}

}
