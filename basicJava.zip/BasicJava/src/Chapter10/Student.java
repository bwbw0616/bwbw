package Chapter10;

public class Student {

	//Lombok : 데이터 클래스에서 생성해야 할 생성자, 메소드 및 오버라이드 메소드를 자동 생성
	//테스트 문제 5번 참고
	private String name;
	private int age;
}
