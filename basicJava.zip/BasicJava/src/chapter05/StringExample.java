package chapter05;

import java.util.Scanner;

public class StringExample {
	public static void main(String[] args) {
		Scanner scanner =  new Scanner(System.in);
		
		scanner.next();
//	String name1 = new String("홍길동");
//	String name2 = new String("홍길동");
	    String name1 = "홍길동"; // String Literal
	    String name2 = "홍길동";
		
		if (name1.equals(name2)) {
			System.out.println("같음");
		}else{
			System.out.println("다름");
		}
		
	}

}
