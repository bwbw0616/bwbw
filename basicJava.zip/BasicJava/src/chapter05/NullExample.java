package chapter05;

import java.util.Scanner;

public class NullExample {
	public static void main(String[] args) {
		int age = 0;
		System.out.println(age);
		
		Scanner scanner1 = null;
		Scanner scanner2 = new Scanner(System.in);
		scanner1.next();
		scanner2.next();
		
	}

}
