package chapter02;

import java.util.Scanner;

public class exercise_03 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("원기둥밑변의반지름은? 단위:cm");
		float var1 =scanner.nextFloat();
		
		System.out.print("원기둥의높이는? 단위:cm");
		float var2 = scanner.nextFloat();
		
		double result = (var1 * var1 * Math.PI);
		System.out.println("원기둥밑면의넓이(단위:cm^2)"+result);
		double result2 = (var1*var1*var2*Math.PI);
		System.out.println("원기둥의부피(단위:cm^3):"+result2);
	}

}
