package Chapter07HomeworkBank2;

public class BankAccount {
	protected int balance;

	public BankAccount(int balance) {
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}
	/**
	 * 입금
	 * @param amount: 입금액
	 */
	public void deposit(int amount) {
		this.balance += amount;
	}
	/**
	 * 출금
	 * @param amount: 출금액
	 * @return  출금 성공시 true 실패시 false
	 */
	public boolean withdraw(int amount) {
		if (this.balance < amount) {
			return false;
		}
		this.balance -= amount;
		return true;
	}
	/**
	 * 이체
	 * @param amount: 이체 금액
	 * @param otherAccount: 이체할 계좌번호
	 * @return 이체 성공시 true 실패시 false
	 */
	public boolean transfer(int amount, BankAccount otherAccount) {
		if (withdraw(amount)) {
			otherAccount.deposit(amount);
			return true;
		}
		return false;
	}
	
	@Override
	public String toString() {
		return String.format("%,d", this.balance);
	}
}
