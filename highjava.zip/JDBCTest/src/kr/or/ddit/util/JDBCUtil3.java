package kr.or.ddit.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

/**
 * JDBC드라이버를 로딩하고 Connection객체를 생성하는 메서드로 구성된 클래스
 * 방법2) ResourceBundle객체를 이용하여 DB정보 가져오기
 * @author 306-19
 *
 */
public class JDBCUtil3 {
	
	static ResourceBundle bundle;  // 객체변수 선언
	
	static {
		
		bundle = ResourceBundle.getBundle("db");
		
		
		try {
			Class.forName(bundle.getString("driver"));
			System.out.println("드라이버 로딩 성공");
			
			
		}catch(ClassNotFoundException ex) {
			System.out.println("드라이버 로딩 실패");
			ex.printStackTrace();
		}
		
		
		try {
			Class.forName(bundle.getString("driver"));
			System.out.println("드라이버 로딩 성공!");
		}catch(ClassNotFoundException ex) {
			System.out.println("드라이버 로딩 실패!!!");
			ex.printStackTrace();
		}
	}
	
	
	public static Connection getConnection() {
		try {
			return DriverManager.getConnection(
					bundle.getString("url"),
					bundle.getString("username"),
					bundle.getString("password"));
		}catch(SQLException ex) {
			System.out.println("DB 연결 실패!!!");
			ex.printStackTrace();
			return null;
		}
	}
	
	public static void close(Connection conn, 
			Statement stmt, 
			PreparedStatement pstmt,
			ResultSet rs) {
		if(rs != null) try {rs.close();}catch(SQLException ex) {}
		if(pstmt != null) try {pstmt.close();}catch(SQLException ex) {}
		if(stmt != null) try {stmt.close();}catch(SQLException ex) {}
		if(conn != null) try {conn.close();}catch(SQLException ex) {}
	}
	
}
