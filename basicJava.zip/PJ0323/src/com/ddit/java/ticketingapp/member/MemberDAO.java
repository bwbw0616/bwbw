package com.ddit.java.ticketingapp.member;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.util.JdbcTemplate;

public class MemberDAO {
	private static MemberDAO instance;

	public static MemberDAO getInstance() {
		if(instance == null) {
			instance = new MemberDAO();
		}
		return instance;
	}

	private MemberDAO() {
	}

	private JdbcTemplate template = JdbcTemplate.getTemplate();

	public Map<String, Object> selectUser(String id, String password) {
		String sql = "select * from MEMBER where MEM_ID = ? and MEM_PASSWORD = ?";
		List<Object> param = new ArrayList<>();
		param.add(id);
		param.add(password);
		
		return template.selectOne(sql, param);
	}
	
	public int insertUser(List<Object> list) {
		String sql = " insert into MEMBER values(?, ?, ?, ?, ?, ?, ?, sysdate)";
		int result = template.update(sql, list);
		
		return result;
	}
}
