package Chapter09;

public interface Calculatable {
	public int sum();
}
