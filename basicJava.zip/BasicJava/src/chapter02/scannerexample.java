package chapter02;

import java.util.Scanner;

public class scannerexample {
	public static void main(String[] args) {
		// print println printf(format 형식)
		//"이름 : 홍길동, 나이 : 23세"
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("문자를 입력하세요 : ");
		String str =  scanner.next();// 사용자가 입력한 데이터를 문자로 가져온다.
		int integer =  scanner.nextInt(); // 정수로 가져온다.
		double db =  scanner.nextDouble();// double type로 가져온다.
		System.out.println(str);
		System.out.println(integer);
		System.out.println(db);
		scanner.close();
	}
}
