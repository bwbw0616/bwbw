package Chapter11;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateExample {
	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy년 MM월 dd일 E요일 hh:mm:ss");
		String format = dateFormat.format(date);
		System.out.println(format);
		
		//새로운 버전 1.8 (feat. JodaTime)
		
		LocalDateTime now = LocalDateTime.now();
		System.out.println(now);
		
		String format2 = now.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 E요일 hh:mm:ss"));
		System.out.println(format2);
		System.out.println(LocalDate.now());
		//chain 방식
		LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 E요일 hh:mm:ss"));
	}
}
