package JavaTest20220304;

public class PersonExample {
	public static void main(String[] args) {
		new Person("은지원", 45);
		new Person("김종민", 44);
	}
}
