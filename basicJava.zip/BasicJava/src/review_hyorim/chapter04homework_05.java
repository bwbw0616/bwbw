package review_hyorim;

import java.util.Random;
import java.util.Scanner;

public class chapter04homework_05 {
	public static void main(String[] args) {
		// 컴퓨터가 1부터 100 사이의 임의의 정수를 생성하면, 그 수를 맞추는 게임

		Scanner scanner = new Scanner(System.in);
		Random random = new Random();

		int me;
		int computer = (int) (Math.random() * 100) + 1;

		while (true) {

			System.out.println("1부터 100 사이의 정수 중 하나를 선택하세요 : ");
			me = scanner.nextInt();
			if (me > computer) {
				System.out.println("정답은 더 작은 수입니다.");
			} else if (me < computer) {
				System.out.println("정답은 더 큰 수입니다.");
			} else if (me == computer) {
				System.out.println("정답입니다.");
				break;

			}
		}scanner.close();
		

	}

}
