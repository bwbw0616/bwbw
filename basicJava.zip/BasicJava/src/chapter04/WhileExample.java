package chapter04;

public class WhileExample {
	public static void main(String[] args) {
		//for (int i = 1; i<= 10; i++) { 
		//	System.out.println(i);
		//}
		int i = 1;
		while (i <= 10) {
			System.out.println(i);
			i++;
		}
		
	}

}
