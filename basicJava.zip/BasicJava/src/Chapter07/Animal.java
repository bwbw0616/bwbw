package Chapter07;

public class Animal {
	public String sound() {
		return "소리를 낸다.";
	}

}
