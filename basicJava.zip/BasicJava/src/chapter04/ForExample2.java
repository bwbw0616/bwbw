package chapter04;

import java.util.Scanner;

public class ForExample2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
        System.out.println("1부터 합을 구하고자 하는 숫자를 입력하세요");
        int num = scanner.nextInt();
        
		int sum = 0;
		
		for(int i=1; i<=num; i++) {
			sum+= i;
		}
		System.out.printf("1부터 %d까지의 합은 %d입니다" ,num,sum);
		
	}

}
