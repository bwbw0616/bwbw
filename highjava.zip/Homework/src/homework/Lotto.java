package homework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Lotto {
	Scanner scanner = new Scanner(System.in);

	// 메뉴를 출력하고 실행할 메뉴 번호를 입력받아 반환하는 메서드
	public int menu() {
		System.out.println("==========================");
		System.out.println("  Lotto 프로그램");
		System.out.println("--------------------------");
		System.out.println(" 1. Lotto 구입");
		System.out.println(" 2. 프로그램 종료");
		System.out.println("==========================");
		System.out.print(" 메뉴 선택 : ");
		int number = scanner.nextInt();
		return number;
	}

	// 프로그램을 시작하는 메서드
	public void lottoStore() {
		while (true) {
			int choice = menu();
			switch (choice) {
			case 1: // 로또 구입
				buyLotto();
				break;
			case 2: // 프로그램 종료
				System.out.println();
				System.out.println("감사합니다.");
				return;
			default:
				System.out.println("번호를 잘못 선택했습니다. ('1' 또는 '2'를 입력하세요.)");
			}
		}
	}

	// 로또를 구매하는 메서드
	public void buyLotto() {
		System.out.println();
		System.out.println(" Lotto 구입 시작");
		System.out.println();
		System.out.println("(1000원에 로또번호 하나입니다.)");
		System.out.print("금액 입력 :");
		int money = scanner.nextInt();

		getLottoNum(money); // 로또번호를 생성하는 메서드 호출

		System.out.println("받은 금액은 " + money + "원이고, 거스름돈은 " + (money % 1000) + "원 입니다.");

	}

	// 금액에 맞는 로또 번호를 생성하는 메서드
	public void getLottoNum(int money) {
		Set<Integer> lottoSet = new HashSet<>();

		int amount = money / 1000; // 로또 구매 개수 구하기

		System.out.println();
		System.out.println("행운의 번호는 아래와 같습니다.");
		for (int i = 1; i <= amount; i++) {
			while (lottoSet.size() < 6) {
				lottoSet.add((int) (Math.random() * 45 + 1));
			}
			ArrayList<Integer> lottoList = new ArrayList<>(lottoSet);
			Collections.sort(lottoList);
			System.out.println("로또 번호" + i + " : " + lottoList);
			lottoSet.clear();
		}

	}

	public static void main(String[] args) {
		new Lotto().lottoStore();
	}

}