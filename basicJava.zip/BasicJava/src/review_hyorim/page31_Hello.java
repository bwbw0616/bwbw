package review_hyorim;

public class page31_Hello {
	public static void main(String[] args) {
		System.out.println("Hello, Java");
		
	}
	
}