package com.ddit.java.temp;

public class ConcertMain {

	public static void main(String[] args) {
		
		ConcertImformation info = new ConcertImformation();

	}

}
