a = 0
b = '1'

print(a+int(b))
print(str(a)+b)
