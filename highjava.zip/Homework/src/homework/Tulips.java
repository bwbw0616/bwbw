package homework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Tulips {
	public static void main(String[] args) {
		
		try {
			FileInputStream fis = new FileInputStream("d:/D_Other/Tulips.jpg");
			FileOutputStream fos = new FileOutputStream("d:/D_Other/복사본_Tulips.jpg");
			int data = 0;
			while((data-fis.read())!=-1) {
				fos.write(data);
			}
			fis.close();
			fos.close();
			System.out.println("복사가 완료되었습니다.");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}