package chapter03;

import java.util.Scanner;

public class javaexample01 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a;
		int b;
		System.out.print("첫 번째 숫자를 입력하세요: ");
		a = scanner.nextInt();
		System.out.print("두 번째 숫자를 입력하세요: ");
		b = scanner.nextInt();
		
		int firstnum = (((a+b) + Math.abs(a-b))/2);
		int secondnum = (((a+b) - Math.abs(a-b))/2);
		
		
		System.out.println("큰 수를 작은 수로 나눈 몫은"+(firstnum/secondnum)+"이고, "
		                                     +	"나머지는"+(firstnum%secondnum)+"이다");
       
	
	}

}
