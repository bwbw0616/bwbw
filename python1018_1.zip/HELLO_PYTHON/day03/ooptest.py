class Animal:
    age = 1
    def getAge(self):
        self.age = self.age + 1

class Cat(Animal):
    ssagaji = False
    def onepunch(self):
        self.ssagaji = True
        
# class OopTest():
#     ssakbagaji = "냥냥"
#     def nyangnyangpunch(self):
#         print(self.ssakbagaji)

cute = Animal()
print(cute.age)
cat = Cat()
print(cat.ssagaji)
cute.getAge()
print(cute.age)
# cuteCat = OopTest()
# cuteCat.nyangnyangpunch()
cat.onepunch()
print(cat.ssagaji)
