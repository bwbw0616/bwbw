package chapter06;

public class Calculator {
	boolean flag;
	// 반환 값이 없으면 void
	void powerOn() {
		System.out.println("전원을 켭니다.");
	}
	//가변인수(Variable Arguments) : vararg jdk 1.5이상부터 사용 가능
	int plus(int ... x) {
		int result = 0;
		for(int i = 0; i < x.length; i++) {
		       result += x[i];
		}
		return result;
	}
	
//	int plus(int x, int y) {
//		int result = x + y;
//		return result;		
//	}
	
	double divide(int x, int y) {
		double result = (double) x/y;
		return result;
	}
	
	String getNumber() { 
		return "숫자";
	}
	
	void powerOff() {
		
		if (flag ) {
		    System.out.println("전원을 끕니다. ");
		}else{
			System.out.println("작습니다.");
			return;
		}
		System.out.println("종료합니다.");
		}
		
	}



