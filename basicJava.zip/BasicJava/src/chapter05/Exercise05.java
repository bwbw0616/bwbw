package chapter05;

public class Exercise05 {
	public static void main(String[] args) {
		int [][] array = {
				{95,86},
				{83,92,96},{78,83,93,87,88}
		};
		int sum = 0;
		double avg = 0.0;
		
		sum += array[0][0];
		sum += array[0][1];
		sum += array[1][0];
		sum += array[1][1];
		sum += array[1][2];
		sum += array[2][0];
		sum += array[2][1];
		sum += array[2][2];
		sum += array[2][3];
		sum += array[2][4];
		
		avg = sum / 10.0;
		
		System.out.println("sum: "+sum);
		System.out.println("avg: "+avg);

		
	}

}
