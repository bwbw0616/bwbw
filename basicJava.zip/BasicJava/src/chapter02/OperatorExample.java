package chapter02;

public class OperatorExample {
	public static void main (String[] args) {
		int x = 1;
		int y = 1;
		int result1 = ++x + 10; // 2 + 10 =>12
		int result2 = y++ + 10; // 1 + 10 => 11
		
		
	}

}
