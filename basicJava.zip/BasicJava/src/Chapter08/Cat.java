package Chapter08;

public class Cat implements Soundable{
	
	@Override
	public String sound(){
		return "냥";
		
	}
}	