from flask import Flask
from flask.globals import request
from flask.templating import render_template

from flask.json import jsonify
from day12axios.dao_emp import DaoEmp

app = Flask(__name__,static_url_path='')
de = DaoEmp()

@app.route('/')
@app.route('/emp')
def emp():
    return render_template('emp.html')

@app.route('/emp.ajax',methods=['POST'])
def emp_ajax():
    data = request.get_json()
    print("data",data['e_id'])
    return jsonify({'msg': '저장 완료!'})

@app.route('/emp_list.ajax',methods=['POST'])
def emp_list_ajax():
    de = DaoEmp()
    list = de.myselects()
    return jsonify(list)


@app.route('/emp_one.ajax',methods=['POST'])
def emp_one_ajax():
    data = request.get_json()
    e_id    = data['e_id']
    de = DaoEmp()
    emp = de.myselect(e_id)
    return jsonify(emp)


@app.route('/emp_add.ajax',methods=['POST'])
def emp_add_ajax():
    data = request.get_json()
    e_id    = data['e_id']
    e_name  = data['e_name']
    sex     = data['sex']
    addr    = data['addr']
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.myinsert(e_id, e_name, sex, addr)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})

@app.route('/emp_mod.ajax',methods=['POST'])
def emp_mod_ajax():
    data = request.get_json()
    e_id    = data['e_id']
    e_name  = data['e_name']
    sex     = data['sex']
    addr    = data['addr']
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.myupdate(e_id, e_name, sex, addr)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})


@app.route('/emp_del.ajax',methods=['POST'])
def emp_del_ajax():
    data = request.get_json()
    e_id    = data['e_id']
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.mydelete(e_id)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})


if __name__ == '__main__':
    app.run(debug=True)
    
    
    
    
    
    
    
    
    