package Chapter09확인문제09_02_02;

public class Anonymous {

}
