package com.ddit.java.temp;

import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.SimpleFormatter;

import oracle.jdbc.driver.OracleDriver;

public class Temp3 {
	public static void main(String[] args) {
//		System.out.println(" << CAST INFO >>");
//		System.out.println("------------------------------------------------");
//		
//		
//		JdbcTemplate template = JdbcTemplate.getTemplate();
//		String sql = "";
//		sql += "SELECT CAST_NAME AS 이름,";
//		sql += "       CAST_DATE AS 날짜";
//		sql += "  FROM CAST";
//		
//		List<Map<String, Object>> list = template.selectList(sql);
//		
//		for(int i = 0; i < list.size(); i++) {
//			System.out.print("이름: " + list.get(i).get("이름") + " | ");
//			System.out.println("날짜: " + FormatUtil.format(list.get(i).get("날짜")));
//		}	
//	
//		String enter = ScanUtil.nextLine();		

		System.out.println("좌석을 선택해주세요.");
		System.out.println("-------------------------------------");
		System.out.println("    1 2 3 4 5 6 7 8 9 10");

		

		for (int i = 0; i < getNumLength("V%") / 2; i++) {
			selectSeatLeft(i, "V");
		}
		
		for (int j = 0; j < 2; j++) {
			System.out.print("V" + (j + 1) + "  ");
			for (int i = 0; i < getNumLength("V%") / 2; i++) {
				System.out.print("□ ");
			}
			System.out.println();
		}
		for (int j = 0; j < 3; j++) {
			System.out.print("R" + (j + 1) + "  ");
			for (int i = 0; i < getNumLength("RO%") / 3; i++) {
				System.out.print("□ ");
			}
			System.out.println();
		}
		for (int j = 0; j < 3; j++) {
			System.out.print("S" + (j + 1) + "  ");
			for (int i = 0; i < getNumLength("S%") / 3; i++) {
				System.out.print("□ ");
			}
			System.out.println();
		}
		for (int j = 0; j < 3; j++) {
			System.out.print("A" + (j + 1) + "  ");
			for (int i = 0; i < getNumLength("RE%") / 3; i++) {
				System.out.print("□ ");
			}
			System.out.println();
		}
		System.out.println("좌석 타입을 선택하세요. ex) A6");
		System.out.println("1. VIP석 2. R석 3. S석 4. A석 5. 뒤로 가기");
		System.out.println("---------------------------------------------------------------------");
	}

	public static int getNumLength(String str) {
		String sql = "";
		sql += " select RANK,";
		sql += "        COUNT(*) as 수";
		sql += "   from SEAT";
		sql += "  where RANK like ?";
		sql += "  group by RANK";

		JdbcTemplate template = JdbcTemplate.getTemplate();
		Map<String, Object> map = template.selectOne(sql, str);
		int vlength = Integer.parseInt(String.valueOf(map.get("수")));

		return vlength;
	}

	public static String selectSeatLeft(int num, String param) {
		Map<String, Object> map = null;
		String seatLeft = null;

		JdbcTemplate template = JdbcTemplate.getTemplate();
		String sql = "select SEAT_LEFT from SEAT where SEAT_NO = ?";

		if (num >= 10) {
			map = template.selectOne(sql, param + "0" + (num + 1));
		}
		else {
			map = template.selectOne(sql, param + (num + 1));
		}

		if (String.valueOf(map.get("SEAT_LEFT")).equals("Y")) {
			seatLeft = "□";
		} else if (String.valueOf(map.get("SEAT_LEFT")).equals("N")) {
			seatLeft = "■";
		}
		return seatLeft;
	}
}
