package chapter02;

public class hr1 {
   public static void main(String[] args) {
	   String name = "홍길동";
	   String description = "홍길동전은  \"소설\"입니다.";
	   System.out.println(name);
	   System.out.println(description);
	   long value = 50000000000L;
	   Shorts = 1000;
	   byte b = 120;
	   boolean flag = false;
	   double v2 = 2e-323;
	   float v3 = 1e2f;
	   
	   
   }
}
