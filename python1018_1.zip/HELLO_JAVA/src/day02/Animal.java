package day02;

public class Animal {
	int age = 1;
	public void getOld() {
		age++;
	}
}
