package chapter02;

import java.util.Random;

public class randomexample {
	public static void main(String[] args) {
		//Math.random() ;  //랜덤이 정해져 있음
		Random random= new Random();  //중요
		//pseudo : 의사, 가짜
		//bound: 랜덤의 개수
		int dice = random.nextInt(6) + 1;  // 0부터 5까지

		
	//	System.out.println((int)(Math.random()*6)+1);
		
		//5부터 11까지 랜덤
		
		int ranNum = random.nextInt(7) + 5;
		
		
	
	}

}
