package kr.or.ddit.basic;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * 파일 출력 예제
 * @author sem
 * 
 */
public class T06_FileStreamTest {
	public static void main(String[] args) {
		// 파일에 출력하기
		FileOutputStream fos = null;

		try {
			// 출력용 스트림 객체 생성
			fos = new FileOutputStream("d:/D_Other/out.txt");
			for (char ch = 'A'; ch <= 'Z'; ch++) {
				fos.write(ch);
			}
			System.out.println("파일 쓰기 작업 완료...");

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		/////////////////////////////

		FileInputStream fis = null;

		try {
			fis = new FileInputStream("d:/D_Other/out.txt");

			int data = 0;

			// 읽어온 값이 -1이면 파일의 끝까지 다 읽었다는 의미이다.
			while ((data = fis.read()) != -1) {
				// 읽어온 자료 출력하기
				System.out.print((char) data);
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
