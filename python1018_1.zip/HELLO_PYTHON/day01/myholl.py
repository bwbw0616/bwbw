import random

computer = ""
mine = ""
result = ""

mine = input("홀짝 게임을 시작합니다.")

rnd = random.random()

if rnd > 0.5:
    computer = "홀"
else:
    computer = "짝"

if computer == mine:
    result = "이겼습니다"
else :
    result = "졌습니다"

print("computer",computer)
print("mine",mine)
print("result",result)