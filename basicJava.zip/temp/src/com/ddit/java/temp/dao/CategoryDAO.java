package com.ddit.java.temp.dao;

import java.util.Map;

import com.ddit.java.temp.JdbcTemplate;

public class CategoryDAO {
	private static CategoryDAO instance;
	private CategoryDAO() {
		
	}
	public static CategoryDAO getInstance() {
		if(instance == null) {
			instance = new CategoryDAO();
		}
		return instance;
	}
	
	private JdbcTemplate template = JdbcTemplate.getTemplate();
	
}
