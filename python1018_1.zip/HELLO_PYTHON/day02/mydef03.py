import random

def myrandom():
    return random.random()

rnd = myrandom()
print("rnd",rnd)