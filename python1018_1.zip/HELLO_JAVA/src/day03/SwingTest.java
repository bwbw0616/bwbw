package day03;

import javax.swing.JFrame;

public class SwingTest {
	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		f.setVisible(true);
	}
}
