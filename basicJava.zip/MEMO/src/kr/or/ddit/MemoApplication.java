package kr.or.ddit;

import java.util.List;

import java.util.Scanner;

public class MemoApplication {

	public static void main(String[] args) throws Exception {

		// VO객체, DAO, Service(transaction), Controller, View: MVC 패턴

		Scanner scanner = new Scanner(System.in);

		MemoService service = new MemoService();

		while (true) {

			System.out.println("메뉴를 입력하세요.");

			int menu = Integer.parseInt(scanner.next());

			switch (menu) {

			case 1:

				List<MemoVO> list = service.getMemoList("");

				for (MemoVO vo : list) {

					System.out.println(vo);

				}

				break;

			case 2:

				System.out.print("제목 입력: ");

				String title = scanner.next();

				System.out.print("내용 입력: ");

				String contents = scanner.next();

				int insertMemo = service.insertMemo(new MemoVO(title, contents));

				if (insertMemo == 1) {

					System.out.println("등록되었습니다.");

				} else {

					System.out.println("등록에 실패하였습니다.");

				}

				break;

			}

		}

	}

}