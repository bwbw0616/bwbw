from PyQt5 import uic
from PyQt5.Qt import QMainWindow, QMessageBox
from anaconda_navigator.utils.qthelpers import qapplication
import sys
import random

form_class = uic.loadUiType("pyqt11.ui")[0]

class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        self.com = "123"
        self.pb.clicked.connect(self.button1Function)
    #   콘솔에 정답이 나오는 소스, 정답 알고 싶으면 이 주석 풀기self.setCom()
    
    def setCom(self):
        arr9 = [1,2,3,4,5,6,7,8,9]

        for i in range(10):
            rnd = int(random.random()*9)
            a= arr9[rnd]
            b = arr9[0]
            arr9[0]=a
            arr9[rnd]=b
        
        self.com = str(arr9[0]) + str(arr9[1]) + str(arr9[2])
        print(self.com)             
        
    def button1Function(self) :
        mine = self.le.text()
        bs = self.getBallStrike(self.com,mine)
        
        str_old = self.te.toPlainText()
        
        self.te.setText(str_old+mine+" " + bs + "\n")
        self.le.setText("")
        
        if bs == "3S0B":
            QMessageBox.about(self, 'baseball', '드디어 이겼습니다' )
    
    def getBallStrike(self,com,mine):
        strike = 0
        ball = 0
        
        c1 = com[0:1]
        c2 = com[1:2]
        c3 = com[2:3]
        
        m1 = mine[0:1]
        m2 = mine[1:2]
        m3 = mine[2:3]
        
        
        if c1 == m1 : strike += 1
        if c2 == m2 : strike += 1
        if c3 == m3 : strike += 1
        
        if c1 == m2 or c1 == m3: ball+=1
        if c2 == m1 or c2 == m3: ball+=1
        if c3 == m1 or c3 == m1: ball+=1
        
        return str(strike)+"S"+str(ball)+"B"
        

if __name__ == "__main__" :
    app = qapplication(sys.argv) 

    myWindow = WindowClass() 

    myWindow.show()

    app.exec_()