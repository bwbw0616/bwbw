package chapter02;

import java.util.Scanner;

public class exercise_02 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("빛의 속도는? 단위:km/s");
		float var1 =scanner.nextFloat();
		//빛의 속도 = 300000km/s
		System.out.print("프록시마 센타우리에서 지구까지의 거리는? 단위:km");
		float var2 = scanner.nextFloat();
		//프록시마 센타우리에서 지구까지의 거리 = 40e12km
		double result =(double) (var2)/(var1)/60/60/24/365;
		
		System.out.println(result);
		scanner.close();
	}

}
