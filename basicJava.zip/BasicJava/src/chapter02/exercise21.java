package chapter02;

import java.util.Scanner;

public class exercise21 {
	public static void main(String[] args) {
		// 입력
		Scanner scanner = new Scanner(System.in);
		System.out.println("가로의 길이는?(단위: m)");
		double width = scanner.nextDouble();
		System.out.println("세로의 길이는?(단위:m)");
		double heigh = scanner.nextDouble();
		
		//처리
		//넓이 = 가로*세로
		double area = width * heigh;
		//둘레 = (가로 + 세로)*2;
	}

}
