package kr.or.ddit.lprod.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.lprod.vo.LprodVO;

public class LprodDaoImpl implements ILprodDao {
	// 1. 자기 자신 참조값이 저장될 변수를 private static으로 선언한다.
	private static LprodDaoImpl dao;
	
	// 2. 모든 생성자의 접근 제한자를 private으로 한다.
	private LprodDaoImpl() {
		
	}
	// 3. 자기 자신 참조값을 반환하는 메소드를 public static으로 작성한다.
	// (이 때, 메소드명은 보통 'getInstance'로 한다.)
	public static LprodDaoImpl getInstance() {
		// 3-1. 1번의 변수 값이 null이면 자신의 객체를 생성해서 저장한다.
		if(dao==null) dao = new LprodDaoImpl();
		
		// 3-2. 1번의 변수값을 반환한다.
		return dao;
	}

	@Override
	public int getMaxLprodId(Connection conn) throws SQLException {
		int maxNum = 0;	// 반환값이 저장될 변수 선언
		
		String sql = "select nvl(max(lprod_id),0) maxnum from lprod";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		ResultSet rs = pstmt.executeQuery();
		
		if(rs.next()) {		// select한 결과가 1개의 레코드일 경우 if문으로 비교해도 된다.
			maxNum = rs.getInt("maxnum");
		}
		
		if(rs != null) try {rs.close(); }catch(SQLException e) {}
		if(pstmt != null) try {pstmt.close(); }catch(SQLException e) {}
		
		return maxNum;
	}

	@Override
	public int getLprodBuCount(Connection conn, String gu) throws SQLException {
		int count = 0;
		
		String sql = "select count(*) cnt from lprod where lprod_gu = ?";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, gu);
		
		ResultSet rs = pstmt.executeQuery();
		
		if(rs.next()) {
			count = rs.getInt("cnt");
		}
		
		if(rs != null) try {rs.close(); }catch(SQLException e) {}
		if(pstmt != null) try {pstmt.close(); }catch(SQLException e) {}
		
		return count;
	}

	@Override
	public List<LprodVO> getAllLprod(Connection conn) throws SQLException {
		List<LprodVO> lprodList = null;
		
		String sql = "select * from lprod";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		ResultSet rs = pstmt.executeQuery();
		
		lprodList = new ArrayList<LprodVO>();
		
		while(rs.next()) {
			// VO객체에서 DB에서 가져온 값을 셋팅한다.
			LprodVO lvo = new LprodVO();
			lvo.setLprodId(rs.getInt("lprod_id"));
			lvo.setLprodGu(rs.getString("lprod_gu"));
			lvo.setLprodNm(rs.getString("lprod_nm"));
			
			// 데이터가 셋팅된 VO객체를 List에 추가한다.
			lprodList.add(lvo);
		}
		
		if(rs != null) try {rs.close(); }catch(SQLException e) {}
		if(pstmt != null) try {pstmt.close(); }catch(SQLException e) {}
		
		return lprodList;	// List객체 반환
	}

	@Override
	public int insertLprod(Connection conn, LprodVO lpvo) throws SQLException {
		int cnt = 0;
		
		String sql = "insert into lprod(lprod_id, lprod_gu, lprod_nm)"
				+ "values (?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, lpvo.getLprodId());
		pstmt.setString(2, lpvo.getLprodGu());
		pstmt.setString(3, lpvo.getLprodNm());
		
		cnt = pstmt.executeUpdate();	// select문이 아닐 때..
		
		if(pstmt!=null) try { pstmt.close(); } catch(SQLException e) {}
				
		return cnt;
	}

}
