package chapter06;

public class Student1 {
	String name;
	String addr;
	int no ;
	public Student1() {
	    //TODO Auto-generated constructor stub	
	}
	//생성자
	public Student1(String name) {
		this.name = "홍길동";
	}
	public Student1(int no) {
		this.no = no;
	}
	public Student1(String name, int n) {
		this(name) ;
		no = n;
	}
	public Student1(int n,String nm) {
		name = nm;
		no = n;
	}
	public Student1(String name, String a) {
		this(name);
		addr = a;
		// TODO Auto-generated constructor stub
	
		
	}
	
		
}