def add(a,b):
    return a+b
def minus(a,b):
    return a-b
def multiply(a,b):
    return a*b
def divide(a,b):
    return a/b


sum = add(5,6)
min = minus(5,6)
mul = multiply(5,6)
div = divide(5,6)

print("sum",sum)
print("min",min)
print("mul",mul)
print("div",div)