package com.ddit.java.temp;

import com.ddit.java.temp.view.View;

public class Temp {

	public static void main(String[] args) {
		View view = View.getInstance();
		
		view.showHomeMenu();
	}

}
