package chapter02;

import java.util.Scanner;

public class exercise_04 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("500원짜리 동전의 갯수는?");
		 int num1 = scanner.nextInt();
		System.out.print("100원짜리 동전의 갯수는?");
		int num2 = scanner.nextInt();
		System.out.print("50원짜리 동전의 갯수는?");
		int num3 = scanner.nextInt();
		System.out.print("10원짜리 동전의 갯수는?");
		int num4 = scanner.nextInt();
		 
		int result = (num1*500 + num2*100+ num3*50+num4*10);
		System.out.printf("동전총액수:%d원\n",result);
		
	}

}
