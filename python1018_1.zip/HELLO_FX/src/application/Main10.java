package application;
	


import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;



public class Main10 extends Application {
	TextField tfMine;
	TextField tfCom;
	Button btn;
	TextArea ta;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("main10.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			tfCom = (TextField) scene.lookup("#tfCom");
			tfMine = (TextField) scene.lookup("#tfMine");
			ta = (TextArea) scene.lookup("#ta");
			Button btn = (Button) scene.lookup("#btn");
			
			
			tfMine.setOnKeyPressed(new EventHandler<KeyEvent>() {
				@Override
				public void handle(KeyEvent event) {
					if(event.getCode()== KeyCode.ENTER) {
						myclick();
					}
				}
			});
			
			btn.setOnMouseClicked(new EventHandler<Event>() {
				@Override
				public void handle(Event event) {
					myclick();
				}
			});
						
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public String drawStar(int cnt) {
		String ret = "";
		for(int i = 0; i < cnt; i++) {
			ret+="*";
		}
		ret += "\n";
		return ret;
	}
	
	public void myclick() {
		String str_first = tfMine.getText();
		String str_last = tfCom.getText();
		int ifirst = Integer.parseInt(str_first);
		int ilast = Integer.parseInt(str_last);
		
		String txt = "";
		
		for(int i = ifirst; i <= ilast; i++) {
			txt += drawStar(i);
		}
		
		
		for(int i = ifirst; i >= ilast; i--) {
			txt += drawStar(i);
		}
		
		
		ta.setText(txt);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
