package com.ddit.java.temp.service;

import java.util.Map;

import com.ddit.java.temp.dao.MemberDAO;

public class MemberService {
	private static MemberService instance = new MemberService();
	
	public static MemberService getInstance() {
		return instance;
	}
	
	private MemberService() {
	}
	
	private MemberDAO dao = MemberDAO.getInstance();
	
	public boolean login(String id, String password) {
		Map<String, Object> user = dao.selectUser(id, password);
		
		if(user == null) {
			return false;
		}
		else {
			return true;
		}
	}
}
