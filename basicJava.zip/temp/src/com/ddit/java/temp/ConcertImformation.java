package com.ddit.java.temp;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ConcertImformation {
	Scanner scanner = new Scanner(System.in);

	public ConcertImformation() {

		JdbcTemplate template = JdbcTemplate.getTemplate();

		System.out.println();
		System.out.println("   << 티켓 정보 >>");
		System.out.println("--------------------------------------------------------------");

		String sql = "";
		sql += " SELECT A.CON_NAME as 공연명,";
		sql += "        A.CON_DATE as 날짜,";
		sql += "        B.CAST_NAME as 주연,";
		sql += "        A.PLACE_NAME as 장소명,";
		sql += "        A.TICKET_PRICE as 가격";
		sql += "   FROM (SELECT C.CON_ID,";
		sql += "                C.CON_NAME,";
		sql += "                C.CON_DATE,";
		sql += "                D.PLACE_NAME";
		sql += "           FROM CONCERT C,PLACE D";
		sql += "          WHERE C.PLACE_ID=D.PLACE_ID) A,";
		sql += "                CASTING F, CAST B";
		sql += "  WHERE A.CON_ID = F.CON_ID";
		sql += "    AND F.CAST_ID = B.CAST_ID";
		sql += "    AND F.CON_ID= '2022022500001'";// 씨어터 이문세, 만7세이상, 20220325공연

		List<Map<String, Object>> list = template.selectList(sql);

		for(int i = 0; i < list.size(); i++) {
		System.out.println("공연명: " + list.get(i).get("공연명"));
		System.out.println("날짜: " + FormatUtil.format(list.get(i).get("날짜")));
		System.out.println("장소명: " + list.get(i).get("장소명"));
		System.out.println("주연: " + list.get(i).get("주연"));
		System.out.println("가격: " + "A석 " + list.get(i).get("TICKET_PRICE"));
		System.out.println("--------------------------------------------------------------");
		}
		String concert = scanner.nextLine();

	}
}
