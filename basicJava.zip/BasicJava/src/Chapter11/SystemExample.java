package Chapter11;

import chapter06.Calculator;

public class SystemExample {
	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
		Class<? extends Calculator> clazz = calculator.getClass();
		clazz.getFields();
		clazz.getDeclaredFields();
		clazz.getMethods();
		clazz.getDeclaredMethods();
		
//		Class.forName("chapter06.Calculator");
		
//		Calculator.class;
		
		
		long millis = System.currentTimeMillis();
		System.out.println(millis);
		double result = millis / 1000.0 / 60 / 60 / 24 / 365;
		System.out.println(result);
	}
}
