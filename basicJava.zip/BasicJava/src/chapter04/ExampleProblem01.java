package chapter04;

import java.util.Scanner;

public class ExampleProblem01 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//삼각형을 판별하는 방법은 가장 긴 변의 길이가 
		//다른 두 변의 길이의 합보다 작으면 삼각형을 만들 수 있다.
		//a는 첫 번째 변의 길이, b는 두 번째 변의 길이, c는 세 번째 변의 길이
		int a ;
		int b ;
		int c ;
			System.out.println("삼각형의 첫 번째 변의 길이를 입력하세요: ");
			a=scanner.nextInt();
				
			System.out.println("삼각형의 두 번째 변의 길이를 입력하세요: ");
			b=scanner.nextInt();
			
			System.out.println("삼각형의 세 번째 변의 길이를 입력하세요: ");
			c=scanner.nextInt();
		
			if((a+b>c)&&(c>b)&&(c>a)) {
			System.out.println("삼각형을 만들 수 있습니다.");
			}else if((a+c>b)&&(b>c)&&(b>a)) {
				System.out.println("삼각형을 만들 수 있습니다.");
			}else if((b+c>a)&&(a>c)&&(a>b)) {
				System.out.println("삼각형을 만들 수 있습니다.");
			}else {
			System.out.println("삼각형을 만들 수 없습니다.");
		
			}
		}
	
}

