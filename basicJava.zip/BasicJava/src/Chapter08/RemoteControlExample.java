package Chapter08;

public class RemoteControlExample {
	public static void main(String[] args) {
//		RemoteControl rc = new Television();
//		RemoteControl rc = new Audio();
		RemoteControl rc = new SmartTelevision();
		
		rc.turnOn();
		rc.setVolume(8);
		rc.turnOff();
		
		Searchable rc2 = new SmartTelevision();
		rc2.search("www.google.co.kr");
	}
}
