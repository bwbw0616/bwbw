package review_hyorim;

import java.util.Scanner;

public class chapter02homework_03 {
	public static void main(String[] args) {
		// 원기둥 밑면의 넓이와 부피를 계산하는 프로그램
		// 원주율 : Math.PI 사용

		Scanner scanner = new Scanner(System.in);

		System.out.println("원기둥 밑변의 반지름을 입력하시오.(단위:cm):");
		float r = scanner.nextFloat();

		System.out.println("원기둥의 높이를 입력하시오.(단위:cm):");
		float h = scanner.nextFloat();

		double area = (Math.PI) * r * r;

		double volume = (area) * h;

		System.out.println("원기둥 밑변의 넓이는 " + area + "이고, 원기둥의 부피는" + volume + "이다.");

		scanner.close();
	}

}
