package kr.or.ddit.lprod.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.lprod.vo.LprodVO;

public interface ILprodDao {
	/**
	 * 상품 분류 번호(LPROD_ID) 중 제일 큰 값을 찾아 반환하는 메소드
	 * @param conn	Connection 객체
	 * @return		상품 분류 번호 중 제일 큰 값
	 * @throws SQLException
	 */
	public int getMaxLprodId(Connection conn) throws SQLException;
	
	/**
	 * 상품 분류 코드(LPROD_GU)를 인수값으로 받아서 해당 분류 코드의 개수를 반환하는 메소드
	 * @param conn
	 * @param gu 검색할 상품 분류 코드
	 * @return 검색한 상품 분류 코드의 개수
	 * @throws SQLException
	 */
	public int getLprodBuCount(Connection conn, String gu) throws SQLException;
	
	/**
	 * 상품 분류 테이블(LPROD)의 전체 데이터를 List에 담아 반환하는 메소드
	 * @param con
	 * @return 전체 LPROD데이터가 저장된 List 객체
	 * @throws SQLException
	 */
	public List<LprodVO> getAllLprod(Connection con) throws SQLException;
	
	/**
	 * 추가할 데이터가 저장된 LprodVO객체를 인수값으로 받아서 insert하는 메소드
	 * @param conn
	 * @param lpvo 추가할 데이터가 저장된 LprodVO객체
	 * @return 추가작업 성공 : 1, 추가작업 실패 : 0
	 * @throws SQLException
	 */
	public int insertLprod(Connection conn, LprodVO lpvo) throws SQLException;
	
}
