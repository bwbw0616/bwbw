package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDAO;
import kr.or.ddit.member.dao.MemberDAOImpl;
import kr.or.ddit.member.vo.MemberVO;

public class MemberServiceImpl implements IMemberService {
	
	private IMemberDAO memDAO;
	
	public MemberServiceImpl() {
		memDAO = new MemberDAOImpl();
	}
	
	@Override
	public int insertMember(MemberVO mv) {

		return memDAO.insertMember(mv);
	}

	@Override
	public int updateMember(MemberVO mv) {
		return memDAO.updateMember(mv);
	}

	@Override
	public int deleteMember(String memId) {
		return memDAO.deleteMember(memId);
	}

	@Override
	public List<MemberVO> getAllMemberList() {
		return memDAO.getAllMemberList();
	}

	@Override
	public boolean checkMember(String memId) {
		return memDAO.checkMember(memId);
	}

	@Override
	public List<MemberVO> searchMemberList(MemberVO mv) {
		
		return memDAO.searchMemberList(mv);
	}

}
