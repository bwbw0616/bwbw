package Chapter13;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class StudentHashMapExample {
	public static void main(String[] args) {
		Map<Student,Integer> map = new HashMap<Student, Integer>();
		map.put(new Student(1, "홍길동"), 95);
		map.put(new Student(1, "홍길동"), 90);
		map.put(new Student(2, "이순신"), 100);
		map.put(new Student(3, "유관순"), 98);
		
		System.out.println(map.size());
		
		// key 만 가져오기
		Set<Student> keySet = map.keySet();
		for (Student student : keySet) {
			System.out.println(student);
		}
		//value만 가져오기
		Collection<Integer> values = map.values();
		for (Integer integer : values) {
			System.out.println(integer);
		}
		//entry 가져오기
		Set <Entry<Student,Integer>> entrySet = map.entrySet();
		for (Entry<Student,Integer> entry : entrySet) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
	}
}