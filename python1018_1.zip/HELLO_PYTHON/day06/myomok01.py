from PyQt5 import uic
from PyQt5.Qt import QMainWindow, QLabel, QPixmap
from anaconda_navigator.utils.qthelpers import qapplication
import sys

form_class = uic.loadUiType("myomok01.ui")[0]

class WindowClass(QMainWindow, form_class):
    def __init__(self) :
        QMainWindow.__init__(self)
        self.setupUi(self)
        
        pixmap = QPixmap('0.png')
        mylbl = QLabel("sdfs", self) 
        mylbl.setPixmap(pixmap)
        
        mylbl2 = QLabel("ssdagdsagasfs", self)
        mylbl2.move(40,0)
        mylbl2.setPixmap(pixmap)
        
        
        self.show()
        
        self.pb.clicked.connect(self.button1Function)
        self.lbl.clicked.connect(self.mychange)
        
    def mychange(self):
        print("mychange")
        
    def button1Function(self) :
        self.lbl.setText("Good Evening")

if __name__ == "__main__" :
    app = qapplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec_()