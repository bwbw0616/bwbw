package chapter02;

import java.util.Scanner;

public class logicaloperatorexample {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
				
		System.out.println("문자 하나를 입력하세요: ");
		int charCode = scanner.next().charAt(0);//A
		System.out.println(charCode >= 65 && charCode <= 90);
		System.out.println(charCode >= 65 & charCode <= 90);
		
		System.out.println("숫자를 입력하세요: ");
		int value = scanner.nextInt();
		System.out.println(value % 2 == 0 || value % 3 == 0 || value % 5==0);
		System.out.println(value % 2 == 0 | value % 3 == 0);
	}

}
