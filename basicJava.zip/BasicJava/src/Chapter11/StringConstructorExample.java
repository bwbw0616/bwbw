package Chapter11;

import java.util.Scanner;

public class StringConstructorExample {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("내용을 입력하세요 : ");
		String message = scanner.next();
		
		byte[] bytes = message.getBytes();
		//bytes를 암호화
		//데이터를 B에게 전송
		
		scanner.close();
	}

}
