package kr.or.ddit.basic;

/*
 * 싱글 스레드 프로그램
 * @author sem
 * 
 */
public class T01_ThreadTest {
	public static void main(String[] args) {
		for(int i = 1; i <= 2000; i++)	{
			System.out.print("*");
		}
		
		System.out.println();
		
		for(int i = 1; i <= 2000; i++) {
			System.out.print("$");
		}
	}
}
