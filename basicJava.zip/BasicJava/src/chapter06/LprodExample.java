package chapter06;

public class LprodExample {
	public static void main(String[] args) {
		Lprod lprod1 = new Lprod();
		System.out.println("변경전 : " + lprod1.getId());
		lprod1.setId(100);
		System.out.println("변경후 : " + lprod1.getId());
		
	}

}
