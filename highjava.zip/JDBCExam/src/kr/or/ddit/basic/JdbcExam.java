package kr.or.ddit.basic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import kr.or.ddit.util.DBUtil;

/*
	다음 2가지 기능을 갖는 프로그램을 만들어 보자. (사용할 테이블 : Lprod)
	
	메뉴)
		1. 전체 목록 보기
		2. 데이터 추가하기
		0. 프로그램 끝.
	
	2번 메뉴의 처리 조건)
		- lprod_gu와 lprod_nm은 사용자로부터 직접 입력을 받아서 처리하고,
		  lprod_id는 현재의 lprod_id값 중 제일 큰 값보다 1 크게 한다.
		- 입력받은 Lpred_gu가 이미 등록되어 있는 값이면 다시 입력 받아서 처리한다.
 */
public class JdbcExam {
	private Scanner scan = new Scanner(System.in);
	
	// 시작 메서드
	public void jdbcStart() {
		while(true) {
			int choice = displayMenu();
			switch(choice) {
				case 1 :
					displayAll();
					break;
				case 2 :
					insert();
					break;
				case 0 :
					System.out.println("프로그램을 종료합니다..");
					return;
				default :
					System.out.println("작업 번호를 잘못 입력했습니다.");
					System.out.println("다시 선택하세요.");
			}
		}
	}
	
	// 데이터를 추가하는 메서드
	private void insert() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			/*
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"SHR98",
					"java");
			*/
			conn = DBUtil.getConnection();
			
			// lprod_id는 현재의 lprod_id값 중 제일 큰 값보다 1 크게 한다.
			String sql = "select nvl(max(lprod_id), 0) maxnum from lprod";
			
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			int maxnum = 0;
			
			if(rs.next()) {	// select한 결과가 1개의 레코드일 경우에는 if문으로 비교해도 된다.
				maxnum = rs.getInt("maxnum");
			}
			maxnum++;	// 가져온 값 증가하기
			
			// 사용했던 PreparedStatement객체를 재사용하려면 close()후 재사용하는 것이 좋다.
			if(pstmt != null) try {pstmt.close();}catch(SQLException e) {}
			
			//-----------------------------------------------------------------
			
			// 입력받은 Lpred_gu가 이미 등록되어 있는 값이면 다시 입력 받아서 처리한다.
			
			String gu;	// 상품 분류 코드(LPROD_GU)
			int count = 0;	// 입력한 상품 분류 코드의 개수가 저장될 변수
			do {
				System.out.println("상품 분류 코드(LPROD_GU) 입력 >> ");
				gu = scan.next();
				
				String sql2 = "select count(*) cnt from lprod"
						+ " where lprod_gu = ? ";
				pstmt = conn.prepareStatement(sql2);
				// Sql문의 물음표(?)에 들어갈 데이터 셋팅하기
				pstmt.setString(1, gu);
				
				rs = pstmt.executeQuery();
				if(rs.next()) {
					count = rs.getInt("cnt");
				}
				if(count == 1) {
					System.out.println("입력한 상품 분류 코드" + gu + "는 이미 등록된 코드입니다.");
					System.out.println("새로운 상품 분류 코드를 입력하세요.");
				}						
			}while(count==1);
			//--------------------------------------------------------------
			
			// 사용했던 PreparedStatement객체를 재사용하려면 close()후 재사용하는 것이 좋다.
			if(pstmt != null) try { pstmt.close();}catch(SQLException e) {}
			
			System.out.println("상품 분류명 (LPROD_NM) 입력 >>");
			String nm = scan.next();
			
			String sql3 = "insert into lprod (lprod_id, lprod_gu, lprod_nm)"
					+ " values( ?, ?, ?) ";
			pstmt = conn.prepareStatement(sql3);
			pstmt.setInt(1, maxnum);
			pstmt.setNString(2, gu);
			pstmt.setNString(3, nm);
			
			int cnt = pstmt.executeUpdate();
			
			if(cnt > 0) {
				System.out.println("데이터 추가 성공!!");
			}else {
				System.out.println("데이터 추가 실패!!");
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
//		}catch(ClassNotFoundException e) {
//			e.printStackTrace();
		} finally {
			if(rs != null) try { rs.close(); }catch(SQLException e) {}
			if(pstmt != null) try { pstmt.close(); }catch(SQLException e) {}
			if(conn != null) try { conn.close(); }catch(SQLException e) {}
		}
		
	}
	
	// Lprod테이블의 전체 목록을 보여주는 메서드
	private void displayAll() {
		// 1. DB 작업에 필요한 객체 변수 선언
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			/*
			// 2. 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 3. DB연결 ==> 연결이 성공되면 Connection객체가 생성된다.
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe",
					"SHR98",
					"java");
			*/
			conn = DBUtil.getConnection();
			
			// 4. 처리할 SQL문 작성
			// 		==> SQL문장 중에서 데이터가 들어갈 자리를 물음표(?)로 표시하여 작성한다.
			String sql = "select lprod_id, lprod_gu, lprod_nm nm from lprod";
			
			// 5. Connection객체를 이용하여 PreparedStatement객체 생성
			//		==> 이 때 실행할 SQL문을 인수값으로 넣어준다.
			pstmt = conn.prepareStatement(sql);
			
			// 6. SQL문의 물음표(?)자리에 들어갈 데이터를 셋팅한다.
			//		형식) pstmt.set자료형 이름(물음표 번호, 데이터값);
			
			// 7. 데이터의 셋팅이 완료되면 쿼리문을 실행하고, 실행한 결과를 얻어온다.
			//	==> 실행할 SQL문이 select문일 경우에는 executeQuery()메소드를 사용하고
			//		SQL문이 select문이 아닐 경우에는 executeUpdate()메소드를 사용한다.
			
			// executeQuery()메서드는 SQL문의 실행 결과가 ResultSet객체에 저장되어 반환되고
			// executeUpdate()메서드는 실행에 성공한 레코드 수가 반환된다.
			rs = pstmt.executeQuery();
			
			// 8. 결과 처리하기 ==> select문일 경우
			
			// rs.next() ==> ResultSet객체의 데이터를 가리키는 포인터를 다음번째 레코드 위치로
			//				이동시키고, 그 곳에 데이터가 있으면 true, 없으면 false를 반환한다.
			while(rs.next()) {
				// ResultSet객체의 포인터가 가리키는 곳의 데이터를 가져와서 처리한다.
				// 형식1) rs.get자료형이름("컬럼명"); ==> 컬럼명은 대소문자 구분 없이 사용 가능
				// 형식2) rs.get자료형이름(컬럼번호); ==> 1번부터 시작한다.
				// 형식3) rs.get자료형이름("컬럼의 alias명");
				System.out.println("LPROD_ID : " + rs.getInt("lprod_id"));
				System.out.println("LPROD_GU : " + rs.getNString(2));
				System.out.println("LPROD_NM : " + rs.getNString("nm"));
				System.out.println("------------------------------------------------");
			}
			System.out.println("출력 끝.....");
			System.out.println();
			
		}catch(SQLException e) {
			e.printStackTrace();
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
		}finally {
			// 9. 사용했던 자원을 반납한다. ==> close()메서드 이용
			if(rs!=null) try {rs.close();}catch(SQLException e) {}
			if(pstmt!=null) try {pstmt.close();}catch(SQLException e) {}
			if(conn!=null) try {conn.close();}catch(SQLException e) {}
		}
	}
	
	
	// 메뉴를 출력하고 작업 번호를 입력받아서 반환하는 메서드
	private int displayMenu() {
		System.out.println();
		System.out.println("=======================");
		System.out.println("1. 전체 목록 보기");
		System.out.println("2. 데이터 추가하기");
		System.out.println("0. 프로그램 종료");
		System.out.println("=======================");
		System.out.print("작업 번호>>");
		return scan.nextInt();
	}

	public static void main(String[] args) {
		new JdbcExam().jdbcStart();
	}
}
