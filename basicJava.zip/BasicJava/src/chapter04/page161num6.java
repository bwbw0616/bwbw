package chapter04;

public class page161num6 {
	public static void main(String[] args) {
		String result = "";
		for (int i = 1; i<=4; i++) {
			for(int j = 4; j > i; j--) {
				result += "   ";
			}
			for (int j = 1; j<=i; j++) {
				result  += "*";
			}
			result += "\n";
		}
		System.out.println(result);
			
		
	}

}
