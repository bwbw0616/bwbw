class Animal:
    def __init__(self):
        print("Animal:__init__")
        self.age = 1
    
    def getOld(self):
        self.age += 1
        
    def __del__(self):
        print("Animal:__del__")
        
class Cat(Animal):        
    def __init__(self):
        print("Cat:__init__")
        super().__init__()
        self.ssagaji = False
    def onepunch(self):
        self.ssagaji = True
    def __del__(self):
        print("Cat:__del__")   
    
    
if __name__ == '__main__':
    cat = Cat()
    print(cat.ssagaji)
    print(cat.age)
    cat.getOld()
    cat.onepunch()
    print(cat.ssagaji)
    print(cat.age)