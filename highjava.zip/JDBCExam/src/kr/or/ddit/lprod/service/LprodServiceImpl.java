package kr.or.ddit.lprod.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import kr.or.ddit.lprod.dao.ILprodDao;
import kr.or.ddit.lprod.dao.LprodDaoImpl;
import kr.or.ddit.lprod.vo.LprodVO;
import kr.or.ddit.util.DBUtil;

public class LprodServiceImpl implements ILprodService{
	private ILprodDao dao;		// DAO객체 변수 선언
	private Connection conn;	// Connection객체 변수 선언
	
	private static LprodServiceImpl service;
	
	private LprodServiceImpl() {
		dao = LprodDaoImpl.getInstance();	// DAO객체 생성
	}
	
	public static LprodServiceImpl getInstance() {
		if(service==null) service = new LprodServiceImpl();
		return service;
	}

	@Override
	public int getMaxLprodId() {
		int maxNum = 0;	// 반환값이 저장될 변수 선언
		try{
			conn = DBUtil.getConnection();	// Connection객체 생성
			maxNum = dao.getMaxLprodId(conn);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null)try { conn.close(); } catch(SQLException e) {}
		}
		return maxNum;
	}

	@Override
	public int getLprodBuCount(String gu) {
		int cnt = 0;
		try {
			conn = DBUtil.getConnection();
			cnt = dao.getLprodBuCount(conn, gu);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null)try { conn.close(); } catch(SQLException e) {}
		}
		return 0;
	}

	@Override
	public List<LprodVO> getAllLprod() {
		List<LprodVO> lprodList = null;
		try {
			conn = DBUtil.getConnection();
			lprodList = dao.getAllLprod(conn);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null)try { conn.close(); } catch(SQLException e) {}
		}
		return lprodList;
	}

	@Override
	public int insertLprod(LprodVO lpvo) {
		int cnt = 0;
		try {
			conn = DBUtil.getConnection();
			
			cnt = dao.insertLprod(conn, lpvo);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null)try { conn.close(); } catch(SQLException e) {}
		}
		return cnt;
	}

}
