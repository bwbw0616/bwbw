# 문제 예시
# 첫 수를 입력하시오 ex)1 
# 끝 수를 입력하시오 ex)5
# 배수를 입력하시오 ex)2
# 1에서 5까지 2의 배수의 합은 6입니다.

a = input("첫 수를 입력하시오")
b = input("끝 수를 입력하시오")
c = input("배수를 입력하시오")
aa = int(a)
bb = int(b)
cc = int(c)

sum = 0

for i in range(aa, bb+1):
    if i % cc == 0:
        sum += i

print(f"{aa}에서 {bb}까지 {cc}의 배수의 합은 {sum}입니다")       #파이썬 3.5ver
#print("{}에서 {}까지 {}의 배수의 합은 {}입니다".format(aa,bb,cc,sum))
#print(a + "에서" + b +"까지" +c + "의 배수의 합은" +str(sum)+"입니다")