import pymysql

class DaoMango:
    def __init__(self):
        self.conn = pymysql.connect(host='localhost', user='root', password='python',
                               db='python',port=3305, charset='utf8')
        self.curs = self.conn.cursor(pymysql.cursors.DictCursor)

    
    def myinsert(self,m_name,menu):
        sql = f"""insert into mangoplate (m_name,menu) 
                values ('{m_name}','{menu}')"""
                
        print("sql",sql)
        
        cnt = self.curs.execute(sql)
        self.conn.commit()
        return cnt

    
    def __del__(self):
        self.curs.close()
        self.conn.close()
    
if __name__ == '__main__':
    de = DaoMango()
    cnt = de.myinsert('1','1')
    print(cnt)
    
    
    
    
    