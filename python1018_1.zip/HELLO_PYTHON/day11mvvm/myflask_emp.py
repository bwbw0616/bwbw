from flask import Flask
from flask.globals import request
from flask.templating import render_template
from day11mvvm.dao_emp import DaoEmp
from flask.json import jsonify

app = Flask(__name__,static_url_path='')
de = DaoEmp()

@app.route('/')
@app.route('/emp')
def emp():
    return render_template('emp.html')

@app.route('/emp.ajax',methods=['POST'])
def emp_ajax():
    e_id = request.form['e_id']
    print("e_id",e_id)
    return jsonify({'msg': '저장 완료!'})


@app.route('/emp_list.ajax',methods=['POST'])
def emp_list_ajax():
    de = DaoEmp()
    list = de.myselects()
    return jsonify(list)

@app.route('/emp_one.ajax',methods=['POST'])
def emp_one_ajax():
    e_id = request.form['e_id']
    de = DaoEmp()
    emp = de.myselect(e_id)
    return jsonify(emp)

@app.route('/emp_add.ajax',methods=['POST'])
def emp_add_ajax():
    e_id = request.form['e_id']
    e_name = request.form['e_name']
    sex = request.form['sex']
    addr = request.form['addr']
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.myinsert(e_id, e_name, sex, addr)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})

@app.route('/emp_mod.ajax',methods=['POST'])
def emp_mod_ajax():
    e_id = request.form['e_id']
    e_name = request.form['e_name']
    sex = request.form['sex']
    addr = request.form['addr']
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.myupdate(e_id, e_name, sex, addr)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})

@app.route('/emp_del.ajax',methods=['POST'])
def emp_del_ajax():
    e_id = request.form['e_id']
   
    de = DaoEmp()

    cnt = -1
    try:
        cnt = de.mydelete(e_id)
    except:
        print("dao : error")
    
    return jsonify({'cnt':cnt})

if __name__ == '__main__':
    app.run(debug=True)
    
