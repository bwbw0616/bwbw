package Chapter07;

public class DriverExample {
	public static void main(String[] args) {
		Driver driver = new Driver();
		Vehicle vehicle = new Vehicle();
		
		//Vehicle v = new Bus();
		Vehicle v = new Vehicle();
		
		if (v instanceof Bus) {
			Bus b =(Bus)v;
			System.out.println("버스로 캐스팅되었습니다.");
		}else {
			System.out.println("버스로 캐스팅할 수 없습니다");
		}
		
		//Bus bus = new Bus();
		//Taxi taxi = new Taxi();
		
		//driver.drive(bus);
		//driver.drive(taxi);
		
	}

}
