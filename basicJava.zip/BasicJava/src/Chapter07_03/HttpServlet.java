package Chapter07_03;

public abstract class HttpServlet {
	public abstract void service();

}
