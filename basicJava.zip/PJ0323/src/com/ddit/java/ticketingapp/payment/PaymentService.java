package com.ddit.java.ticketingapp.payment;

import java.util.List;
import java.util.Map;

import com.ddit.java.ticketingapp.util.ScanUtil;
import com.ddit.java.ticketingapp.view.View;

public class PaymentService {
	private static PaymentService instance;
	private PaymentService() {
	}
	public static PaymentService getInstance() {
		if(instance == null) {
			instance = new PaymentService();
		}
		return instance;
	}
	
	PaymentDAO dao = PaymentDAO.getInstance();
	
	public Object showPayMethodList() {
		List<Map<String, Object>> list = dao.selectPayMethod();
		Object payMethod = null;
		
		System.out.println("                    << 결제 수단 선택 >>");
		System.out.println("--------------------------------------------------------------");
		for (int i = 0; i < list.size(); i++) {
			System.out.print((i + 1) + " " + list.get(i).get("결제수단명") + " \t");
			if(i == 3) {
				System.out.println();
			}
			if(i == 5 || i == 6) {
				System.out.print("\t");
			}
		}
		System.out.println();
		System.out.println("--------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("--------------------------------------------------------------");
		
		int num;
		try {
			num = Integer.parseInt(enter);
			
			if(num < 9 && num > 0) {
				payMethod = list.get(num - 1).get("결제수단명");
			}
			else {
				View.getInstance().showReEnterMsg();
				showPayMethodList();
			}
		} 
		catch (NumberFormatException e) {
			View.getInstance().showReEnterMsg();
			showPayMethodList();
		}
		
		return payMethod;
	}
	
	public Object selectMathodId(Object methodName) {
		return PaymentDAO.getInstance().selectPayMethod(methodName).get("PAYMETHOD_ID");
	}
	
}
