package com.ddit.java.temp;

public enum Temp2 {
	HOME("1"),
	QUIT("Q");
	
	Temp2(String str) {
		
	}
}
