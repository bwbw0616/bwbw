class Animal{
    constructor() {
        this.age = 1;
    }
    
    getOld() {
        this.age++;
    }
}

export default Animal;
