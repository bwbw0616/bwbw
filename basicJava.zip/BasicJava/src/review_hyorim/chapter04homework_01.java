package review_hyorim;

import java.util.Scanner;

public class chapter04homework_01 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		//사용자로부터 세 변의 길이를 입력받은 후, 
		//입력받은 변의 길이로 삼각형을 입력 받을 수 있는가?
		//삼각형은 가장 긴 변의 길이가 다른 두 변의 길이의 합보다 작아야 한다.
		
		
		int a;   //첫번째 변의 길이
		int b;  // 두번째 변의 길이
		int c;  // 세번째 변의 길이
		
		System.out.println("삼각형의 첫 번째 변의 길이를 입력하세요 : ");
		a = scanner.nextInt();
		System.out.println("삼각형의 두 번째 변의 길이를 입력하세요 : ");
		b = scanner.nextInt();
		System.out.println("삼각형의 세 번째 변의 길이를 입력하세요 : ");
		c = scanner.nextInt();
		
		if (((a<b+c)&&(a>b)&&(a>c))||((b<a+c)&&(b>a)&&(b>c))||
		((c<b+a)&&(c>b)&&(c>a)))    {
			System.out.println("삼각형을 만들 수 있습니다.");
			
		}else { 
			System.out.println("삼각형을 만들 수 없습니다.");
			scanner.close();
			
		}	
		
	}

}
