package kr.or.ddit.board.dao;

import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.vo.BoardVO;


public interface BoardDAO {
	
	public int insertBoard(SqlMapClient smc, BoardVO mv);
	
	
	public int updateBoard(SqlMapClient smc,BoardVO mv);
	
	
	public int deleteBoard(SqlMapClient smc,String memId);
	
	
	public List<BoardVO> getAllBoardList(SqlMapClient smc);
	
	
	public boolean checkBoard(SqlMapClient smc,String memId);
	
	
	public List<BoardVO> searchBoardList(SqlMapClient smc,BoardVO mv);
	
}