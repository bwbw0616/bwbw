package chapter06;

public class SingletonExample {
	public static void main() {
		Singleton singleton = Singleton.getInstance();
		singleton.plus(10, 20);
				
	}
	private void execute() {
		Singleton singleton = Singleton.getInstance();
		singleton.plus(30, 20);
	}

}
