import pymysql

conn = pymysql.connect(host='localhost', user='root', password='python',
                       db='python', port=3305, charset='utf8')
curs = conn.cursor()


sql = "select * from emp"
curs.execute(sql)

rows = curs.fetchall()
for r in rows:
    print(r[0],r[1],r[2],r[3])
# print(rows)

curs.close()
conn.close()