arr = ["홍길동", "전우치", "이순신"]

idx = 0
for i in arr:
    print(idx,i)
    idx+=1