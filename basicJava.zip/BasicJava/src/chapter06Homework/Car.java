package chapter06Homework;

public class Car {
	
	private double speed;
	private String color;
	private static final double MAX_SPEED=200.0;   //MAX_SPEED는 상수
	public Car() {
		
	}
	
	public Car (String color) {
		this.color = color;		
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color=color;
	}
	public static double getMaxSpeed() {
		return MAX_SPEED;
	}
	//현재 속도 190km/h일 때 speedUp(100)을 호출하면
	//최대 속력을 넘어가므로 기존 속도를 유지
	public boolean speedUp(double speed) {
		if(this.speed+speed>0&&this.speed+speed<MAX_SPEED){
			this.speed+=speed;
			return true;
			
		}
		return false;
	}
	@Override
	public String toString() {
		return "Car[speed=" + speed + ", color="+color +"]";
	}

}
