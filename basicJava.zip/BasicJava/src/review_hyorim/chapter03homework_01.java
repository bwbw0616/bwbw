package review_hyorim;

import java.util.Scanner;

public class chapter03homework_01 {
	public static void main(String[]args) {
		//큰 수를 작은 수로 나눈 몫과 나머지를 출력해보자.
		Scanner scanner = new Scanner(System.in);
		
		int a;
		int b;
				
		System.out.println("첫 번째 숫자를 입력하세요. : ");
		a =scanner.nextInt() ;
		
		System.out.println("두 번째 숫자를 입력하세요 : ");
		b = scanner.nextInt();
		
		int firstNum =( (a+b)+(Math.abs(a-b)))/2;
		int secondNum =( (a+b)-(Math.abs(a-b)))/2;
		
		//((a+b)+(Math.abs(a-b)))/2는 큰 수
		//((a+b)-(Math.abs(a-b)))/2는 작은 수
		//절대값을 반환하는 메소드는 Math.abs(숫자)이다.
		
		System.out.println("큰 수를 작은 수로 나눈 몫은" + firstNum/secondNum
				                            + "이고,");
		System.out.println("나머지는 " +firstNum% secondNum + "이다.");
		scanner.close();

	}

}
