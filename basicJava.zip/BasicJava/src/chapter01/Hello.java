package chapter01;

public class Hello {
 // Entry Point(진입점)
      public static void main(String [] args) {
    	  System.out.println("Hello, Java");
      }
}
