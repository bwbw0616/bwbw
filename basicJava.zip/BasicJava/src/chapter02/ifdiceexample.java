package chapter02;

import java.util.Random;

public class ifdiceexample {
	public static void main(String[] args) {
		Random random = new Random();
		
		System.out.println("주사위의 숫자");
		
		int num = random.nextInt(6) + 1;
		
		if(num==1&&num==3&&num==5) {
			System.out.println(num+"홀수가 나왔습니다.");
			
		}else if(num==2&&num==4&&num==6) {
			System.out.println(num+"짝수가 나왔습니다.");
		}
	}

}
