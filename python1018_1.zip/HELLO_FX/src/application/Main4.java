package application;
	
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class Main4 extends Application {
	
	TextField tf;
	TextArea ta ;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("main4.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			tf = (TextField) scene.lookup("#tf");
			ta = (TextArea) scene.lookup("#ta");
			Button btn = (Button) scene.lookup("#btn");
			
			btn.setOnMouseClicked(new EventHandler<Event>() {
				@Override
				public void handle(Event event) {
					myclick();
					
				}
			});
			
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void myclick() {
		String dan = tf.getText();
		int idan = Integer.parseInt(dan);
		
		String txt = "";
		
		txt+=idan+"*"+1+"="+(idan*1)+"\n";
		txt+=idan+"*"+2+"="+(idan*2)+"\n";
		txt+=idan+"*"+3+"="+(idan*3)+"\n";
		txt+=idan+"*"+4+"="+(idan*4)+"\n";
		txt+=idan+"*"+5+"="+(idan*5)+"\n";
		txt+=idan+"*"+6+"="+(idan*6)+"\n";
		txt+=idan+"*"+7+"="+(idan*7)+"\n";
		txt+=idan+"*"+8+"="+(idan*8)+"\n";
		txt+=idan+"*"+9+"="+(idan*9)+"\n";
		ta.setText(txt);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}











