package Chapter11;

public class StringExample {
	public static void main(String[] args) {
		//A라는 컴퓨터에서 전달된 데이터
		//전달받은 암호화 데이터를 복호화
		byte[] bytes = new byte[100];
		
		String message = new String(bytes);
		System.out.println(message);
	}
}
