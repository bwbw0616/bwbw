package chapter06;

public class Person {
	static final String nation = "Korea";     //final static String nation = "Korea"; (순서 상관 없음)
	final String ssn;
	String name;
	public Person(String ssn, String name) {
		this.ssn = ssn;
		this.name = name;		
	}
}