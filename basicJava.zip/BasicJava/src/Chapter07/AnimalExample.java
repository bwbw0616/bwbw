package Chapter07;

public class AnimalExample {
	public static void main(String[] args) {
		Dog dog = new Dog();
		System.out.println(dog.sound());
		
	}

}
