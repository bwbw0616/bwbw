package chapter04;

public class page160num2 {
	public static void main(String[] args) {
		int i;
		int sum= 0;
		for(i = 1; i<=100; i++) {
		if	(i % 3==0) {
			sum +=i;
		}
		}
			System.out.println("1~"+(i-1) +"까지의 정수 중에서  3의 배수의 총합: " + sum);
		}
}	