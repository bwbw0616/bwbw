a = 56

if a > 60:
    print("좋음")
elif a > 55:
    print("나쁨")
else:
    print("바부")