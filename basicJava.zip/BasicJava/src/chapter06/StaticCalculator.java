package chapter06;

public class StaticCalculator {
	static double pi = 3.14;
	boolean isPowerOn;
	
	double area(int radius) {
		return pi * radius * radius;
	}
	
	static int plus(int x, int y) {
		StaticCalculator calculator = new StaticCalculator();
		if (calculator.isPowerOn) {
			return x +y;
		}
		return 0;
	}
	static int minus(int x, int y) {
		return x-y;
	}

}
