package Chapter07;

public class PhoneExample {
	public static void main(String[] args) {
//		new Phone("") {
		Phone phone =  new SmartPhone("");
		
		phone.turnOn();
		phone.internetSearch();
		phone.turnOff();
	
	}

}
