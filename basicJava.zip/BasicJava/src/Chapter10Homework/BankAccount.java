package Chapter10Homework;

public abstract class BankAccount {
	protected int balance;

	public int getBalance() {
		return balance;

	}

	public abstract String getAccountType();

	public void deposit(int amount) {
		this.balance += amount;

	}

	public boolean withdraw(int amount) {
		if (this.balance < amount) {

			return false;

		}
		this.balance -= amount;
		return true;
	}

	public boolean transfer(int amount, BankAccount otherAccount) {
		if (amount < 0 || amount > balance) {
			throw new IllegalArgumentException("해당 금액을 보낼 수 없습니다.");
		}
		if (otherAccount == null) {
			throw new NullPointerException("해당하는 계좌가 없습니다.");

		}
		if (withdraw(amount)) {
			otherAccount.deposit(amount);
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return String.format("%,d", this.balance);
	}

}