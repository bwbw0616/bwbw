package chapter04;

import java.util.Scanner;

public class ExampleProblem02 {
	public static void main(String[] args) {
		//입력 받은 월의 계절이 어떤 계절인가?
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("월을 입력하세요");
		int num = scanner.nextInt();
		if((num==3)||(num==4)||(num==5)) {
	     	System.out.println(num+"월은 봄입니다. ");
		}else if ((num==6)||(num==7)||(num==8)){
		    System.out.println(num+"월은 여름입니다. ");
		}else if ((num==9)||(num==10)||(num==11)){
		    System.out.println(num+"월은 가을입니다. ");
		}else if((num==12)||(num==1)||(num==2)){
		    System.out.println(num+"월은 겨울입니다. ");
		}else {
		    System.out.println("잘못된 입력입니다. ");
		
		}
	}
}
