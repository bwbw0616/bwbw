package Chapter08Homework;

import java.text.NumberFormat;

public abstract class BankAccount {

	protected int balance;

	public abstract String getAccountType();

	public BankAccount(int balance) {
		this.balance = balance;

	}

	public int getBalance() {
		return balance;

	}

	public void deposit(int balance) {
		this.balance += balance;

	}

	public boolean withdraw(int amount) {
		if (balance - amount > 0) {
			this.balance -= amount;
			return true;

		} else {
			return false;

		}
	}

	public boolean transfer(int balance, BankAccount account) {
		if (withdraw(balance)) {
			account.deposit(balance);
			return true;
		}
		return false;

	}

	public String toString() {
		NumberFormat numberFormat = NumberFormat.getInstance();
		return String.format(numberFormat.format(balance));
	}

}