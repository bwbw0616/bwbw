package com.ddit.java.temp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JdbcTemplate {
	private static JdbcTemplate template = new JdbcTemplate();
	private Connection connection;
	private PreparedStatement pStatement = null;
	private ResultSet resultSet = null;

	private JdbcTemplate() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@192.168.36.41:1521:xe";
			String userId = "ticketingapp";
			String password = "java";
			connection = DriverManager.getConnection(url, userId, password);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static JdbcTemplate getTemplate() {
		return template;
	}

	public Connection getConnection() {
		return connection;
	}

	public void quitSql() {
		if(resultSet != null) {
			try {
				resultSet.close();
			}
			catch (Exception e) {
			}
		}
		if(pStatement != null) {
			try {
				pStatement.close();
			}
			catch (Exception e) {
			}
		}
	}

	public void closeConnection() {
		if(connection != null) {
			try {
				connection.close();
			}
			catch (Exception e) {
			}
		}
	}

	
	public Map<String, Object> selectOne(String sql) {
		Map<String, Object> map = null;

		try {
			pStatement = connection.prepareStatement(sql);
			resultSet = pStatement.executeQuery();

			// resultSet에 대한 데이터 정보를 metaData에 저장함
			ResultSetMetaData metaData = resultSet.getMetaData();
			// medata를 통해 resultSet의 총 컬럼 수를 가져옴
			int columnCount = metaData.getColumnCount();

			while (resultSet.next()) {
				map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					// 예) member 테이블의 mem_id: a001 일 때,
					// metaData.getColumnName은 mem_id, resulSet.getObject는 a001을 map에 저장함
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return map;
	}

	public Map<String, Object> selectOne(String sql, String str) {
		Map<String, Object> map = null;

		try {
			pStatement = connection.prepareStatement(sql);
			pStatement.setObject(1, str);
			
			resultSet = pStatement.executeQuery();

			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();

			while (resultSet.next()) {
				map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return map;
	}
	
	public Map<String, Object> selectOne(String sql, List<Object> param) {
		Map<String, Object> map = null;

		try {
			pStatement = connection.prepareStatement(sql);
			for (int i = 0; i < param.size(); i++) {
				// List에 저장된 값을 prepared된 sql에 저장함
				pStatement.setObject(i + 1, param.get(i));
			}
			
			resultSet = pStatement.executeQuery();
			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();
			
			// sql을 출력한 값을 map에 저장함
			while (resultSet.next()) {
				map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return map;
	}

	public List<Map<String, Object>> selectList(String sql) {
		List<Map<String, Object>> list = new ArrayList<>();

		try {
			pStatement = connection.prepareStatement(sql);
			resultSet = pStatement.executeQuery();

			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();

			while (resultSet.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
				list.add(map);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return list;
	}
	
	// 조건이 한 개일 때
	public List<Map<String, Object>> selectList(String sql, String param) {
		List<Map<String, Object>> list = new ArrayList<>();

		try {
			pStatement = connection.prepareStatement(sql);
			pStatement.setObject(1, param);
			resultSet = pStatement.executeQuery();
			
			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();

			while (resultSet.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
				list.add(map);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return list;
	}
	
	// 조건이 여러개일 때
	public List<Map<String, Object>> selectList(String sql, List<Object> param) {
		List<Map<String, Object>> list = new ArrayList<>();
		
		try {
			pStatement = connection.prepareStatement(sql);
			for (int i = 0; i < list.size(); i++) {
				// List에 저장된 값을 prepared된 sql에 저장함
				pStatement.setObject(i + 1, list.get(i));
			}
			resultSet = pStatement.executeQuery();
			ResultSetMetaData metaData = resultSet.getMetaData();
			int columnCount = metaData.getColumnCount();
			
			// sql을 출력한 값을 map에 저장함
			while (resultSet.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					map.put(metaData.getColumnName(i), resultSet.getObject(i));
				}
				list.add(map);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return list;
	}
	
	public int update(String sql) {
		int result = 0;

		try {
			pStatement = connection.prepareStatement(sql);
			result = pStatement.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return result;
	}

	// List에 컬럼값을 저장해서 업데이트함
	public int update(String sql, List<Object> param) {
		int result = 0;

		try {
			pStatement = connection.prepareStatement(sql);

			for (int i = 0; i < param.size(); i++) {
				pStatement.setObject(i + 1, param.get(i));
			}

			result = pStatement.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			quitSql();
		}

		return result;
	}
}
