package kr.or.ddit.basic;

import java.io.FileInputStream;
import java.io.IOException;

/*
 * 파일 읽기 예제
 * @author sem
 * 
 */
public class T05_FileStreamTest {
	public static void main(String[] args) {
		
		FileInputStream fis = null;
		
		try {
			fis = new FileInputStream("d:/D_Other/test.txt");
			
			int data = 0;
			
			// 읽어온 값이 -1이면 파일의 끝까지 다 읽었다는 의미이다.
			while((data = fis.read()) != -1) {
				//읽어온 자료 출력하기
				System.out.print((char) data);
			}			
		}catch(IOException ex) {
			ex.printStackTrace();
		}finally {
			try {
				fis.close();
			}catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
