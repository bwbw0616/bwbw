package day02;

public class Putin extends Lee{
	int army_power = 100;
	
	public void goToUkraine() {
		army_power--;
	}
}
