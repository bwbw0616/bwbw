package chapter04;

import java.util.Random;
import java.util.Scanner;

public class WhileBreakExample {
	public static void main(String[] args) {
		Random random = new Random();
		while (true) {
		    int num = random.nextInt(6) + 1;
		
	//	Scanner scanner = new Scanner(System.in);
	//	while(true) {
	//		String string = scanner.next();
	//		System.out.println(string);
	//		if (string.equals("종료")) {
	//			break;
			}
		}
		
	}
