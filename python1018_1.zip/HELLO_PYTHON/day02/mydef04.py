def addminmuldiv(a,b):
    return a+b, a-b, a*b, a/b


sum = addminmuldiv(5, 6)

print(sum)