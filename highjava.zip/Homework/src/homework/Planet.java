package homework;

public enum Planet {
	
	//행성의 반지름 (단위 : km)
	//데이터값을 임의로 지정한 열거형 객체 선언
	
	수성(2439), 
	금성(6052), 
	지구(6371), 
	화성(3390), 
	목성(69911), 
	토성(58232), 
	천왕성(25362), 
	해왕성(24622);

	//괄호 속의 값이 저장될 변수 선언
	private double r;
	
	//생성자 만들기
	private Planet(double r) {
		this.r = r;
	}

	//값을 반환하는 메서드 작성
	public double getR() {
		return r;
	}

	public static void main(String[] args) {
		//데이터를 배열로 가져온다.
		Planet planet[] = Planet.values();
		for (int i = 0; i < planet.length; i++) {
			System.out.println(planet[i].name() + "의 면적 : " + 4 * Math.PI * planet[i].getR() * planet[i].getR() + "㎢");
			System.out.println();
		}
	}
}