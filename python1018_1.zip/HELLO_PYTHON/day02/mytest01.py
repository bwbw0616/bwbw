sum = 0

for i in range(1, 10+1):
    sum += i

print("sum",sum)
