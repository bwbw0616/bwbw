package review_hyorim;

import java.util.Scanner;

public class chapter02homework_04 {
	public static void main(String[] args) {
		
		//500원, 100원, 50원, 10원짜리 동전의 갯수를 입력 받아
		//저금통 안에 총 얼마가 들어 있는지 알아보자.
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("500원짜리 동전의 개수:");
		float coin500 = scanner.nextFloat();
		
		System.out.println("100원짜리 동전의 개수:");
		float coin100 = scanner.nextFloat();
		
		System.out.println("50원짜리 동전의 개수:");
		float coin50 = scanner.nextFloat();
		
		System.out.println("10원짜리 동전의 개수:");
		float coin10 = scanner.nextFloat();
		
		float total = (coin500*500)+ (coin100*100)
				         + (coin50*50)+ (coin10*10);
		
		System.out.println("저금통 안의 동전의 총 액수 : " + total);
		scanner.close();
	}

}
