package Chapter08;

import java.util.Arrays;

public class ComparableExample {
	public static void main(String[] args) {
		int[] numbers = {50,24,82,91,13,48,72,9,5,1,33};
		sort(numbers, numbers.length);
		System.out.println(Arrays.toString(numbers));
	}
	static void sort(int a[], int len) {
		for (int i = len - 1; i>0; i--)
			for (int j = 0; j<i; j++)
				if (a[j]>a[j + 1]) {
					int t = a[j];
					a[j] = a[j + 1];
					a[j+1] = t;
				}
	}

}
