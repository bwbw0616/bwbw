package chapter02;

public class chapter {
	public static void main(String[] args) {
		int x = 3;
		int y = 5;
		System.out.println("x :" + x + ", y : " + y);

		{
			int c = 100;
			System.out.println(x);
		}
		int temp = x;
		x = y;
		y = temp;
		System.out.println("x:" + x + ", y:" + y);
	}
}