package kr.or.ddit;

import java.sql.Date;

public class MemoVO {
	private long no;
	private String title;
	private String contents;
	private Date createDate;
	private Date modifyDate;

	public MemoVO() {

	}

	public MemoVO(String title, String contents) {
		this.title = title;
		this.contents = contents;
	}

	public MemoVO(long no, String title, String contents, Date createDate, Date modifyDate) {
		this.no = no;
		this.title = title;
		this.contents = contents;
		this.createDate = createDate;
		this.modifyDate = modifyDate;
	}

	public long getNo() {
		return no;
	}

	public void setNo(long no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	@Override

	public String toString() {
		return "MemoVO [no=" + no + ", title=" + title + ", contents=" + contents + ", createDate=" + createDate
				+ ", modifyDate=" + modifyDate + "]";

	}
}
