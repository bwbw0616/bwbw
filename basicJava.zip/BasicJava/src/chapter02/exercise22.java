package chapter02;

public class exercise22 {
	public static void main(String[] args) {
		//거리: 40 * 10^12km 40,000,000,000,000km
		double distance = 40e12;
		double speed = 300000;// 단위 1초 30만킬로미터 이동
		double time = distance/speed;
		//133333333.33333333		
		double result = time / (60*60*24*365);
				System.out.println(result+"광년");
		
	}

}
