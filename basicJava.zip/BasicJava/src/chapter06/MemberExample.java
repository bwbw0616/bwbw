package chapter06;

public class MemberExample {
	public static void main(String[] args) {
		new Member("홍길동", "hong");

	} 

}
