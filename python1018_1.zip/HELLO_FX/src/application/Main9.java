package application;
	
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;


public class Main9 extends Application {
	TextField tfCom;
	TextField tfMine;
	TextField tfResult;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("main9.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			tfCom = (TextField) scene.lookup("#tfCom");
			tfMine = (TextField) scene.lookup("#tfMine");
			tfResult = (TextField) scene.lookup("#tfResult");
			Button btn = (Button) scene.lookup("#btn");
			
			
			tfMine.setOnKeyPressed(new EventHandler<KeyEvent>() {
				@Override
				public void handle(KeyEvent event) {
					if(event.getCode()== KeyCode.ENTER) {
						myclick();
					}
				}
			});
			
			btn.setOnMouseClicked(new EventHandler<Event>() {
				@Override
				public void handle(Event event) {
					myclick();
				}
			});
						
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void myclick() {
		String com = "";
		String mine = tfMine.getText();
		String result = "";
		
		double rnd = Math.random();
		if(rnd > 0.66) {
			com = "가위";
			
		}else if(rnd > 0.33){
			com = "바위";
		}
		else {
			com = "보";
		}
		if(com.equals(mine)) {
			result  = "비김";
			
		}else if(com.equals("가위")&&mine.equals("바위")){
			result  = "이김";
		}else if(com.equals("바위")&&mine.equals("보")){
			result  = "이김";
		}else if(com.equals("보")&&mine.equals("가위")){
			result  = "이김";
		}else {
			result = "짐";
		}
		
		tfCom.setText(com);
		tfResult.setText(result);
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
