package com.ddit.java.temp;


public enum Menu {
	QUIT(0, "프로그램을 종료하겠습니다. 안녕히가세요!\n"),
	HOME(1, "3. 로그인\n5. 회원가입\n0. 시스템 종료"),
	MAIN(2, "6. 공연확인\n8. 마이페이지\n4. 로그아웃\n0. 시스템종료\n메뉴를 선택해주세요: "),
	LOGIN(3,"아이디와 비밀번호를 입력해주세요\n"),
	LOGOUT(4, "로그아웃 되었습니다.\n"),
	JOIN(5, "회원가입을 진행합니다.\n"),
	CATEGORY(6, "뮤지컬\n연극\n콘서트\n클래식/무용\n아동/가족\n카테고리를 입력해주세요.\n"),
	CONCERTLIST(61,"해당 카테고리의 공연 리스트입니다.\n보고싶은 공연을 입력해주세요: "),
	CONCERT(62, "선택하신 공연의 정보입니다.\n"),
	PLACE(63, "선택하신 공연의 장소 정보입니다.\n"),
	CAST(64, "선택하신 공연의 출연진 정보입니다.\n"),
	SEAT(7, "예매하실 좌석을 선택해주세요\n"),
	TICKET(71, "티켓 정보를 확인합니다.\n"),
	TICKETING(72, "결제를 진행합니다\n"),
	MYPAGE(8, "마이페이지입니다.\n9. 예약정보확인\n10. 내정보확인\n11. 회원정보수정\n4. 로그아웃\n0. 시스템종료\n메뉴를 선택해주세요: "),
	TICKETCHECK(9, "예약내역을 확인합니다.\n"),
	MYINFO(10, "내 정보를 확인합니다.\n"),
	MODIFY(11, "회원정보를 수정합니다.\n이름\n비밀번호\n주소\n전화번호\n수정할 항목을 선택해주세요"),
	MODIFY_NAME(111, "이름을 수정합니다.\n새로운 이름을 입력해주세요: "),
	MODIFY_PASSWORD(112, "비밀번호를 수정합니다.\n새로운 비밀번호를 입력해주세요: "),
	MODIFY_ADD(113, "주소를 수정합니다.\n새로운 주소를 입력해주세요: "),
	MODIFY_HP(114, "전화번호를 수정합니다.\n새로운 전화번호를 입력해주세요: ");
	
	private final int menu;
	private final String menuString;
	
	Menu(int menu, String menuString) {
		this.menu = menu;
		this.menuString = menuString;
	}
	
	public int getMenu() {
        return menu;
    }

    public String getMenuString() {
        return menuString;
    }

//    public static Menu findMenu(int number) {
//        for (Menu menu: values()) {
//            if (menu.getMenu() == number) {
//                return menu;
//            }
//        }
//    }
}



