package com.ddit.java.temp.service;

public class JoinService {
	private JoinService instance;
	
	private JoinService() {	
	}
	
	public JoinService getInstance() {
		if(instance == null) {
			instance = new JoinService();
		}
		return instance;
	}
	
}
