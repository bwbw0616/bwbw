package Chapter07HomeworkBank2;

public class CheckingAccount extends BankAccount {
	private SavingsAccount protectedBy;
	
	public CheckingAccount(int balance) {
		super(balance);
	}

	public CheckingAccount(int balance, SavingsAccount protectedBy) {
		super(balance);
		this.protectedBy = protectedBy;
	}
	
	@Override
	public boolean withdraw(int amount) {
		if (balance < amount) {// 잔액이 부족할 때
			this.protectedBy.withdraw(amount - balance);
			balance = 0;
		} else {
			balance -= amount;
		}
		return true;
	}
}
