package com.ddit.java.ticketingapp.ticket;

import java.util.Map;

import com.ddit.java.ticketingapp.member.MemberVO;
import com.ddit.java.ticketingapp.payment.PaymentDAO;
import com.ddit.java.ticketingapp.payment.PaymentService;
import com.ddit.java.ticketingapp.util.FormatUtil;
import com.ddit.java.ticketingapp.util.ScanUtil;
import com.ddit.java.ticketingapp.view.View;

public class TicketService {
	private static TicketService instance;

	private TicketService() {
	}

	public static TicketService getInstance() {
		if(instance == null) {
			instance = new TicketService();
		}
		return instance;
	}

	TicketDAO dao = TicketDAO.getInstance();

	private void showTicketServiceMenu(Map<String, Object> map) {
		System.out.println("          << TICKET SERVICE >> ");
		System.out.println("--------------------------------------------------------------");
		System.out.print("공연명: " + map.get("공연명") + "\t ");
		System.out.println("날짜: " + FormatUtil.format(map.get("날짜")));
		System.out.print("주연: " + map.get("주연") + "\t\t ");
		System.out.println("장소명: " + map.get("장소명"));
		System.out.println("좌석번호: " + map.get("좌석번호"));
		System.out.println("가격: " + map.get("가격"));
		System.out.println("--------------------------------------------------------------");
	}

	private String showTicketServiceMenu(Map<String, Object> map, Object method) {
		System.out.println("          << TICKET SERVICE >> ");
		System.out.println("--------------------------------------------------------------");
		System.out.print("공연명: " + map.get("공연명") + "\t ");
		System.out.println("날짜: " + FormatUtil.format(map.get("날짜")));
		System.out.print("주연: " + map.get("주연") + "\t\t ");
		System.out.println("장소명: " + map.get("장소명"));
		System.out.println("좌석번호: " + map.get("좌석번호"));
		System.out.println("결제수단: " + method);
		System.out.println("총 가격: " + map.get("가격") + " (수수료 1000원 포함)");
		System.out.println("--------------------------------------------------------------");
		String price = String.valueOf(map.get("가격"));
		return price;
	}

	public void showPriceInput(String price, Object conId, Object seatNo, Object methodId) {
		System.out.println("※ 가격을 정확히 입력해 주세요");
		System.out.print("입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("--------------------------------------------------------------");
		if(enter.equals(price)) {
			MemberVO mv = MemberVO.getInstance();

			Object ticketId = dao.updateTicket(conId, seatNo).get("TICKET_ID");
			Object ticketingId = dao.updateTicketing(conId, seatNo, Integer.parseInt(price), ticketId, mv.getId()).get("TICKETING_ID");
			PaymentDAO pd = PaymentDAO.getInstance();
			int result = pd.updatePayment(methodId, price, ticketingId);
			if(result > 0) {
				System.out.println("예매가 완료되었습니다.");

				View.getInstance().showMainMenu();
			}
			else {
				System.out.println("예매에 실패하였습니다.");
				View.getInstance().showCategoryMenu();
			}
		}
		else {
			View.getInstance().showReEnterMsg();
			showPriceInput(price, conId, seatNo, methodId);
		}
	}

	public void showTicketService(Object conId, Object seatNo) {
		Map<String, Object> map = dao.selectTicket(conId, seatNo);

		showTicketServiceMenu(map);
		System.out.print("예매하시겠습니까?(Y/N) >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("--------------------------------------------------------------");
		switch (enter) {
		case "Y":
			PaymentService ps = PaymentService.getInstance();
			Object methodName = ps.showPayMethodList();
			map = dao.selectTicketCommission(conId, seatNo);
			String price = showTicketServiceMenu(map, methodName);
			Object methodId = ps.selectMathodId(methodName);
			showPriceInput(price, conId, seatNo, methodId);
			break;
		case "N":
			View.getInstance().showCategoryMenu();
			break;
		default:
			View.getInstance().showReEnterMsg();
			showTicketService(conId, seatNo);
		}
	}
}
