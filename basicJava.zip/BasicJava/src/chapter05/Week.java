package chapter05;

//  class와 같다.
public enum Week  {
	
	MONDAY(1, "월요일"),
	TUSEDAY(2, "화요일"),
	WEDNESDAY(3, "수요일"),
	THURSDAY(4, "목요일"),
	FRIDAY(5, "금요일"),
	SATURDAY(6, "토요일"),
	SUNDAY(7, "일요일");
	int number;
	String korName;
	Week(int number, String korName) {
		this.number = number;
		this.korName = korName;
		
	}
	public String getkorName() {
		return korName;
		
	}

}
