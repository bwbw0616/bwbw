package chapter06;

import java.util.Timer;

public class CalculatorExample {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		//인수 : 메소드 호출 시 전달하는 값
		int result = calculator.plus(10, 100, 1000, 10000);
		//매개 변수(parameter)와 인수(argument, 인자)
		calculator.divide(10, 20);
		System.out.println(result);
	}

}
