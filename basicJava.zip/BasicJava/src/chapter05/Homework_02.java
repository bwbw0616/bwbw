package chapter05;

import java.util.Random;
import java.util.Scanner;

public class Homework_02 {
	public static void main(String[] args) {
		// 로또번호를 생성하는 프로그램을 작성하시오.
		// (로또 번호는 1 ~ 45번까지 있으며
		// 이 중에서 중복되지 않는 6개의 숫자를
		// 추출하여 결과를 출력한다.)
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();

		int[] lotto = new int[6];

		lotto[0] = (int) (Math.random() * 45) + 1;

		for (int i = 1; i < 6; i++) {
			lotto[i] = (int) (Math.random() * 45) + 1;

			for (int j = 0; j < i; j++) {
				if (lotto[i] == lotto[j])
					lotto[i] = (int) (Math.random() * 45) + 1;
				else
					break;
			}
		}

		for (int j = 0; j < 6; j++) {
			System.out.println(lotto[j]);
		}
	}
}