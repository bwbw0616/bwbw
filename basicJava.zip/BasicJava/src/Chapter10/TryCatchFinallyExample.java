package Chapter10;

import java.util.Scanner;

public class TryCatchFinallyExample {
	public static void main(String[] args) {
		//Compile Time Exception
		try {
			Class.forName("");
		}catch(ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		//Run time Exception
		Scanner scanner = new Scanner(System.in);
		int value1;
		int value2;
		while (true) {
			System.out.print("첫번째 데이터 입력 : ");
			String data1 = scanner.next();
			System.out.print("두번째 데이터 입력 : ");
			String data2 = scanner.next();
			value1 = 0;
			value2 = 0;
			try {
				value1 = Integer.parseInt(data1);
				value2 = Integer.parseInt(data2);
				break;
			} catch (NumberFormatException e) {
				// e.printStackTrace();
				System.out.println("숫자 형식으로 입력하세요.");
			}
		}
		int result = value1 + value2;
		System.out.println(value1 + " + " + value2 + " = " + result);

		scanner.close();

	}

}