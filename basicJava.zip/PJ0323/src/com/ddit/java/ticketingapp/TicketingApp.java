package com.ddit.java.ticketingapp;

import com.ddit.java.ticketingapp.view.View;

public class TicketingApp {
	public static void main(String[] args) {
		View view = View.getInstance();
		
		view.showHomeMenu();
	}	
}
