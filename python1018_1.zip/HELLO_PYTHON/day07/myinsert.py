import pymysql

conn = pymysql.connect(host='localhost', user='root', password='python',
                       db='python', port=3305, charset='utf8')

e_id = '5'
e_name = '5'
sex = '5'
addr = '5'

cursor = conn.cursor()

sql = f"""INSERT INTO emp(e_id, e_name, sex, addr)
       VALUES ('{e_id}', '{e_name}', '{sex}', '{addr}')"""

print("sql",sql)
cnt = cursor.execute(sql)
print("cnt",cnt)

conn.commit()
cursor.close()
conn.close()