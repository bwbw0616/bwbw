package chapter02;

import java.util.Scanner;

public class exercise_23 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		//첫 번째 숫자 > 두 번째 숫자 : true
		//첫 번째 숫자 < 두 번째 숫자 : false
		
		
		System.out.println("첫 번째 수를 입력하세요");
		int first = scanner.nextInt();
		System.out.println("두 번째 수를 입력하세요");
        int second = scanner.nextInt();
        
        if(first>second) {
        	
		
		System.out.println("첫 번째 수가 두 번째 수보다 큰가? true");
        }
        
	   if(first<second) {
		System.out.println("첫 번째 수가 두 번째 수보다 큰가? false");
		scanner.close();
        }

}
	}
