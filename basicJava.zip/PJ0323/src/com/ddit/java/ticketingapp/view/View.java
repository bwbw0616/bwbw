package com.ddit.java.ticketingapp.view;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.ddit.java.ticketingapp.category.CategoryDAO;
import com.ddit.java.ticketingapp.concert.ConcertDAO;
import com.ddit.java.ticketingapp.home.HomeService;
import com.ddit.java.ticketingapp.member.MemberVO;
import com.ddit.java.ticketingapp.mypage.MyPageService;
import com.ddit.java.ticketingapp.seat.SeatDAO;
import com.ddit.java.ticketingapp.seat.SeatService;
import com.ddit.java.ticketingapp.ticket.TicketService;
import com.ddit.java.ticketingapp.util.FormatUtil;
import com.ddit.java.ticketingapp.util.JdbcTemplate;
import com.ddit.java.ticketingapp.util.ScanUtil;

public class View {
	private static View instance;

	private View() {
	}

	public static View getInstance() {
		if(instance == null) {
			instance = new View();
		}
		return instance;
	}

	HomeService homeService = HomeService.getInstance();
	MyPageService myPageService = MyPageService.getInstance();
	MemberVO memberVO = MemberVO.getInstance();
	TicketService ticketService = TicketService.getInstance();

	public void showReEnterMsg() {
		System.out.println("\n\t\t\t    ※ 다시 입력해 주십시오.\n");
	}

	// 홈
	public void showHomeMenu() {
		System.out.println("\t\t\t\t<< 홈 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t\t1. 로그인");
		System.out.println("\t\t\t\t2. 회원가입");
		System.out.println("\t\t\t\tQ. 종료");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		switch (enter) {
		case "1":
			homeService.login();
			break;
		case "2":
			homeService.join();
			break;
		case "Q":
		case "q":
			System.out.println("\t\t\t          프로그램을 종료합니다.");
			System.out.println("------------------------------------------------------------------------");
			return;
		default:
			showReEnterMsg();
			showHomeMenu();
			break;
		}
	}

	// 메인
	public void showMainMenu() {
		System.out.println("\t\t\t\t<< 메인 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t       1. 예매하기");
		System.out.println("\t\t\t       2. 마이페이지");
		System.out.println("\t\t\t       Q. 종료");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		switch (enter) {
		case "1":
			showCategoryMenu();
			break;
		case "2":
			showMyPageMenu();
			break;
		case "Q":
		case "q":
			System.out.println("\t\t\t          프로그램을 종료합니다.");
			System.out.println("------------------------------------------------------------------------");
			return;
		default:
			showReEnterMsg();
			showMainMenu();
			break;
		}

	}

	public void showCategoryMenu() {
		List<Map<String, Object>> list = CategoryDAO.getInstance().selectCategory();

		System.out.println("\t\t\t   << 예매: 카테고리 선택 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t       선택번호       카테고리명");
		System.out.println("------------------------------------------------------------------------");
		for (int i = 0; i < list.size(); i++) {
			for (Entry<String, Object> entry : list.get(i).entrySet()) {
				System.out.println("\t\t\t      " + (i + 1) + "\t          " + entry.getValue());
			}
		}
		System.out.println("\t\t\t      Q\t          돌아가기");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");

		switch (enter) {
		case "1":
			showConcertInfo("뮤지컬");
			break;
		case "2":
			showConcertInfo("연극");
			break;
		case "3":
			showConcertInfo("콘서트");
			break;
		case "4":
			showConcertInfo("클래식/무용");
			break;
		case "5":
			showConcertInfo("아동/가족");
			break;
		case "Q":
		case "q":
			showMainMenu();
			break;
		default:
			showReEnterMsg();
			showCategoryMenu();
			break;
		}
	}

	// 단어 정렬 필요
	public void showConcertInfo(Object category) {
		List<Map<String, Object>> list = ConcertDAO.getInstance().selectConcertWithCategory(category);

		System.out.println("\t\t\t    << 예매: 콘서트 정보 >>");
		System.out.println("------------------------------------------------------------------------");
		for (int i = 0; i < list.size(); i++) {
	         System.out.print("  " + (i + 1) + "\t ");
	         System.out.print("공연명: " + list.get(i).get("CON_NAME") + " ");
	         
	         System.out.print("관람등급: " + list.get(i).get("CON_RATING")+ " ");
	         System.out.print("장소:" +list.get(i).get("PLACE_NAME")+ " ");
	         System.out.print("기간: "+FormatUtil.format(list.get(i).get("CON_DATE"))+ " ");
	         System.out.println();
	      }
		System.out.println("------------------------------------------------------------------------");
		System.out.println("  1.돌아가기          2.예매하기          3.상세정보 보기          4.메인으로");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();

		switch (enter) {
		case "1":
			showCategoryMenu();
			break;
		case "2":
			System.out.print("\t\t\t  ※ 예매할 콘서트 번호 입력 >> ");
			try {
				enter = ScanUtil.nextLine();
				System.out.println("------------------------------------------------------------------------");

				Object conId = list.get(Integer.parseInt(enter) - 1).get("CON_ID");
				showConcertSeat(conId);
			}
			catch (NumberFormatException e) {
				showReEnterMsg();
				showConcertInfo(category);
			}
			break;
		case "3":

			System.out.print("\t\t         ※ 상세정보를 확인할 콘서트 번호 입력 >> ");
			try {
				enter = ScanUtil.nextLine();
				System.out.println("------------------------------------------------------------------------");

				Object conId = list.get(Integer.parseInt(enter) - 1).get("CON_ID");
				showConcertMoreInfo(conId, category);
			}
			catch (NumberFormatException e) {
				showReEnterMsg();
				showConcertInfo(category);
			}
			break;
		case "4":
			showMainMenu();
			break;
		default:
			showReEnterMsg();
			showConcertInfo(category);
			break;
		}
	}

	public void showConcertMoreInfo(Object conId, Object category) {
		ConcertDAO dao = ConcertDAO.getInstance();

		Map<String, Object> map = dao.selectConcertMoreInfo(conId);
		System.out.println("\t\t\t  << 예매: 공연 상세 정보 >> ");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t" + "공연명: " + map.get("공연명"));
		System.out.print("\t" + "주최/기획: " + map.get("주최/기획") + "\t ");
		System.out.println("\t" + "고객문의: " + map.get("고객문의"));
		System.out.print("\t" + "공연시간: " + map.get("공연시간") + "\t\t ");
		System.out.println("\t" + "관람등급: " + map.get("관람등급"));
		System.out.print("\t" + "주연: " + map.get("주연") + "\t\t ");
		System.out.println("\t" + "공연장소: " + map.get("공연장소"));
		System.out.println("\t" + "예매수수료: " + map.get("예매수수료"));
		System.out.println("\t" + "공연시간: " + map.get("공연시간"));
		System.out.println("------------------------------------------------------------------------");
		System.out.println("  1.돌아가기          2.예매하기          3.메인으로");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		switch (enter) {
		case "1":
			showConcertInfo(category);
			break;
		case "2":
			showConcertSeat(conId);
			break;
		case "3":
			showMainMenu();
			break;
		default:
			showReEnterMsg();
			showMyPageMenu();
			break;
		}
	}

	public void showConcertSeat(Object conId) {
		SeatService ss = SeatService.getInstance();
		ConcertDAO dao = ConcertDAO.getInstance();
		Map<String, Object> map = dao.selectConcert(conId);

		ss.showSeatLeftAll();
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t   Q. 예매 메뉴로 돌아가기");
		System.out.print("\t\t              ※ 좌석을 선택해 주세요(예: V1) >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		SeatDAO sdao = SeatDAO.getInstance();
		if(enter.equals("Q") || enter.equals("q")) {
			showCategoryMenu();
		}
		else if(sdao.selectSeat(enter) != null) {
			System.out.println("\t\t                 ※ 선택하신 좌석이 " + enter + "(이)가 맞습니까?");
			System.out.println("------------------------------------------------------------------------");
			System.out.print("\t\t\t            입력(Y/N) >> ");
			String enter2 = ScanUtil.nextLine();
			System.out.println("------------------------------------------------------------------------");
			switch (enter2) {
			case "Y":
			case "y":
				String seatNo = enter;
				ticketService.showTicketService(conId, seatNo);
				break;
			default:
				showConcertSeat(conId);
				break;
			}
		}
		else {
			showReEnterMsg();
			showConcertSeat(conId);
		}
	}

	// 마이페이지
	public void showMyPageMenu() {
		System.out.println("\t\t\t      << 마이페이지 >>   ");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t      1. 내정보확인");
		System.out.println("\t\t\t      2. 예약내역확인");
		System.out.println("\t\t\t      3. 회원정보수정");
		System.out.println("\t\t\t      4. 로그아웃");
		System.out.println("\t\t\t      5. 돌아가기");
		System.out.println("\t\t\t      Q. 시스템종료");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		switch (enter) {
		case "1":
			showMemberInfo();
			break;
		case "2":
			showTicketCheck();
			break;
		case "3":
			showModifyMember();
			break;
		case "4":
			showHomeMenu();
			break;
		case "5":
			showMainMenu();
			break;
		case "q":
		case "Q":
			System.out.println("\t\t\t          프로그램을 종료합니다.");
			System.out.println("------------------------------------------------------------------------");
			return;
		default:
			showReEnterMsg();
			showMyPageMenu();
			break;
		}
	}

	public void showMemberInfo() {
		Map<String, Object> map = myPageService.showMember(String.valueOf(MemberVO.getInstance().getId()));
		System.out.println("\t\t\t       << 내 정보 >>");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("\t\t\t아이디: " + map.get("MEM_ID"));
		System.out.println("\t\t\t이름: " + map.get("MEM_NAME"));
		System.out.println("\t\t\t주민등록번호: " + map.get("MEM_REGNO1") + "-" + map.get("MEM_REGNO2").toString().substring(0, 1) + "******");
		System.out.println("\t\t\t주소: " + map.get("MEM_ADDR"));
		System.out.println("\t\t\t전화번호: " + map.get("MEM_HP"));
		System.out.println("------------------------------------------------------------------------");
		System.out.println("  1.돌아가기          Q. 종료");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		String enter = ScanUtil.nextLine();
		switch (enter) {
		case "1":
			showMyPageMenu();
			break;
		case "q":
		case "Q":
			System.out.println("\t\t\t          프로그램을 종료합니다.");
			System.out.println("------------------------------------------------------------------------");
		default:
			showReEnterMsg();
			showMemberInfo();
			break;
		}
	}

	// 예약내역확인
	public void showTicketCheck() {

		System.out.println("\t\t\t     << 예약내역확인 >>  ");
		System.out.println("------------------------------------------------------------------------");

		List<Map<String, Object>> list = myPageService.showTicket("hello");
		if(list.size() != 0) {
			for (int i = 0; i < list.size(); i++) {
				System.out.println("\t\t\t  티켓번호: " + list.get(i).get("TICKET_ID"));
				System.out.println("\t\t\t  공연이름: " + list.get(i).get("CON_NAME"));
				System.out.println("\t\t\t  공연날짜: " + FormatUtil.format(list.get(i).get("CON_DATE")));
				System.out.println("\t\t\t  출연진: " + list.get(i).get("CAST_NAME"));
				System.out.println("\t\t\t  장소: " + list.get(i).get("PLACE_NAME"));
				System.out.println("\t\t\t  좌석: " + list.get(i).get("SEAT_NO"));
				System.out.println("\t\t\t  결제수단: " + list.get(i).get("PAYMETHOD_NAME"));
			}
			System.out.println("------------------------------------------------------------------------");
			System.out.println("  1.돌아가기          2.환불          Q.종료");
			System.out.println("------------------------------------------------------------------------");
			System.out.print("\t\t\t\t입력 >> ");
			String enter = ScanUtil.nextLine();
			System.out.println("------------------------------------------------------------------------");
			switch (enter) {
			case "1":
				showMyPageMenu();
				break;
			case "2":
				showRefund();
				break;
			case "q":
			case "Q":
				System.out.println("\t\t\t          프로그램을 종료합니다.");
				System.out.println("------------------------------------------------------------------------");
				break;
			}
		}
		else {
			System.out.println("\n\t\t                        ※ 표시할 예약 정보가 없습니다.\n");
			System.out.println("------------------------------------------------------------------------");
			showMyPageMenu();
		}
	}

	// 회원정보변경
	public void showModifyMember() {
		System.out.println("\t\t\t     << 회원정보수정 >>  ");
		System.out.println("------------------------------------------------------------------------");
		System.out.println("  1.이름          2.비밀번호          3.주소          4.전화번호");
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t\t\t입력 >> ");
		int enter = ScanUtil.nextInt();
		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t                  ※ 변경할 내용을 입력해 주세요 >> ");
		String newMem = ScanUtil.nextLine();
		if(myPageService.modifyMember(enter, newMem, MemberVO.getInstance()) > 0) {
			System.out.println("------------------");
			System.out.println("변경되었습니다.\n마이페이지로 돌아갑니다.");
			showMyPageMenu();
		}
		else {
			showReEnterMsg();
			showModifyMember();
		}

	}

	// 환불
	public void showRefund() {
		Object ticketId = null;

		System.out.println("\t\t\t       << 티켓환불 >>");
		System.out.println("------------------------------------------------------------------------");
		List<Map<String, Object>> list = myPageService.showTicketId(String.valueOf(MemberVO.getInstance().getId()));

		for (int i = 0; i < list.size(); i++) {
			System.out.println("\t\t\t    " + (i + 1) + ". 티켓번호: " + list.get(i).get("TICKET_ID"));
		}

		System.out.println("------------------------------------------------------------------------");
		System.out.print("\t\t             ※ 환불하실 티켓번호를 정확히 입력하세요 >> ");
		String refundTicket = ScanUtil.nextLine();
		System.out.println("------------------------------------------------------------------------");
		for (int i = 0; i < list.size(); i++) {
			if(refundTicket.equals(list.get(i).get("TICKET_ID"))) {
				ticketId = list.get(i).get("TICKET_ID");
			}
		}
		try {
			Map<String, Object> ticketing = myPageService.showTicketingId(ticketId);
			Map<String, Object> pay = myPageService.showPayMethod(ticketing.get("TICKETING_ID"));

			if(myPageService.insertRefund(ticketing.get("TICKETING_ID")) > 0) {
				System.out.println("\n\t\t               ※ 환불처리가 정상적으로 완료되었습니다.");
				System.out.println("\t\t\t      ※ 마이페이지로 돌아갑니다.\n");
				System.out.println("------------------------------------------------------------------------");
				showMyPageMenu();
			}
			else {
				showReEnterMsg();
				showRefund();
			}
		}
		catch (Exception e) {
			showReEnterMsg();
			showRefund();
		}
	}

}
