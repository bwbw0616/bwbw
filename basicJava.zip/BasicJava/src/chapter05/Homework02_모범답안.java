package chapter05;

import java.util.Random;

public class Homework02_모범답안 {
	public static void main(String[]args) {
	
		int[] numbers = new int[45];
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = i + 1 ;
		}
		Random random = new Random();
		
		for (int i = 0; i < numbers.length; i++) {
			int ranNum = random.nextInt(45);
			
			//numbers[i]와 numbers[ranNum]을 바꿔준다.
			
			int temp = numbers[i];
			numbers[i] = numbers[ranNum];
			numbers[ranNum] = temp;
		} 
		for (int i = 0; i < 6; i++) {
			System.out.println(numbers[i]+" ");
		}
		
	}
}
