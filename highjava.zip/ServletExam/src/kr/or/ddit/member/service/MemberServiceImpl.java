package kr.or.ddit.member.service;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.Util.SqlMapClientFactory;
import kr.or.ddit.member.dao.IMemberDAO;
import kr.or.ddit.member.dao.MemberDAOImpl;
import kr.or.ddit.member.vo.MemberVO;

public class MemberServiceImpl implements IMemberService{
	
	private static IMemberService memService;
	
	private SqlMapClient smc;
	
	private IMemberDAO memDAO;
	
	public MemberServiceImpl() {
		memDAO = MemberDAOImpl.getInstance();
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static IMemberService getInstance() {
		if(memService == null) {
			memService = new MemberServiceImpl();
		}
		return memService;
	}	

	@Override
	public int inserMember(MemberVO mv) {
		
		
		int cnt = 0;
		
		try {
			smc.startTransaction(); //트랜젝션 시작
			
			cnt = memDAO.inserMember(smc, mv);
			
			smc.commitTransaction(); //커밋
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				smc.endTransaction();  //트랜젝션 끝
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
		return cnt;
	}

	@Override
	public int updateMember(MemberVO mv) {
		return memDAO.updateMember(smc, mv);
	}

	@Override
	public int deleteMember(String memId) {
		return memDAO.deleteMember(smc, memId);
	}

	@Override
	public List<MemberVO> getAllMemberList() {
		return memDAO.getAllMemberList(smc);
	}

	@Override
	public boolean checkMember(String memId) {
		return memDAO.checkMember(smc, memId);
	}

	@Override
	public List<MemberVO> searchMemberList(MemberVO mv) {
		return memDAO.searchMemberList(smc, mv);
	}

	@Override
	public MemberVO getMember(String memId) {
		return memDAO.getMember(smc, memId);
	}

}
