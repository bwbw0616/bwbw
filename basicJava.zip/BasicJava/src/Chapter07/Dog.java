package Chapter07;

public class Dog extends Animal {
	final String a = "10";
	//메소드 재정의(Method Overriding)
	@Override
	public String sound() {
		System.out.println(super.sound());
		return "멍멍";
	}
}