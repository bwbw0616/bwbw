package chapter05;

import java.util.Scanner;

public class ReferenceExample {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("나이를 입력하세요: ");
		int age = scanner.nextInt();
		System.out.println("이름을 입력하세요: ");
		String name = scanner.next();
		System.out.printf("당신의 이름은 %s이고, 나이는 %d입니다.\n", name, age);
		scanner.close();		
	}
}
